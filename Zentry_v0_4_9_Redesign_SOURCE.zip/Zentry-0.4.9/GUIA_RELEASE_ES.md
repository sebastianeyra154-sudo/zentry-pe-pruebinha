# Zentry — proceso de release

## Estado antes de publicar

- Corrección actual preparada como versión `0.4.9`; sigue pendiente la nueva ejecución completa en Windows.

- Versión declarada en `zentry/__init__.py`: `0.4.9`.
- El paquete fuente actual no incluye `dist\Zentry.exe`.
- No hay evidencia de un run de Windows Actions exitoso adjunta a esta entrega.
- El workflow construye y sube un artifact de 14 días; no crea automáticamente una GitHub Release.
- No hay una licencia elegida ni archivo `LICENSE`; la decisión sigue pendiente.
- No se declara instalador, firma digital, autoactualización ni matriz completa de Windows probada.

## Checklist pre-release

### 1. Cambios y versión

- [ ] Acordar el alcance de la release y confirmar que se completaron los módulos previstos.
- [ ] Elegir la versión explícitamente antes de cambiar `zentry/__init__.py` y referencias de documentación.
- [ ] Decidir y revisar la licencia con criterio expreso; añadir `LICENSE` solo después de la decisión.
- [ ] Revisar dependencias directas y licencias/obligaciones de redistribución de sus componentes.
- [ ] Revisar `git status` y `git diff`; no publicar logs ni datos locales.

### 2. Pruebas

- [ ] Instalar dependencias desde `requirements-dev.txt`.
- [ ] `python -m pip check` usando `.venv`.
- [ ] `python -m compileall -q zentry tests`.
- [ ] `python -m pytest -q -rs`.
- [ ] Distinguir PASÓ, FALLÓ y SKIPPED; documentar cada test omitido.
- [ ] En Windows, probar manualmente todas las páginas, idioma ES/EN, escalado DPI, estados de error y cierre durante tareas.
- [ ] Probar limpieza solo con archivos temporales sintéticos/no importantes en un entorno de prueba; verificar selección vacía, candidato cambiado, protegido, fallo `send2trash` y resumen de resultados.

### 3. Build de Windows

- [ ] Ejecutar `build_windows.bat` o `build_windows.ps1` en una máquina Windows normal, sin administrador.
- [ ] Verificar que el workflow `Windows build — Zentry` termina correctamente en `windows-latest`.
- [ ] Descargar `Zentry.exe` desde el artifact recién generado.
- [ ] Comprobar SHA-256 y tamaño; guardar la versión exacta del artifact.
- [ ] Ejecutar el EXE y recorrer todas las páginas. El smoke test del workflow solo comprueba que el proceso sigue vivo por diez segundos.
- [ ] Documentar las versiones reales de Python/Windows usadas y las limitaciones no probadas.

### 4. Publicación

El workflow actual corre en pull requests, pushes a `main`/`master`, tags `v*` y ejecución manual. Publica `Zentry.exe` como artifact con retención de 14 días y logs como artifact separado.

- [ ] Esperar una ejecución real exitosa; no basta con que el YAML parsea o con que los tests en Linux pasen.
- [ ] Si el proyecto usa GitHub Releases, crear la Release manualmente después de decidir licencia y proceso de publicación.
- [ ] Adjuntar el EXE generado en el run correcto, checksum y notas de versión.
- [ ] Indicar plataforma/arquitectura y limitaciones conocidas.
- [ ] No afirmar que el artifact está firmado ni verificado por antivirus si no se hizo esa comprobación.

## Rollback de release

- No sobreescribir silenciosamente una release anterior.
- Identificar el tag/commit y artifact concreto.
- Si se detecta defecto, retirar/anunciar el artifact afectado según el proceso del repositorio y preparar una versión corregida con tests de regresión.
- No recomendar a usuarios que ejecuten como administrador para sortear fallos de instalación/build.
