[CmdletBinding()]
param(
    [switch]$NonInteractive
)

$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$venvDirectory = Join-Path $projectRoot '.venv'
$venvPython = Join-Path $venvDirectory 'Scripts\python.exe'
$requirementsFile = Join-Path $projectRoot 'requirements-dev.txt'
$distDirectory = Join-Path $projectRoot 'dist'
$buildDirectory = Join-Path $projectRoot 'build'
$exePath = Join-Path $distDirectory 'Zentry.exe'
$logDirectory = Join-Path $projectRoot '.build-logs'
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $logDirectory "build_$timestamp.log"
$transcriptStarted = $false
$exitCode = 0

function Get-PythonInfo {
    param(
        [Parameter(Mandatory)][string]$Executable,
        [string[]]$PrefixArguments = @()
    )

    $probe = "import json,sys; print(json.dumps({'executable':sys.executable,'implementation':sys.implementation.name,'major':sys.version_info.major,'minor':sys.version_info.minor,'micro':sys.version_info.micro}))"
    $arguments = @()
    if ($PrefixArguments.Count -gt 0) { $arguments += $PrefixArguments }
    $arguments += @('-c', $probe)

    try {
        $output = & $Executable @arguments 2>$null
        $nativeExitCode = $LASTEXITCODE
        if ($nativeExitCode -ne 0) { return $null }
        $jsonLine = $output | Where-Object { ([string]$_).TrimStart().StartsWith('{') } | Select-Object -Last 1
        if (-not $jsonLine) { return $null }
        $info = ([string]$jsonLine) | ConvertFrom-Json
        if ($info.implementation -ne 'cpython' -or [int]$info.major -ne 3 -or [int]$info.minor -lt 11 -or [int]$info.minor -gt 14) {
            return $null
        }
        return $info
    }
    catch {
        return $null
    }
}

function Find-PythonInstallation {
    $candidates = [System.Collections.Generic.List[object]]::new()

    foreach ($name in @('py.exe', 'python3.exe', 'python.exe')) {
        $commands = @(Get-Command $name -CommandType Application -All -ErrorAction SilentlyContinue)
        foreach ($command in $commands) {
            # Los aliases de WindowsApps en la raiz pueden abrir Microsoft Store;
            # no los ejecutamos. Las instalaciones versionadas se prueban mas abajo.
            if ($command.Source -match '(?i)\\Microsoft\\WindowsApps\\(?:python|python3)\.exe$') { continue }
            $prefix = @()
            if ($name -ieq 'py.exe') { $prefix = @('-3') }
            $candidates.Add([pscustomobject]@{
                Executable = $command.Source
                PrefixArguments = $prefix
                Source = "PATH: $name"
            })
        }
    }

    $localPythonRoot = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Programs\Python' } else { $null }
    if ($localPythonRoot -and (Test-Path -LiteralPath $localPythonRoot)) {
        foreach ($directory in Get-ChildItem -LiteralPath $localPythonRoot -Directory -ErrorAction SilentlyContinue) {
            $candidates.Add([pscustomobject]@{
                Executable = Join-Path $directory.FullName 'python.exe'
                PrefixArguments = @()
                Source = 'Instalacion por usuario'
            })
        }
    }

    $programRoots = @($env:ProgramFiles, ${env:ProgramFiles(x86)}) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
    foreach ($root in $programRoots) {
        foreach ($directory in Get-ChildItem -LiteralPath $root -Directory -Filter 'Python3*' -ErrorAction SilentlyContinue) {
            $candidates.Add([pscustomobject]@{
                Executable = Join-Path $directory.FullName 'python.exe'
                PrefixArguments = @()
                Source = 'Program Files'
            })
        }
    }

    if ($env:LOCALAPPDATA) {
        $windowsApps = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps'
        if (Test-Path -LiteralPath $windowsApps) {
            foreach ($directory in Get-ChildItem -LiteralPath $windowsApps -Directory -Filter 'PythonSoftwareFoundation.Python.3.*' -ErrorAction SilentlyContinue) {
                $candidates.Add([pscustomobject]@{
                    Executable = Join-Path $directory.FullName 'python.exe'
                    PrefixArguments = @()
                    Source = 'Alias de Microsoft Store comprobado por ejecucion'
                })
            }
        }
    }

    foreach ($version in @('314', '313', '312', '311')) {
        foreach ($path in @("C:\Python$version\python.exe", (Join-Path $env:ProgramFiles "Python$version\python.exe"))) {
            if ($path) {
                $candidates.Add([pscustomobject]@{
                    Executable = $path
                    PrefixArguments = @()
                    Source = 'Ruta de instalacion conocida'
                })
            }
        }
    }

    $seen = @{}
    foreach ($candidate in $candidates) {
        $key = '{0}|{1}' -f $candidate.Executable, ($candidate.PrefixArguments -join ' ')
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true
        if (-not (Test-Path -LiteralPath $candidate.Executable) -and -not (Get-Command $candidate.Executable -ErrorAction SilentlyContinue)) { continue }
        $info = Get-PythonInfo -Executable $candidate.Executable -PrefixArguments $candidate.PrefixArguments
        if ($null -ne $info) {
            return [pscustomobject]@{
                Executable = $candidate.Executable
                PrefixArguments = $candidate.PrefixArguments
                Source = $candidate.Source
                Info = $info
            }
        }
    }

    throw 'No se encontro una instalacion real de CPython 3.11-3.14. Los alias de Microsoft Store solo se aceptan si ejecutan correctamente el probe.'
}

function Invoke-CheckedNative {
    param(
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][string]$Executable,
        [string[]]$Arguments = @()
    )
    Write-Host "  -> $Description"
    & $Executable @Arguments
    $nativeExitCode = $LASTEXITCODE
    if ($nativeExitCode -ne 0) {
        throw "$Description fallo con codigo de salida $nativeExitCode. Revisa el log: $logPath"
    }
}

function Clear-ProjectArtifacts {
    foreach ($name in @('build', 'dist')) {
        $path = Join-Path $projectRoot $name
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Recurse -Force
            if (Test-Path -LiteralPath $path) { throw "No se pudo limpiar el artefacto: $path" }
        }
    }

    $generatedSpec = Join-Path $projectRoot 'Zentry.spec'
    if (Test-Path -LiteralPath $generatedSpec) {
        Remove-Item -LiteralPath $generatedSpec -Force
    }

    # Limpiar bytecode solo bajo el codigo fuente y los tests del proyecto.
    foreach ($relativeRoot in @('zentry', 'tests')) {
        $path = Join-Path $projectRoot $relativeRoot
        if (-not (Test-Path -LiteralPath $path)) { continue }
        Get-ChildItem -LiteralPath $path -Directory -Filter '__pycache__' -Recurse -ErrorAction SilentlyContinue |
            Sort-Object { $_.FullName.Length } -Descending |
            ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
        Get-ChildItem -LiteralPath $path -File -Filter '*.pyc' -Recurse -ErrorAction SilentlyContinue |
            ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    }
}

try {
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    try {
        Start-Transcript -Path $logPath -Force | Out-Null
        $transcriptStarted = $true
    }
    catch {
        Write-Warning "No se pudo iniciar el transcript; la salida seguira visible. Causa: $($_.Exception.GetType().Name)"
    }

    Write-Host ''
    Write-Host '============================================================'
    Write-Host '                 ZENTRY - WINDOWS BUILD'
    Write-Host '============================================================'
    Write-Host "Proyecto: $projectRoot"
    Write-Host "Log: $logPath"

    Write-Host ''
    Write-Host '[PASO 1/8] Detectar un interprete Python real y compatible...'
    $basePython = $null
    if (Test-Path -LiteralPath $venvPython) {
        $venvInfo = Get-PythonInfo -Executable $venvPython
        if ($null -eq $venvInfo) {
            throw '.venv existe, pero su Python no es compatible (se requiere CPython 3.11-3.14). El constructor no modificara ni eliminara ese entorno.'
        }
        Write-Host "Interprete existente de .venv: $($venvInfo.executable), version $($venvInfo.major).$($venvInfo.minor).$($venvInfo.micro)"
    }
    elseif (Test-Path -LiteralPath $venvDirectory) {
        throw '.venv existe pero no contiene Scripts\python.exe. Haz copia de seguridad y renombra o elimina solo esa carpeta .venv antes de volver a ejecutar.'
    }
    else {
        $basePython = Find-PythonInstallation
        Write-Host "Fuente: $($basePython.Source)"
        Write-Host "Interprete: $($basePython.Info.executable)"
        Write-Host "Version: $($basePython.Info.major).$($basePython.Info.minor).$($basePython.Info.micro)"
    }

    Write-Host ''
    Write-Host '[PASO 2/8] Crear o validar el entorno virtual local...'
    if (-not (Test-Path -LiteralPath $venvPython)) {
        $arguments = @()
        if ($basePython.PrefixArguments.Count -gt 0) { $arguments += $basePython.PrefixArguments }
        $arguments += @('-m', 'venv', $venvDirectory)
        Invoke-CheckedNative -Description 'Crear .venv' -Executable $basePython.Executable -Arguments $arguments
    }
    $venvInfo = Get-PythonInfo -Executable $venvPython
    if ($null -eq $venvInfo) { throw 'El Python de .venv no es compatible tras crear/reutilizar el entorno.' }
    Write-Host "Entorno utilizado: $($venvInfo.executable)"
    Write-Host "Version: $($venvInfo.major).$($venvInfo.minor).$($venvInfo.micro)"

    Write-Host ''
    Write-Host '[PASO 3/8] Instalar dependencias y comprobar consistencia...'
    if (-not (Test-Path -LiteralPath $requirementsFile)) { throw 'No existe requirements-dev.txt en la raiz del proyecto.' }
    Invoke-CheckedNative -Description 'Instalar requirements-dev.txt' -Executable $venvPython -Arguments @('-m', 'pip', '--disable-pip-version-check', 'install', '-r', $requirementsFile)
    Invoke-CheckedNative -Description 'pip check' -Executable $venvPython -Arguments @('-m', 'pip', 'check')
    Write-Host 'Versiones instaladas (pip freeze):'
    Invoke-CheckedNative -Description 'pip freeze' -Executable $venvPython -Arguments @('-m', 'pip', 'freeze')

    Write-Host ''
    Write-Host '[PASO 4/8] Comprobar sintaxis Python...'
    Invoke-CheckedNative -Description 'compileall' -Executable $venvPython -Arguments @('-m', 'compileall', '-q', (Join-Path $projectRoot 'zentry'), (Join-Path $projectRoot 'tests'))

    Write-Host ''
    Write-Host '[PASO 5/8] Ejecutar pruebas automatizadas...'
    Invoke-CheckedNative -Description 'pytest' -Executable $venvPython -Arguments @('-m', 'pytest', '-q', '-rs')

    Write-Host ''
    Write-Host '[PASO 6/8] Limpiar solo artefactos de build bajo la raiz del proyecto...'
    Clear-ProjectArtifacts

    Write-Host ''
    Write-Host '[PASO 7/8] Construir Zentry.exe con PyInstaller...'
    Write-Host 'Se usan los hooks estandar de PyInstaller para PySide6/Qt; no se fuerza la inclusion de todos los plugins opcionales.'
    Write-Host 'La salida del build no se filtra: los warnings se muestran y un codigo fatal detiene el proceso.'
    $entryPoint = Join-Path $projectRoot 'zentry\__main__.py'
    Invoke-CheckedNative -Description 'PyInstaller' -Executable $venvPython -Arguments @(
        '-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile', '--windowed',
        '--name', 'Zentry', '--log-level', 'INFO', '--paths', $projectRoot,
        '--distpath', $distDirectory, '--workpath', $buildDirectory,
        '--specpath', $projectRoot, $entryPoint
    )

    Write-Host ''
    Write-Host '[PASO 8/8] Verificar el ejecutable...'
    if (-not (Test-Path -LiteralPath $exePath -PathType Leaf)) { throw "PyInstaller no produjo el archivo esperado: $exePath" }
    $exe = Get-Item -LiteralPath $exePath
    if ($exe.Length -le 0) { throw "El ejecutable tiene tamano cero: $exePath" }
    $hash = (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash
    Write-Host "BUILD SUCCESSFUL: $exePath"
    Write-Host "Tamano: $($exe.Length) bytes"
    Write-Host "SHA-256: $hash"
    Write-Host 'Esta comprobacion confirma existencia/tamano/hash; no sustituye la prueba de arranque e interaccion de la GUI.'

    if ($NonInteractive) {
        Write-Host 'Modo no interactivo: se omite abrir Explorer.'
    }
    else {
        try {
            Start-Process -FilePath 'explorer.exe' -ArgumentList @('"' + $distDirectory + '"') -ErrorAction Stop | Out-Null
            Write-Host 'Se abrio la carpeta dist.'
        }
        catch {
            Write-Warning "Build correcto, pero no se pudo abrir Explorer: $($_.Exception.GetType().Name)"
        }
    }
}
catch {
    $exitCode = 1
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host '[FALLO] La construccion se detuvo.' -ForegroundColor Red
    Write-Host "Categoria: $($_.Exception.GetType().Name)"
    Write-Host "Detalle: $($_.Exception.Message)"
    Write-Host "Log: $logPath"
    Write-Host 'No se afirma que el EXE sea funcional.'
    Write-Host '============================================================' -ForegroundColor Red
}
finally {
    if ($transcriptStarted) {
        try { Stop-Transcript | Out-Null } catch { }
    }
}

if (-not $NonInteractive) {
    Read-Host 'Pulsa Enter para cerrar la consola' | Out-Null
}
exit $exitCode
