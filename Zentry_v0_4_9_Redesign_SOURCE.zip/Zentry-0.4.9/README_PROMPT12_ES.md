# Zentry — Prompt 12: Constructor de Windows y creación del EXE

Este módulo actualiza exclusivamente el empaquetado y su documentación. No cambia la lógica de la aplicación, el scanner, el clasificador ni el motor de limpieza.

## Archivos incluidos

- `build_windows.bat`: constructor para doble clic o CMD/PowerShell.
- `build_windows.ps1`: constructor con transcript de diagnóstico; acepta `-NonInteractive` para CI.
- `requirements-dev.txt`: dependencias de ejecución más versiones directas fijadas para tests/build.
- `.github/workflows/build-windows.yml`: tests, build Windows, smoke test de arranque y publicación de artifacts.
- `.gitignore`: excluye solo artefactos locales del desarrollo/build.
- `tests/test_build_configuration.py`: comprobaciones estáticas de configuración del empaquetado.
- `README.md`: instrucciones de build actualizadas.

## Secuencia del constructor

1. Detecta CPython real y comprueba su versión. Acepta Python 3.11–3.14; los aliases directos de `WindowsApps` se descartan para evitar abrir Microsoft Store. Las rutas de intérprete se verifican ejecutando un probe real.
2. Crea o reutiliza `.venv` dentro de la raíz del proyecto. Si la carpeta existe pero está dañada o usa una versión incompatible, no la borra: informa al usuario.
3. Instala `requirements-dev.txt` mediante ` .venv\Scripts\python.exe -m pip`, ejecuta `pip check` e informa de las versiones instaladas.
4. Ejecuta `compileall` y pytest. Si cualquiera falla, no empieza PyInstaller.
5. Solo después de las comprobaciones limpia `build`, `dist`, `Zentry.spec` y las cachés bajo `zentry/` y `tests/`. No recorre ni elimina carpetas de usuario fuera de la raíz del proyecto, y no limpia `.venv` ni `.build-logs`.
6. Ejecuta PyInstaller como `--onefile --windowed --name Zentry` usando el intérprete del entorno virtual.
7. Comprueba que `dist\Zentry.exe` exista y tenga tamaño mayor que cero, muestra SHA-256 y abre la carpeta `dist` únicamente al terminar correctamente.
8. Deja la consola abierta tras éxito/fallo; devuelve códigos de salida distintos de cero en los fallos.

## Qt/PySide6 y advertencias

El build usa los hooks estándar de PyInstaller para PySide6 en vez de `--collect-all PySide6`, que recogía también plugins opcionales e introducía advertencias innecesarias en builds previos. No se filtran ni se ocultan la salida de PyInstaller, sus warnings o errores fatales. Un código de salida distinto de cero detiene el build.

PyInstaller documenta soporte integrado para bibliotecas de GUI como PySide6, aunque el resultado debe verificarse en el sistema objetivo. Referencia: https://pyinstaller.org/en/latest/.

## Dependencias y reproducibilidad

`requirements.txt` conserva los rangos declarados de dependencias de ejecución. `requirements-dev.txt` incluye ese archivo y fija las versiones directas principales usadas aquí:

- PySide6 6.12.0
- psutil 7.2.2
- send2trash 1.8.3
- pytest 9.1.1
- PyInstaller 6.22.3

Estas versiones directas se contrastaron con los metadatos de PyPI disponibles al preparar el parche. `send2trash` sigue en 1.8.3 para respetar el rango actual `>=1.8,<2` del proyecto.

**Límite de reproducibilidad:** las dependencias transitivas no tienen aún un lock completo con hashes. Los pines directos reducen las variaciones, pero no garantizan builds bit a bit idénticos.

## Cómo compilar

### Opción principal: BAT

Haz doble clic en `build_windows.bat`. No hace falta ejecutar como administrador ni cambiar `ExecutionPolicy`.

Para conservar también una copia de toda la salida en un log desde PowerShell normal:

```powershell
New-Item -ItemType Directory -Force .build-logs | Out-Null
.\build_windows.bat 2>&1 | Tee-Object -FilePath .\.build-logs\build-local.log
```

El BAT mantiene la consola abierta y muestra el último paso alcanzado. Si falla, copia el contenido desde `[PASO ...]` hasta `[FALLO]`, o comparte `build-local.log` tras revisar que no contenga rutas personales que prefieras ocultar.

### Opción PowerShell

Si la política de tu equipo permite ejecutar el archivo sin cambiar la configuración, usa:

```powershell
.\build_windows.ps1
```

El script crea automáticamente `.build-logs\build_YYYYMMDD_HHMMSS.log`. En CI se invoca con `-NonInteractive` para que no espere una entrada de teclado.

## GitHub Actions

El workflow corre en `windows-latest` con Python 3.12, permisos `contents: read` y sin secretos. Ejecuta sintaxis/tests mediante el constructor, compila el EXE, realiza un smoke test de que el proceso permanezca activo durante 10 segundos y sube `dist/Zentry.exe` como artifact de 14 días. Los logs se suben incluso si falla un paso.

El smoke test solo valida que el proceso no termine inmediatamente; no prueba visualmente la GUI, accesibilidad, todas las interacciones ni las funciones de limpieza. Solo una ejecución exitosa real del workflow permite afirmar que esa versión pasó el smoke test básico en Windows.

## Validación disponible al preparar este parche

El entorno actual es Linux, por lo que no se ejecutaron los BAT/PS1, PyInstaller Windows ni el EXE Windows. La suite de Python y las comprobaciones estáticas de la configuración se pueden ejecutar aquí, pero la validación de Windows queda pendiente de GitHub Actions o de una máquina Windows.

Comandos de pruebas:

```powershell
.\.venv\Scripts\python.exe -m compileall -q zentry tests
.\.venv\Scripts\python.exe -m pytest -q -rs
```
