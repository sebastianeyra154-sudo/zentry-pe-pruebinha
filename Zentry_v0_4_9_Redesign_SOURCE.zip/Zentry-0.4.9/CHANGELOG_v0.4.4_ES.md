# Cambios de Zentry 0.4.4

- Rediseño del tema: azul marino, acentos cian/violeta, tarjetas y controles más claros.
- Barra superior persistente con idioma y etiqueta de solo lectura.
- Navegación lateral y página principal reorganizadas para priorizar estado, salud heurística, recomendaciones y limpieza segura.
- Se mantiene la integración con los proveedores y servicios existentes; no se añadieron acciones de terminación de procesos ni limpieza automática.
- El workflow ya no intenta crear caché de pip basándose en un archivo que GitHub no haya encontrado; si `requirements-dev.txt` falta en la raíz, genera una copia fijada para permitir que el build continúe y muestre cualquier fallo posterior.
- Se actualizó la presentación y la referencia visual de la interfaz.

## Validación

- `compileall`: correcto.
- Pruebas disponibles: 134 correctas, 3 omitidas por falta de PySide6.
- Pendiente: validar visualmente la GUI y completar el build/smoke test en Windows.
