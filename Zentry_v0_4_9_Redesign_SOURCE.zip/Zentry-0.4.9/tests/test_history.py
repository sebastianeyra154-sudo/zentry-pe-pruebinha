from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

import pytest

import zentry.core.history as history_module
from zentry.core.history import (
    HISTORY_SCHEMA_VERSION,
    HistoryEvent,
    HistoryOperation,
    HistoryResult,
    HistoryStore,
    HistoryStoreError,
)
from zentry.models import ScanHistoryItem


def make_event(**overrides: object) -> HistoryEvent:
    values: dict[str, object] = {
        "operation_type": HistoryOperation.STALE_SCAN,
        "result": HistoryResult.SUCCESS,
        "timestamp": datetime(2026, 10, 21, 12, 0, tzinfo=timezone.utc),
        "files_seen": 42,
        "candidate_files": 5,
        "estimated_bytes": 1024 * 1024,
        "skipped_files": 2,
        "failed_files": 0,
        "error_codes": (),
    }
    values.update(overrides)
    return HistoryEvent(**values)  # type: ignore[arg-type]


def legacy_record() -> dict[str, object]:
    return ScanHistoryItem(
        timestamp=datetime(2026, 10, 20, 10, 0, tzinfo=timezone.utc),
        health_score=85,
        cpu_percent=22.0,
        memory_percent=46.0,
        disk_percent=70.0,
        reclaimable_bytes=12345,
        cleaned_bytes=2048,
    ).to_persistence_record()


def test_history_store_round_trip_uses_versioned_envelope_and_aggregates_only(
    tmp_path: Path,
) -> None:
    path = tmp_path / "history.json"
    store = HistoryStore(path)
    event = make_event(process_count=121, protected_files=3, moved_bytes=4096)

    events = store.append(event)
    payload = json.loads(path.read_text(encoding="utf-8"))
    restored = store.load()

    assert payload["schema_version"] == HISTORY_SCHEMA_VERSION == 2
    assert len(payload["events"]) == 1
    assert restored == (event,)
    serialized = path.read_text(encoding="utf-8")
    for forbidden in (
        "path",
        "filename",
        "command",
        "pid",
        "secret-user",
        "C:\\\\Users",
    ):
        assert forbidden not in serialized
    assert "process_count" in payload["events"][0]


def test_history_event_rejects_personal_data_smuggled_into_error_or_event_id() -> None:
    with pytest.raises(ValueError, match="error_codes"):
        make_event(error_codes=(r"C:\Users\Alice\secret.txt",))
    with pytest.raises(ValueError, match="event_id must be a UUID"):
        make_event(event_id=r"C:\Users\Alice\history")


def test_legacy_list_schema_is_loaded_and_migrated_on_next_append(tmp_path: Path) -> None:
    path = tmp_path / "history.json"
    path.write_text(json.dumps([legacy_record()]), encoding="utf-8")
    store = HistoryStore(path)

    legacy = store.load()
    assert len(legacy) == 1
    assert legacy[0].operation_type is HistoryOperation.LEGACY_AGGREGATE
    assert legacy[0].health_score == 85
    assert legacy[0].estimated_bytes == 12345
    assert legacy[0].moved_bytes == 2048

    appended = store.append(make_event())
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["schema_version"] == 2
    assert len(appended) == 2
    assert appended[0].operation_type is HistoryOperation.STALE_SCAN


def test_missing_history_is_empty_and_clear_does_not_touch_logs(tmp_path: Path) -> None:
    data_dir = tmp_path / "state"
    history_path = data_dir / "history.json"
    log_path = data_dir / "logs" / "zentry.log"
    log_path.parent.mkdir(parents=True)
    log_path.write_text("leave log intact", encoding="utf-8")
    store = HistoryStore(history_path)

    assert store.load() == ()
    assert store.clear() is False
    store.append(make_event())
    assert store.clear() is True
    assert store.load() == ()
    assert store.clear() is False
    assert log_path.read_text(encoding="utf-8") == "leave log intact"


def test_corrupt_json_is_reported_then_recovered_on_next_append(tmp_path: Path) -> None:
    path = tmp_path / "history.json"
    path.write_text('{"events": [this is not valid json', encoding="utf-8")
    store = HistoryStore(path)

    with pytest.raises(HistoryStoreError) as error:
        store.load()
    assert error.value.code == "history_json_corrupt"

    store.append(make_event())
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["schema_version"] == 2
    assert len(store.load()) == 1


def test_unsupported_schema_is_not_overwritten(tmp_path: Path) -> None:
    path = tmp_path / "history.json"
    original = json.dumps({"schema_version": 999, "events": []})
    path.write_text(original, encoding="utf-8")
    store = HistoryStore(path)

    with pytest.raises(HistoryStoreError) as error:
        store.append(make_event())
    assert error.value.code == "history_schema_unsupported"
    assert path.read_text(encoding="utf-8") == original


def test_unknown_sensitive_fields_are_not_preserved_on_next_write(tmp_path: Path) -> None:
    path = tmp_path / "history.json"
    record = make_event().to_record()
    record["private_path"] = r"C:\Users\Alice\Documents\secret.txt"
    path.write_text(
        json.dumps({"schema_version": 2, "events": [record]}),
        encoding="utf-8",
    )

    store = HistoryStore(path)
    loaded = store.load()
    assert len(loaded) == 1
    store.append(make_event(result=HistoryResult.PARTIAL))
    persisted = path.read_text(encoding="utf-8")
    assert "private_path" not in persisted
    assert "Alice" not in persisted


def test_invalid_event_record_is_rejected_without_exposing_raw_contents(tmp_path: Path) -> None:
    path = tmp_path / "history.json"
    payload = {
        "schema_version": 2,
        "events": [{"operation_type": "unknown", "private_path": r"C:\Users\Alice"}],
    }
    path.write_text(json.dumps(payload), encoding="utf-8")
    with pytest.raises(HistoryStoreError) as error:
        HistoryStore(path).load()
    assert error.value.code == "history_record_invalid"
    assert "Alice" not in str(error.value)


def test_permission_denied_read_is_recoverable_and_path_is_not_in_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path = tmp_path / "sensitive-user-directory" / "history.json"
    path.parent.mkdir()
    path.write_text("{}", encoding="utf-8")
    original_read_text = Path.read_text

    def denied_read(self: Path, *args: object, **kwargs: object) -> str:
        if self == path:
            raise PermissionError(str(path))
        return original_read_text(self, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", denied_read)
    with pytest.raises(HistoryStoreError) as error:
        HistoryStore(path).load()
    assert error.value.code == "permission_denied"
    assert "sensitive-user-directory" not in str(error.value)


def test_permission_denied_directory_creation_is_recoverable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    blocked_dir = tmp_path / "blocked-state"
    path = blocked_dir / "history.json"
    original_mkdir = Path.mkdir

    def denied_mkdir(self: Path, *args: object, **kwargs: object) -> None:
        if self == blocked_dir:
            raise PermissionError(str(blocked_dir))
        original_mkdir(self, *args, **kwargs)

    monkeypatch.setattr(Path, "mkdir", denied_mkdir)
    with pytest.raises(HistoryStoreError) as error:
        HistoryStore(path).append(make_event())
    assert error.value.code == "permission_denied"
    assert not path.exists()


def test_failed_atomic_replace_keeps_previous_history_and_cleans_temp_file(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path = tmp_path / "history.json"
    store = HistoryStore(path)
    store.append(make_event())
    original = path.read_text(encoding="utf-8")

    def denied_replace(_source: object, _destination: object) -> None:
        raise PermissionError("private OS message")

    monkeypatch.setattr(history_module.os, "replace", denied_replace)
    with pytest.raises(HistoryStoreError) as error:
        store.append(make_event(result=HistoryResult.PARTIAL))

    assert error.value.code == "permission_denied"
    assert path.read_text(encoding="utf-8") == original
    assert list(tmp_path.glob(".zentry-history-*.tmp")) == []


def test_history_store_limits_entries(tmp_path: Path) -> None:
    store = HistoryStore(tmp_path / "history.json", max_entries=2)
    events = [make_event(files_seen=index) for index in range(4)]
    for event in events:
        store.append(event)
    loaded = store.load()
    assert len(loaded) == 2
    assert loaded[0].files_seen == 3
    assert loaded[1].files_seen == 2


def test_history_symlink_is_not_followed_on_load(tmp_path: Path) -> None:
    target = tmp_path / "target.json"
    target.write_text("[]", encoding="utf-8")
    path = tmp_path / "history.json"
    try:
        path.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("Symlink creation is not available on this platform")

    with pytest.raises(HistoryStoreError) as error:
        HistoryStore(path).load()
    assert error.value.code == "history_path_is_symlink"
    assert target.read_text(encoding="utf-8") == "[]"


def test_non_utf8_history_is_reported_as_recoverable_encoding_error(tmp_path: Path) -> None:
    path = tmp_path / "history.json"
    path.write_bytes(b"\xff\xfe\x80")
    with pytest.raises(HistoryStoreError) as error:
        HistoryStore(path).load()
    assert error.value.code == "history_encoding_invalid"
    assert str(path) not in str(error.value)
