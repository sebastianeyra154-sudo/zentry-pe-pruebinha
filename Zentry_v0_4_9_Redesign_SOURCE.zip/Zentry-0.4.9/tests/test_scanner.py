from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

from zentry.core.scanner import (
    DEFAULT_MIN_AGE_DAYS,
    CleanupScanner,
    ScanIssue,
)
from zentry.models import CleanupPolicyDecision, FileClassification

NOW = datetime(2026, 10, 21, 12, 0, tzinfo=timezone.utc)


@pytest.fixture

def cleanup_environment(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> tuple[Path, Path]:
    """Use only a dedicated disposable temp tree and synthetic Windows anchors."""
    windows = tmp_path / "Windows"
    profile = tmp_path / "profile"
    program_files = tmp_path / "Program Files"
    root = tmp_path / "approved-temp"
    for directory in (windows, profile, program_files, root):
        directory.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("SystemRoot", str(windows))
    monkeypatch.setenv("USERPROFILE", str(profile))
    monkeypatch.setenv("ProgramFiles", str(program_files))
    monkeypatch.setenv("LOCALAPPDATA", str(profile / "AppData" / "Local"))
    monkeypatch.setenv("APPDATA", str(profile / "AppData" / "Roaming"))
    return root, windows


def _timestamp_days_ago(days: int, now: datetime = NOW) -> float:
    return (now - timedelta(days=days)).timestamp()


def _set_file_dates(
    path: Path,
    *,
    access_days: int,
    modified_days: int,
    now: datetime = NOW,
) -> None:
    os.utime(
        path,
        (
            _timestamp_days_ago(access_days, now),
            _timestamp_days_ago(modified_days, now),
        ),
    )


def _scanner() -> CleanupScanner:
    return CleanupScanner()


def _scan(scanner: CleanupScanner, root: Path, days: int = 31, **kwargs: object):
    return scanner.scan(
        [("Temporary test files", root)],
        min_age_days=days,
        now=NOW,
        **kwargs,
    )


def test_old_regular_file_becomes_candidate_with_explanation(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "old.cache"
    target.write_bytes(b"cache data")
    _set_file_dates(target, access_days=45, modified_days=45)

    summary = _scan(_scanner(), root)

    assert [candidate.name for candidate in summary.candidates] == ["old.cache"]
    candidate = summary.candidates[0]
    assert candidate.classification is FileClassification.SAFE_CANDIDATE
    assert candidate.policy_decision is CleanupPolicyDecision.ALLOW
    assert candidate.fingerprint is not None
    assert "Calculated age: 45 days" in candidate.reason
    assert "last-access timestamps can be disabled" in candidate.reason
    assert candidate.size_bytes == len(b"cache data")


def test_recent_file_is_not_a_candidate(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "recent.cache"
    target.write_text("recent", encoding="utf-8")
    _set_file_dates(target, access_days=2, modified_days=2)

    summary = _scan(_scanner(), root)

    assert summary.candidates == ()
    assert summary.review_files == 0


def test_recent_access_blocks_candidate_even_if_modification_is_old(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "accessed-recently.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=1, modified_days=90)

    assert _scan(_scanner(), root).candidates == ()


def test_recent_modification_blocks_candidate_even_if_access_is_old(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "modified-recently.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=90, modified_days=1)

    assert _scan(_scanner(), root).candidates == ()


def test_unknown_or_future_timestamps_are_reviewed(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, _ = cleanup_environment
    target = root / "unknown-date.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=90, modified_days=90)
    scanner = _scanner()
    original = scanner._read_file_metadata

    def metadata_with_nan_access(path: Path):
        real = original(path)
        return SimpleNamespace(
            st_mode=real.st_mode,
            st_dev=real.st_dev,
            st_ino=real.st_ino,
            st_size=real.st_size,
            # Preserve Windows-specific metadata used to reject reparse points.
            st_file_attributes=getattr(real, "st_file_attributes", None),
            st_atime=float("nan"),
            st_mtime=real.st_mtime,
            st_ctime=real.st_ctime,
            st_atime_ns=real.st_atime_ns,
            st_mtime_ns=real.st_mtime_ns,
            st_ctime_ns=real.st_ctime_ns,
        )

    monkeypatch.setattr(scanner, "_read_file_metadata", metadata_with_nan_access)
    issues: list[ScanIssue] = []
    summary = _scan(scanner, root, issue_callback=issues.append)

    assert summary.candidates == ()
    assert summary.review_files == 1
    assert issues[0].classification is FileClassification.REVIEW_REQUIRED
    assert "time is missing, invalid, inconsistent" in issues[0].reason


def test_outside_path_is_not_authorized_by_cleanup_classifier(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    outside = root.parent / "outside.cache"
    outside.write_text("outside", encoding="utf-8")
    _set_file_dates(outside, access_days=60, modified_days=60)

    assessment = _scanner()._assess_file(
        outside,
        (root.resolve(),),
        "Temporary test files",
    )

    assert assessment.classification is FileClassification.REVIEW_REQUIRED
    assert assessment.policy_decision is CleanupPolicyDecision.REVIEW_REQUIRED
    assert "outside" in assessment.reason.casefold()


def test_reparse_point_is_skipped_and_does_not_escape_root(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    outside = root.parent / "outside.cache"
    outside.write_text("outside", encoding="utf-8")
    _set_file_dates(outside, access_days=60, modified_days=60)
    link = root / "escape.cache"
    try:
        link.symlink_to(outside)
    except (OSError, NotImplementedError):
        pytest.skip("This platform/user cannot create symbolic links")

    issues: list[ScanIssue] = []
    summary = _scan(_scanner(), root, issue_callback=issues.append)

    assert all(candidate.name != "escape.cache" for candidate in summary.candidates)
    assert summary.skipped_reparse_points >= 1
    assert any(
        issue.classification is FileClassification.REPARSE_POINT
        for issue in issues
    )


def test_reparse_root_is_rejected(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    outside = root.parent / "target-root"
    outside.mkdir()
    link = root.parent / "linked-root"
    try:
        link.symlink_to(outside, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("This platform/user cannot create directory symbolic links")

    summary = _scan(_scanner(), link)

    assert summary.scanned_roots == 0
    assert summary.skipped_reparse_points == 1
    assert summary.candidates == ()


def test_disappearing_file_is_counted_as_inaccessible(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, _ = cleanup_environment
    target = root / "vanishing.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=90, modified_days=90)
    scanner = _scanner()
    original = scanner._read_file_metadata

    def remove_during_scan(path: Path):
        if path == target:
            path.unlink()  # Only the isolated tmp_path fixture is modified.
        return original(path)

    monkeypatch.setattr(scanner, "_read_file_metadata", remove_during_scan)
    issues: list[ScanIssue] = []
    summary = _scan(scanner, root, issue_callback=issues.append)

    assert summary.candidates == ()
    assert summary.inaccessible_items == 1
    assert "disappeared" in issues[0].reason


def test_permission_denied_during_enumeration_is_counted(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, _ = cleanup_environment
    scanner = _scanner()
    original_scandir = os.scandir

    def denied_scandir(path: object):
        if Path(path) == root:
            raise PermissionError("simulated permission denial")
        return original_scandir(path)

    monkeypatch.setattr("zentry.core.scanner.os.scandir", denied_scandir)
    issues: list[ScanIssue] = []
    summary = _scan(scanner, root, issue_callback=issues.append)

    assert summary.candidates == ()
    assert summary.inaccessible_items == 1
    assert issues[0].classification is FileClassification.INACCESSIBLE
    assert "Permission was denied" in issues[0].reason


def test_configurable_age_threshold(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "twenty-days.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=20, modified_days=20)

    assert len(_scan(_scanner(), root, days=14).candidates) == 1
    assert _scan(_scanner(), root, days=21).candidates == ()


def test_default_threshold_and_reasonable_limits(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    scanner = _scanner()
    just_old_enough = root / "32-days.cache"
    just_too_recent = root / "30-days.cache"
    just_old_enough.write_text("old", encoding="utf-8")
    just_too_recent.write_text("recent", encoding="utf-8")
    _set_file_dates(just_old_enough, access_days=32, modified_days=32)
    _set_file_dates(just_too_recent, access_days=30, modified_days=30)

    assert DEFAULT_MIN_AGE_DAYS == 31
    default_summary = scanner.scan(
        [("Temporary test files", root)],
        now=NOW,
    )
    assert [item.name for item in default_summary.candidates] == ["32-days.cache"]

    with pytest.raises(ValueError):
        scanner.scan([("Temp", root)], min_age_days=0, now=NOW)
    with pytest.raises(ValueError):
        scanner.scan([("Temp", root)], min_age_days=3651, now=NOW)
    with pytest.raises(TypeError):
        scanner.scan([("Temp", root)], min_age_days=True, now=NOW)


def test_root_that_is_entire_profile_or_windows_tree_is_rejected(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    _, windows = cleanup_environment
    profile = Path(os.environ["USERPROFILE"])
    scanner = _scanner()

    profile_summary = _scan(scanner, profile)
    windows_summary = _scan(scanner, windows)

    assert profile_summary.scanned_roots == 0
    assert profile_summary.review_files == 1
    assert windows_summary.scanned_roots == 0
    assert windows_summary.review_files == 1


def test_progress_callback_failure_does_not_abort_scan(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "old.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=60, modified_days=60)

    def broken_progress(_message: str) -> None:
        raise RuntimeError("UI disconnected")

    summary = _scan(_scanner(), root, progress=broken_progress)
    assert len(summary.candidates) == 1


def test_unknown_classifier_contract_fails_closed(
    cleanup_environment: tuple[Path, Path],
) -> None:
    root, _ = cleanup_environment
    target = root / "old.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=60, modified_days=60)

    class LegacyClassifier:
        protected_rules = ()

        def classify_for_cleanup(self, *_args: object):
            return FileClassification.SAFE_CANDIDATE, "old API only"

    scanner = CleanupScanner(classifier=LegacyClassifier())  # type: ignore[arg-type]
    summary = _scan(scanner, root)

    assert summary.candidates == ()
    assert summary.review_files == 1


def test_metadata_permission_denied_excludes_candidate(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, _ = cleanup_environment
    target = root / "private-cache.cache"
    target.write_text("data", encoding="utf-8")
    _set_file_dates(target, access_days=90, modified_days=90)
    scanner = _scanner()

    def denied_metadata(_path: Path):
        raise PermissionError("simulated metadata denial")

    monkeypatch.setattr(scanner, "_read_file_metadata", denied_metadata)
    issues: list[ScanIssue] = []
    summary = _scan(scanner, root, issue_callback=issues.append)

    assert summary.candidates == ()
    assert summary.inaccessible_items == 1
    assert issues[0].classification is FileClassification.INACCESSIBLE
    assert "Permission was denied" in issues[0].reason


def test_file_changed_after_classification_is_excluded(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, _ = cleanup_environment
    target = root / "changes-during-scan.cache"
    target.write_text("old-data", encoding="utf-8")
    _set_file_dates(target, access_days=90, modified_days=90)
    scanner = _scanner()
    original_assess = scanner._assess_file
    called = False

    def mutate_after_assessment(
        path: Path,
        allowed_roots: tuple[Path, ...],
        category: str,
    ):
        nonlocal called
        assessment = original_assess(path, allowed_roots, category)
        if path == target and not called:
            called = True
            target.write_text("replacement-data", encoding="utf-8")
            _set_file_dates(target, access_days=1, modified_days=1)
        return assessment

    monkeypatch.setattr(scanner, "_assess_file", mutate_after_assessment)
    issues: list[ScanIssue] = []
    summary = _scan(scanner, root, issue_callback=issues.append)

    assert summary.candidates == ()
    assert summary.review_files == 1
    assert any("changed or was replaced" in issue.reason for issue in issues)


def test_recent_files_skip_full_stale_candidate_validation(
    cleanup_environment: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, _ = cleanup_environment
    target = root / "recent-large-cache.bin"
    target.write_bytes(b"recent content")
    _set_file_dates(target, access_days=1, modified_days=1)
    scanner = _scanner()

    def unexpected_full_validation(**_kwargs):
        raise AssertionError("Recent file should be skipped before stale-file validation")

    monkeypatch.setattr(scanner, "_inspect_stale_file", unexpected_full_validation)
    summary = _scan(scanner, root)

    assert summary.candidates == ()
    assert summary.review_files == 0
    assert summary.scanned_files == 1
