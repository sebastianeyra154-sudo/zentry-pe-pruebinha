from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import pytest

from zentry.models import (
    CleanupPolicyDecision,
    FileCandidate,
    FileClassification,
    FileFingerprint,
)


class RecordingProvider:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def collect_snapshot(self):
        self.calls.append("collect_snapshot")

    def scan_cleanup(self, *args, **kwargs):
        self.calls.append("scan_cleanup")

    def preview_cleanup(self, candidates):
        self.calls.append("preview_cleanup")

    def delete_files(self, *args, **kwargs):
        self.calls.append("delete_files")

    def scan_system_protection(self, *args, **kwargs):
        self.calls.append("scan_system_protection")

    def list_startup_entries(self):
        self.calls.append("list_startup_entries")

    def list_processes(self):
        self.calls.append("list_processes")


def _qt_modules():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        pytest.skip("PySide6 is not installed in this test environment")
    from zentry.ui import main_window

    return QApplication, main_window


def _candidate() -> FileCandidate:
    now = datetime.now(timezone.utc)
    return FileCandidate(
        path="C:/synthetic-temp/old.cache",
        name="old.cache",
        category="User temporary files",
        size_bytes=16,
        last_access=now,
        last_modified=now,
        classification=FileClassification.SAFE_CANDIDATE,
        reason="Synthetic approved candidate for GUI integration testing.",
        policy_decision=CleanupPolicyDecision.ALLOW,
        fingerprint=FileFingerprint(
            size_bytes=16,
            accessed_ns=1,
            modified_ns=1,
            device_id=1,
            file_id=1,
        ),
    )


def test_window_open_does_not_start_diagnostics_or_cleanup(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    QApplication, main_window = _qt_modules()
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main_window, "get_app_data_directory", lambda: tmp_path)
    provider = RecordingProvider()
    window = main_window.MainWindow(provider=provider)
    try:
        assert window._pages.count() == 7
        assert provider.calls == []
    finally:
        window.close()
        app.processEvents()


def test_cleanup_preview_is_submitted_to_worker_not_called_synchronously(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    QApplication, main_window = _qt_modules()
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main_window, "get_app_data_directory", lambda: tmp_path)
    provider = RecordingProvider()
    window = main_window.MainWindow(provider=provider)
    candidate = _candidate()
    submitted: dict[str, object] = {}

    def fake_run_worker(
        task_key: str,
        func: Callable[[Callable[[str], None]], object],
        callback: Callable[[object], None],
    ) -> bool:
        submitted.update(task_key=task_key, func=func, callback=callback)
        return True

    monkeypatch.setattr(window, "_selected_cleanup_candidates", lambda: [candidate])
    monkeypatch.setattr(window, "_run_worker", fake_run_worker)
    monkeypatch.setattr(window, "_show_message_box", lambda *args, **kwargs: "cancel")
    try:
        window._confirm_cleanup()
        assert submitted["task_key"] == "cleanup"
        assert "preview_cleanup" not in provider.calls

        # Invoking the callable captured by the worker is the first time the
        # provider preview method executes; the click handler itself did not call it.
        submitted["func"](lambda _message: None)
        assert provider.calls == ["preview_cleanup"]
    finally:
        window._cleanup_previewing = False
        window._pending_cleanup_candidates = ()
        window.close()
        app.processEvents()
