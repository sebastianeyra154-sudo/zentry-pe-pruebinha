from __future__ import annotations

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def read_project_file(relative_path: str) -> str:
    return (PROJECT_ROOT / relative_path).read_text(encoding="utf-8")


def test_build_dependencies_are_directly_pinned_and_compatible() -> None:
    requirements = read_project_file("requirements.txt")
    development = read_project_file("requirements-dev.txt")

    assert "PySide6>=6.8,<7" in requirements
    assert "psutil>=7.0,<8" in requirements
    assert "send2trash>=1.8,<2" in requirements
    assert "-r requirements.txt" in development
    assert "PySide6==6.12.0" in development
    assert "psutil==7.2.2" in development
    assert "send2trash==1.8.3" in development
    assert "pytest==9.1.1" in development
    assert "PyInstaller==6.22.3" in development


def test_build_scripts_use_local_venv_run_tests_and_verify_exe() -> None:
    batch = read_project_file("build_windows.bat")
    powershell = read_project_file("build_windows.ps1")

    for script in (batch, powershell):
        assert "requirements-dev.txt" in script
        assert "-m PyInstaller" in script or "'-m', 'PyInstaller'" in script
        assert "-m', 'pytest'" in script or "-m pytest" in script
        assert "Zentry.exe" in script
        assert "--onefile" in script
        assert "--windowed" in script
        assert "compileall" in script
        assert "pip" in script

    assert "VENV_PYTHON" in batch
    assert "$venvPython" in powershell
    assert 'if not exist "%EXE_PATH%" goto :exe_error' in batch
    assert 'if "%EXE_SIZE%"=="0" goto :exe_error' in batch
    assert 'if ($exe.Length -le 0)' in powershell


def test_build_does_not_change_execution_policy_or_elevate() -> None:
    batch = read_project_file("build_windows.bat").casefold()
    powershell = read_project_file("build_windows.ps1").casefold()

    for script in (batch, powershell):
        assert "set-executionpolicy" not in script
        assert "-executionpolicy bypass" not in script
        assert "-verb runas" not in script


def test_qt_plugins_are_not_force_collected_and_fatal_errors_are_visible() -> None:
    batch = read_project_file("build_windows.bat")
    powershell = read_project_file("build_windows.ps1")

    assert "--collect-all PySide6" not in batch
    assert "--collect-all', 'PySide6'" not in powershell
    assert "PyInstaller" in batch and "if errorlevel 1 goto :build_error" in batch
    assert "codigo de salida" in powershell
    assert "Start-Transcript" in powershell


def test_workflow_builds_on_windows_with_minimal_permissions_and_artifacts() -> None:
    workflow = read_project_file(".github/workflows/build-windows.yml")

    assert "runs-on: windows-latest" in workflow
    assert "python-version: '3.12'" in workflow
    assert "uses: actions/checkout@v7" in workflow
    assert "uses: actions/setup-python@v7" in workflow
    assert "uses: actions/upload-artifact@v7" in workflow
    assert "permissions:\n  contents: read" in workflow
    assert "branches:\n      - main\n      - master\n    tags:\n      - 'v*'" in workflow
    assert "path: dist/Zentry.exe" in workflow
    assert "if: always()" in workflow
    assert ".build-logs/*.log" in workflow
    assert "Smoke-test packaged executable startup" in workflow
