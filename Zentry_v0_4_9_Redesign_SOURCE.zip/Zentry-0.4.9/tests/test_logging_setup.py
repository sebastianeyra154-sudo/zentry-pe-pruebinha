from __future__ import annotations

import io
import logging
from pathlib import Path

import pytest

import zentry.core.logging_setup as logging_module
from zentry.core.logging_setup import configure_logging, log_safe_exception


@pytest.fixture(autouse=True)
def reset_zentry_logger() -> None:
    logger = logging.getLogger("zentry")
    old_propagate = logger.propagate
    old_level = logger.level
    yield
    for handler in tuple(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    logger.propagate = old_propagate
    logger.setLevel(old_level)


def test_configure_logging_uses_rotating_file_and_bounded_backups(tmp_path: Path) -> None:
    log_path = configure_logging(data_directory=tmp_path, max_bytes=250, backup_count=2)
    assert log_path == tmp_path / "logs" / "zentry.log"

    logger = logging.getLogger("zentry.test")
    for index in range(40):
        logger.info("diagnostic_event=%d result=partial", index)

    assert log_path.exists()
    log_files = list(log_path.parent.glob("zentry.log*"))
    assert len(log_files) <= 3
    assert all(item.stat().st_size > 0 for item in log_files)


def test_exception_logging_excludes_private_message_and_traceback(tmp_path: Path) -> None:
    log_path = configure_logging(data_directory=tmp_path)
    assert log_path is not None
    secret_path = r"C:\Users\Alice\Private\token.txt"
    secret_argument = "api-token-super-secret"
    try:
        raise ValueError(f"failed at {secret_path}; argument={secret_argument}")
    except ValueError as exc:
        event_id = log_safe_exception(logging.getLogger("zentry.worker"), "worker_failed", exc)

    log_text = "\n".join(
        item.read_text(encoding="utf-8")
        for item in log_path.parent.glob("zentry.log*")
    )
    assert event_id in log_text
    assert "worker_failed" in log_text
    assert "ValueError" in log_text
    assert secret_path not in log_text
    assert secret_argument not in log_text
    assert "Traceback" not in log_text


def test_file_logging_permission_failure_falls_back_without_raising(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fallback_stream = io.StringIO()
    monkeypatch.setattr(logging_module.sys, "stderr", fallback_stream)

    class DeniedHandler:
        def __init__(self, *args: object, **kwargs: object) -> None:
            raise PermissionError("path must not be logged")

    monkeypatch.setattr(logging_module, "RotatingFileHandler", DeniedHandler)
    result = configure_logging(data_directory=tmp_path)
    assert result is None
    assert "permission_denied" in fallback_stream.getvalue()
    assert "path must not be logged" not in fallback_stream.getvalue()


def test_log_configuration_rejects_invalid_rotation_values(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="max_bytes"):
        configure_logging(data_directory=tmp_path, max_bytes=0)
    with pytest.raises(ValueError, match="backup_count"):
        configure_logging(data_directory=tmp_path, backup_count=-1)
