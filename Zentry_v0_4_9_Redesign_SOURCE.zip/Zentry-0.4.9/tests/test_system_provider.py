from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import psutil
import pytest

import zentry.providers.system as system_module
from zentry.models import StartupEntry, SystemSnapshot
from zentry.providers.system import (
    DiagnosticCollectionError,
    DiagnosticStatus,
    DiskVolumeDiagnostics,
    MemoryDiagnostics,
    MetricResult,
    StartupDiagnostics,
    SystemDiagnosticsProvider,
)


@pytest.fixture

def provider() -> SystemDiagnosticsProvider:
    return SystemDiagnosticsProvider(cpu_sample_interval=0.1)


def test_dashboard_activity_sampler_returns_real_nonblocking_percentages(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    observed: list[object] = []

    def fake_cpu_percent(interval=None):
        observed.append(interval)
        return 27.5

    monkeypatch.setattr(system_module.psutil, "cpu_percent", fake_cpu_percent)
    monkeypatch.setattr(
        system_module.psutil,
        "virtual_memory",
        lambda: SimpleNamespace(percent=62.5),
    )

    assert provider.sample_activity() == (27.5, 62.5)
    assert observed == [None]


def test_dashboard_activity_sampler_preserves_unknown_values(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    def fail_cpu(_interval=None):
        raise OSError("unavailable")

    monkeypatch.setattr(system_module.psutil, "cpu_percent", fail_cpu)
    monkeypatch.setattr(
        system_module.psutil,
        "virtual_memory",
        lambda: SimpleNamespace(percent=float("nan")),
    )

    assert provider.sample_activity() == (None, None)



def test_cpu_usage_returns_the_sampled_value(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    seen: dict[str, float] = {}

    def fake_cpu_percent(interval: float) -> float:
        seen["interval"] = interval
        return 27.5

    monkeypatch.setattr(system_module.psutil, "cpu_percent", fake_cpu_percent)

    result = provider.collect_cpu_usage()

    assert result.status is DiagnosticStatus.AVAILABLE
    assert result.value == 27.5
    assert seen["interval"] == pytest.approx(0.1)


def test_memory_metrics_return_total_available_and_usage(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(
        system_module.psutil,
        "virtual_memory",
        lambda: SimpleNamespace(total=32_000, available=12_000, percent=62.5),
    )

    result = provider.collect_memory_metrics()

    assert result.status is DiagnosticStatus.AVAILABLE
    assert result.value == MemoryDiagnostics(32_000, 12_000, 62.5)


def test_disk_volume_metrics_return_byte_counts_for_each_mount(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    partitions = [
        SimpleNamespace(device="C:", mountpoint="C:\\", fstype="NTFS"),
        SimpleNamespace(device="D:", mountpoint="D:\\", fstype="NTFS"),
    ]
    usage_by_mount = {
        "C:\\": SimpleNamespace(total=1_000, used=700, free=300, percent=70.0),
        "D:\\": SimpleNamespace(total=2_000, used=500, free=1_500, percent=25.0),
    }
    monkeypatch.setattr(system_module.psutil, "disk_partitions", lambda all=False: partitions)
    monkeypatch.setattr(
        system_module.psutil,
        "disk_usage",
        lambda mountpoint: usage_by_mount[mountpoint],
    )

    result = provider.collect_disk_volumes()

    assert result.status is DiagnosticStatus.AVAILABLE
    assert result.value is not None
    assert [(item.total_bytes, item.used_bytes, item.free_bytes) for item in result.value] == [
        (1_000, 700, 300),
        (2_000, 500, 1_500),
    ]


def test_process_count_returns_exact_mocked_count(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(system_module.psutil, "pids", lambda: [1, 2, 3, 4])

    result = provider.collect_process_count()

    assert result.status is DiagnosticStatus.AVAILABLE
    assert result.value == 4


def test_cpu_permission_error_is_explicitly_reported(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    def denied_cpu_percent(interval: float) -> float:
        del interval
        raise psutil.AccessDenied()

    monkeypatch.setattr(system_module.psutil, "cpu_percent", denied_cpu_percent)

    result = provider.collect_cpu_usage()

    assert result.status is DiagnosticStatus.PERMISSION_DENIED
    assert result.value is None
    assert result.error_code == "access_denied"

def test_memory_metrics_preserve_unknown_fields(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(
        system_module.psutil,
        "virtual_memory",
        lambda: SimpleNamespace(total=16_000, available=None, percent=50.0),
    )

    result = provider.collect_memory_metrics()

    assert result.status is DiagnosticStatus.PARTIAL
    assert result.value is not None
    assert result.value.total_bytes == 16_000
    assert result.value.available_bytes is None
    assert result.value.used_percent == 50.0


def test_cpu_invalid_value_is_unavailable_not_zero(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(system_module.psutil, "cpu_percent", lambda interval: None)

    result = provider.collect_cpu_usage()

    assert result.status is DiagnosticStatus.UNAVAILABLE
    assert result.value is None
    assert result.error_code == "invalid_or_unavailable_value"


def test_disk_volumes_keep_per_volume_permission_errors(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    partitions = [
        SimpleNamespace(device="C:", mountpoint="C:\\", fstype="NTFS"),
        SimpleNamespace(device="D:", mountpoint="D:\\", fstype="NTFS"),
    ]
    monkeypatch.setattr(system_module.psutil, "disk_partitions", lambda all=False: partitions)

    def fake_disk_usage(mountpoint: str) -> Any:
        if mountpoint == "D:\\":
            raise PermissionError("private path deliberately omitted")
        return SimpleNamespace(total=1_000, used=600, free=400, percent=60.0)

    monkeypatch.setattr(system_module.psutil, "disk_usage", fake_disk_usage)

    result = provider.collect_disk_volumes()

    assert result.status is DiagnosticStatus.PARTIAL
    assert result.value is not None
    assert len(result.value) == 2
    assert result.value[0].total_bytes == 1_000
    assert result.value[1].status is DiagnosticStatus.PERMISSION_DENIED
    assert result.value[1].total_bytes is None
    assert result.value[1].free_bytes is None


def test_process_count_failure_is_unknown(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    def fail_pids() -> list[int]:
        raise psutil.AccessDenied()

    monkeypatch.setattr(system_module.psutil, "pids", fail_pids)

    result = provider.collect_process_count()

    assert result.status is DiagnosticStatus.PERMISSION_DENIED
    assert result.value is None
    assert result.error_code == "access_denied"


class FakeProcess:
    def __init__(
        self,
        pid: int,
        name: str,
        memory_percent: float | None,
        status: str | None = "running",
        cpu_samples: tuple[float, ...] = (0.0, 12.5),
    ) -> None:
        self.pid = pid
        self._name = name
        self._memory_percent = memory_percent
        self._status = status
        self._cpu_samples = list(cpu_samples)

    def as_dict(self, attrs: list[str], ad_value: object = None) -> dict[str, object]:
        return {
            "name": self._name,
            "memory_percent": self._memory_percent,
            "status": self._status,
        }

    def cpu_percent(self, interval: float | None = None) -> float:
        if self._cpu_samples:
            return self._cpu_samples.pop(0)
        return 12.5


def test_process_details_sample_cpu_and_keep_unknown_ram(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    processes = [
        FakeProcess(101, "complete.exe", 4.0),
        FakeProcess(102, "partial.exe", None),
    ]
    monkeypatch.setattr(system_module.psutil, "process_iter", lambda: iter(processes))
    monkeypatch.setattr(system_module.time, "sleep", lambda _interval: None)

    result = provider.collect_process_details(limit=20, sample_interval=0.1)

    assert result.status is DiagnosticStatus.PARTIAL
    assert result.observed_count == 2
    complete = next(item for item in result.processes if item.pid == 101)
    partial = next(item for item in result.processes if item.pid == 102)
    assert complete.cpu_percent == 12.5
    assert complete.memory_percent == 4.0
    assert partial.cpu_percent == 12.5
    assert partial.memory_percent is None
    assert partial.availability is DiagnosticStatus.PARTIAL



def test_process_permission_error_is_preserved_as_unknown_metrics(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    class DeniedProcess(FakeProcess):
        def as_dict(self, attrs: list[str], ad_value: object = None) -> dict[str, object]:
            del attrs, ad_value
            raise psutil.AccessDenied(self.pid)

    process = DeniedProcess(404, "protected.exe", 1.0)
    monkeypatch.setattr(system_module.psutil, "process_iter", lambda: iter([process]))
    monkeypatch.setattr(system_module.time, "sleep", lambda _interval: None)

    result = provider.collect_process_details(sample_interval=0.1)

    assert result.status is DiagnosticStatus.PARTIAL
    assert result.inaccessible_count == 1
    assert len(result.processes) == 1
    assert result.processes[0].pid == 404
    assert result.processes[0].cpu_percent is None
    assert result.processes[0].memory_percent is None
    assert result.processes[0].availability is DiagnosticStatus.PERMISSION_DENIED

def test_process_that_disappears_during_sampling_is_omitted(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    class DisappearingProcess(FakeProcess):
        def cpu_percent(self, interval: float | None = None) -> float:
            if self._cpu_samples:
                self._cpu_samples.pop(0)
                return 0.0
            raise psutil.NoSuchProcess(self.pid)

    process = DisappearingProcess(303, "gone.exe", 2.0, cpu_samples=(0.0,))
    monkeypatch.setattr(system_module.psutil, "process_iter", lambda: iter([process]))
    monkeypatch.setattr(system_module.time, "sleep", lambda _interval: None)

    result = provider.collect_process_details(sample_interval=0.1)

    assert result.status is DiagnosticStatus.PARTIAL
    assert result.disappeared_count == 1
    assert result.processes == ()


class FakeRegistry:
    HKEY_CURRENT_USER = 1
    HKEY_LOCAL_MACHINE = 2
    KEY_READ = 0x20019
    KEY_WOW64_32KEY = 0x0200
    KEY_WOW64_64KEY = 0x0100

    @dataclass
    class Key:
        hive: int
        path: str
        access: int

        def __enter__(self) -> "FakeRegistry.Key":
            return self

        def __exit__(self, *_args: object) -> None:
            return None

    @classmethod
    def OpenKey(
        cls,
        hive: int,
        path: str,
        reserved: int,
        access: int,
    ) -> "FakeRegistry.Key":
        del reserved
        return cls.Key(hive=hive, path=path, access=access)

    @staticmethod
    def QueryInfoKey(key: "FakeRegistry.Key") -> tuple[int, int, int]:
        if (
            key.hive == FakeRegistry.HKEY_CURRENT_USER
            and key.path.endswith("\\Run")
            and not (key.access & FakeRegistry.KEY_WOW64_32KEY)
        ):
            return 0, 1, 0
        return 0, 0, 0

    @staticmethod
    def EnumValue(key: "FakeRegistry.Key", index: int) -> tuple[str, str, int]:
        if index != 0:
            raise OSError("no such value")
        return "ExampleApp", r"C:\Program Files\Example\example.exe", 1


def test_startup_inventory_reads_registry_and_startup_folders_only(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
    tmp_path,
) -> None:
    user_startup = tmp_path / "user-startup"
    user_startup.mkdir()
    (user_startup / "example.lnk").write_text("placeholder", encoding="utf-8")
    monkeypatch.setattr(system_module, "winreg", FakeRegistry)
    monkeypatch.setenv("APPDATA", str(tmp_path))
    monkeypatch.setenv("ProgramData", str(tmp_path / "not-present"))
    monkeypatch.setattr(
        provider,
        "_registry_queries",
        lambda _registry: (
            (
                FakeRegistry.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                "HKCU Run (native view)",
                0,
            ),
        ),
    )
    monkeypatch.setattr(
        provider,
        "_startup_directories",
        lambda: (("Test Startup folder", user_startup),),
    )

    result = provider.collect_startup_diagnostics()

    assert result.status is DiagnosticStatus.AVAILABLE
    assert any(item.name == "ExampleApp" for item in result.entries)



def test_registry_queries_are_read_only_and_cover_both_64_bit_views(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("PROCESSOR_ARCHITECTURE", "AMD64")
    monkeypatch.delenv("PROCESSOR_ARCHITEW6432", raising=False)

    queries = SystemDiagnosticsProvider._registry_queries(FakeRegistry)

    assert len(queries) == 8
    assert {item[3] for item in queries} == {
        FakeRegistry.KEY_WOW64_32KEY,
        FakeRegistry.KEY_WOW64_64KEY,
    }
    assert all("Run" in item[1] for item in queries)


def test_registry_access_denied_is_not_reported_as_empty(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    class DeniedRegistry(FakeRegistry):
        @classmethod
        def OpenKey(
            cls,
            hive: int,
            path: str,
            reserved: int,
            access: int,
        ) -> FakeRegistry.Key:
            del cls, hive, path, reserved, access
            raise PermissionError("registry access denied")

    monkeypatch.setattr(system_module, "winreg", DeniedRegistry)
    monkeypatch.delenv("APPDATA", raising=False)
    monkeypatch.delenv("ProgramData", raising=False)

    result = provider.collect_startup_diagnostics()

    assert result.status is DiagnosticStatus.PERMISSION_DENIED
    assert result.entries == ()
    assert result.permission_denied_sources == result.inaccessible_sources
    assert result.error_code == "access_denied"

def test_startup_registry_unavailable_is_not_reported_as_empty(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(system_module, "winreg", None)
    monkeypatch.delenv("APPDATA", raising=False)
    monkeypatch.delenv("ProgramData", raising=False)

    result = provider.collect_startup_diagnostics()

    assert result.status is DiagnosticStatus.UNAVAILABLE
    assert result.entries == ()
    assert result.error_code == "windows_registry_unavailable"


def _snapshot(
    *,
    cpu: float = 50.0,
    memory: float = 50.0,
    disk: float = 50.0,
    startup_count: int = 0,
    startup_high_impact_count: int = 0,
) -> SystemSnapshot:
    from datetime import datetime

    return SystemSnapshot(
        cpu_percent=cpu,
        memory_percent=memory,
        disk_percent=disk,
        disk_free_gb=100.0,
        startup_count=startup_count,
        startup_high_impact_count=startup_high_impact_count,
        process_count=100,
        collected_at=datetime.now().astimezone(),
    )


def test_health_score_is_a_documented_heuristic_not_a_measurement() -> None:
    baseline = _snapshot()
    threshold_case = _snapshot(
        cpu=95.0,
        memory=85.0,
        disk=96.0,
        startup_count=4,
        startup_high_impact_count=1,
    )

    assert baseline.health_score == 100
    # Formula: CPU -25 at >=90, RAM -12 at >=80, disk -25 at >=95,
    # and startup estimate -3 per estimated high-impact item (capped at -15).
    assert threshold_case.health_score == 35



def test_legacy_snapshot_uses_real_mocked_metrics_and_existing_contract(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(
        provider,
        "collect_cpu_usage",
        lambda: MetricResult(25.0, DiagnosticStatus.AVAILABLE),
    )
    monkeypatch.setattr(
        provider,
        "collect_memory_metrics",
        lambda: MetricResult(
            MemoryDiagnostics(16 * 1024**3, 8 * 1024**3, 50.0),
            DiagnosticStatus.AVAILABLE,
        ),
    )
    volume = DiskVolumeDiagnostics(
        device="C:",
        mountpoint="C:\\",
        filesystem="NTFS",
        total_bytes=500 * 1024**3,
        used_bytes=200 * 1024**3,
        free_bytes=300 * 1024**3,
        used_percent=40.0,
        status=DiagnosticStatus.AVAILABLE,
    )
    monkeypatch.setattr(
        provider,
        "collect_disk_volumes",
        lambda: MetricResult((volume,), DiagnosticStatus.AVAILABLE),
    )
    monkeypatch.setattr(
        provider,
        "collect_process_count",
        lambda: MetricResult(123, DiagnosticStatus.AVAILABLE),
    )
    startup_entries = tuple(
        StartupEntry(name=f"Entry {index}", command="command", source="HKCU Run")
        for index in range(8)
    )
    monkeypatch.setattr(
        provider,
        "collect_startup_diagnostics",
        lambda: StartupDiagnostics(startup_entries, DiagnosticStatus.AVAILABLE, 4),
    )
    monkeypatch.setenv("SystemDrive", "C:")

    snapshot = provider.collect_snapshot()

    assert snapshot.cpu_percent == 25.0
    assert snapshot.memory_percent == 50.0
    assert snapshot.disk_percent == 40.0
    assert snapshot.disk_free_gb == pytest.approx(300.0)
    assert snapshot.startup_count == 8
    assert snapshot.startup_high_impact_count == 2
    assert snapshot.process_count == 123
    # This score is a fixed-threshold heuristic and not a scientific measurement.
    assert snapshot.health_score == 94

def test_legacy_snapshot_raises_instead_of_substituting_unknown_with_zero(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(
        provider,
        "collect_cpu_usage",
        lambda: MetricResult(None, DiagnosticStatus.UNAVAILABLE, "cpu_unavailable"),
    )
    monkeypatch.setattr(
        provider,
        "collect_memory_metrics",
        lambda: MetricResult(
            MemoryDiagnostics(100, 50, 50.0),
            DiagnosticStatus.AVAILABLE,
        ),
    )
    volume = DiskVolumeDiagnostics(
        device="C:",
        mountpoint="C:\\",
        filesystem="NTFS",
        total_bytes=100,
        used_bytes=50,
        free_bytes=50,
        used_percent=50.0,
        status=DiagnosticStatus.AVAILABLE,
    )
    monkeypatch.setattr(
        provider,
        "collect_disk_volumes",
        lambda: MetricResult((volume,), DiagnosticStatus.AVAILABLE),
    )
    monkeypatch.setattr(
        provider,
        "collect_process_count",
        lambda: MetricResult(10, DiagnosticStatus.AVAILABLE),
    )
    monkeypatch.setattr(
        provider,
        "collect_startup_diagnostics",
        lambda: StartupDiagnostics((), DiagnosticStatus.AVAILABLE, 4),
    )
    monkeypatch.setenv("SystemDrive", "C:")

    with pytest.raises(DiagnosticCollectionError, match="cpu_unavailable"):
        provider.collect_snapshot()


def test_detailed_report_keeps_each_metric_independent(
    monkeypatch: pytest.MonkeyPatch,
    provider: SystemDiagnosticsProvider,
) -> None:
    monkeypatch.setattr(
        provider,
        "collect_cpu_usage",
        lambda: MetricResult(None, DiagnosticStatus.UNAVAILABLE, "cpu_unavailable"),
    )
    monkeypatch.setattr(
        provider,
        "collect_memory_metrics",
        lambda: MetricResult(MemoryDiagnostics(100, 40, 60.0), DiagnosticStatus.AVAILABLE),
    )
    monkeypatch.setattr(
        provider,
        "collect_disk_volumes",
        lambda: MetricResult((), DiagnosticStatus.PARTIAL, "one_volume_missing"),
    )
    monkeypatch.setattr(
        provider,
        "collect_process_count",
        lambda: MetricResult(2, DiagnosticStatus.AVAILABLE),
    )
    monkeypatch.setattr(
        provider,
        "collect_startup_diagnostics",
        lambda: StartupDiagnostics((), DiagnosticStatus.AVAILABLE, 4),
    )

    report = provider.collect_diagnostics()

    assert report.cpu_percent.value is None
    assert report.cpu_percent.status is DiagnosticStatus.UNAVAILABLE
    assert report.memory.value is not None
    assert report.memory.value.total_bytes == 100
    assert report.process_count.value == 2
    assert report.startup.status is DiagnosticStatus.AVAILABLE


def test_provider_registers_scan_and_requires_confirmation_for_cleanup(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from datetime import datetime, timedelta, timezone

    from zentry.core.cleanup import CleanupConfirmationRequired

    root = tmp_path / "approved-temp"
    root.mkdir()
    windows = tmp_path / "Windows"
    windows.mkdir()
    program_files = tmp_path / "Program Files"
    program_files.mkdir()
    profile = tmp_path / "profile"
    profile.mkdir()
    monkeypatch.setenv("SystemRoot", str(windows))
    monkeypatch.setenv("SystemDrive", str(tmp_path))
    monkeypatch.setenv("ProgramFiles", str(program_files))
    monkeypatch.setenv("ProgramFiles(x86)", str(program_files))
    monkeypatch.setenv("ProgramW6432", str(program_files))
    monkeypatch.setenv("USERPROFILE", str(profile))
    monkeypatch.setenv("LOCALAPPDATA", str(profile / "AppData" / "Local"))
    monkeypatch.setenv("APPDATA", str(profile / "AppData" / "Roaming"))
    monkeypatch.setattr(
        system_module,
        "default_cleanup_roots",
        lambda: [("Provider test temp", root)],
    )

    target = root / "provider-old.cache"
    target.write_bytes(b"provider cleanup contract")
    old = (datetime.now(timezone.utc) - timedelta(days=45)).timestamp()
    os.utime(target, (old, old))

    provider = SystemDiagnosticsProvider(cpu_sample_interval=0.1)
    summary = provider.scan_cleanup(min_age_days=31)
    assert len(summary.candidates) == 1
    candidate = summary.candidates[0]

    with pytest.raises(CleanupConfirmationRequired):
        provider.delete_files([candidate], min_age_days=31)

    assert target.exists()

    import zentry.core.cleanup as cleanup_module

    trash_dir = tmp_path / "provider-test-trash"
    trash_dir.mkdir()

    def fake_trash(raw_path: str) -> None:
        Path(raw_path).rename(trash_dir / Path(raw_path).name)

    monkeypatch.setattr(cleanup_module, "send2trash", fake_trash)
    result = provider.delete_files(
        [candidate], min_age_days=31, confirmed=True
    )
    assert result.moved_files == 1
    assert not target.exists()
    assert (trash_dir / target.name).exists()
