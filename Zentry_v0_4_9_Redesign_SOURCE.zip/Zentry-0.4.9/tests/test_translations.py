from __future__ import annotations

import ast
import os
import string
from collections import Counter
from pathlib import Path

import pytest

from zentry.core.history import HistoryOperation, HistoryResult


PROJECT_ROOT = Path(__file__).parents[1]
UI_SOURCE_PATH = PROJECT_ROOT / "zentry" / "ui" / "main_window.py"


def _source_tree() -> ast.Module:
    return ast.parse(UI_SOURCE_PATH.read_text(encoding="utf-8"))


def _translations_node(tree: ast.Module) -> ast.Dict:
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        if any(isinstance(target, ast.Name) and target.id == "TRANSLATIONS" for target in node.targets):
            assert isinstance(node.value, ast.Dict)
            return node.value
    raise AssertionError("TRANSLATIONS dictionary was not found")


def _translation_catalog(tree: ast.Module | None = None) -> dict[str, dict[str, str]]:
    module = tree if tree is not None else _source_tree()
    return ast.literal_eval(_translations_node(module))


def _class_and_method(tree: ast.Module, class_name: str, method_name: str) -> ast.FunctionDef:
    class_node = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == class_name
    )
    return next(
        node for node in class_node.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == method_name
    )


def test_cleanup_navigation_label_is_concise_without_changing_page_title() -> None:
    translations = _translation_catalog()
    assert translations["es"]["cleanup_nav"] == "Limpieza segura"
    assert translations["en"]["cleanup_nav"] == "Cleanup"
    assert translations["en"]["cleanup"] == "Safe cleanup"


def test_navigation_labels_are_short_without_changing_page_titles() -> None:
    translations = _translation_catalog()
    assert translations["en"]["startup_nav"] == "Startup"
    assert translations["en"]["startup"] == "Windows startup"
    assert translations["en"]["system_protection_nav"] == "System protection"
    assert translations["en"]["system_protection"] == "Windows protection"


def test_navigation_uses_concise_label_keys_on_build_and_language_toggle() -> None:
    tree = _source_tree()
    expected = (
        "overview", "diagnostics", "cleanup_nav", "startup_nav", "processes",
        "history", "system_protection_nav",
    )
    sidebar_method = _class_and_method(tree, "MainWindow", "_build_sidebar")
    retranslate_method = _class_and_method(tree, "MainWindow", "_retranslate_ui")

    def assigned_tuple(method: ast.FunctionDef, name: str) -> tuple[str, ...]:
        for node in ast.walk(method):
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == name
                for target in node.targets
            ):
                value = ast.literal_eval(node.value)
                assert isinstance(value, tuple)
                return value
        raise AssertionError(f"Expected {name} tuple in {method.name}")

    assert assigned_tuple(sidebar_method, "navigation_keys") == expected
    assert assigned_tuple(retranslate_method, "nav_keys") == expected


def test_translation_catalog_has_no_duplicate_keys() -> None:
    node = _translations_node(_source_tree())
    for language_node in node.values:
        assert isinstance(language_node, ast.Dict)
        keys = [
            key.value
            for key in language_node.keys
            if isinstance(key, ast.Constant) and isinstance(key.value, str)
        ]
        duplicates = sorted(key for key, count in Counter(keys).items() if count > 1)
        assert not duplicates, f"Duplicate translation keys: {duplicates}"


def test_every_translation_key_exists_in_both_languages_and_is_non_empty() -> None:
    translations = _translation_catalog()
    assert set(translations) == {"es", "en"}
    assert set(translations["es"]) == set(translations["en"])
    for language, catalog in translations.items():
        for key, value in catalog.items():
            assert isinstance(value, str), f"{language}.{key} is not text"
            assert value.strip(), f"{language}.{key} is empty"


def test_format_placeholders_match_between_languages() -> None:
    translations = _translation_catalog()
    formatter = string.Formatter()

    def placeholders(template: str) -> set[str]:
        return {
            field_name.split(".")[0].split("[")[0]
            for _, field_name, _, _ in formatter.parse(template)
            if field_name is not None
        }

    for key in translations["es"]:
        assert placeholders(translations["es"][key]) == placeholders(
            translations["en"][key]
        ), f"Placeholder mismatch for {key}"


def test_all_literal_translation_lookups_resolve() -> None:
    tree = _source_tree()
    translations = _translation_catalog(tree)
    referenced: set[str] = set()

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute) or node.func.attr != "_t":
            continue
        if node.args and isinstance(node.args[0], ast.Constant):
            if isinstance(node.args[0].value, str):
                referenced.add(node.args[0].value)

    # These values are passed dynamically, but their complete finite sets are known.
    referenced.update(("history_clear_done", "history_clear_missing"))
    referenced.update(f"history_op_{item.value}" for item in HistoryOperation)
    referenced.update(f"history_result_{item.value}" for item in HistoryResult)
    referenced.update(("ok", "cancel", "continue", "delete"))
    referenced.update(("cleanup_action", "cleanup_desc", "system_action", "system_desc"))
    referenced.update(
        (
            "category_user_temp", "category_windows_temp", "category_chrome_cache",
            "category_edge_cache", "category_firefox_cache", "category_unknown",
        )
    )
    referenced.update(
        f"process_status_{status}"
        for status in (
            "running", "sleeping", "stopped", "zombie", "dead", "idle", "waiting", "unknown"
        )
    )

    missing = sorted(referenced - set(translations["es"]))
    assert not missing, f"Translation lookups reference missing keys: {missing}"


def test_live_activity_state_is_initialized_before_initial_ui_render() -> None:
    tree = _source_tree()
    init = _class_and_method(tree, "MainWindow", "__init__")

    def statement_index_for_attribute(attribute: str) -> int:
        for index, statement in enumerate(init.body):
            if isinstance(statement, (ast.Assign, ast.AnnAssign)):
                targets = statement.targets if isinstance(statement, ast.Assign) else [statement.target]
                if any(
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "self"
                    and target.attr == attribute
                    for target in targets
                ):
                    return index
        raise AssertionError(f"self.{attribute} is not initialized directly in __init__")

    def call_index(method_name: str) -> int:
        for index, statement in enumerate(init.body):
            if any(
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "self"
                and node.func.attr == method_name
                for node in ast.walk(statement)
            ):
                return index
        raise AssertionError(f"self.{method_name}() is not called directly in __init__")

    activity_index = statement_index_for_attribute("_latest_activity")
    assert activity_index < call_index("_build_ui")
    assert activity_index < call_index("_retranslate_ui")


def test_retranslation_attributes_are_initialized_or_explicitly_dynamic() -> None:
    tree = _source_tree()
    class_node = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
    )
    method_names = {
        node.name for node in class_node.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    assigned: set[str] = set()
    for node in ast.walk(class_node):
        target = None
        if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for candidate in targets:
                if isinstance(candidate, ast.Attribute) and isinstance(candidate.value, ast.Name):
                    if candidate.value.id == "self":
                        assigned.add(candidate.attr)
                elif isinstance(candidate, (ast.Tuple, ast.List)):
                    for element in candidate.elts:
                        if isinstance(element, ast.Attribute) and isinstance(element.value, ast.Name) and element.value.id == "self":
                            assigned.add(element.attr)

    dynamic_attributes = {
        # Created by _make_action_card using setattr(self, f"_{title_key}", ...).
        "_cleanup_action", "_cleanup_desc", "_cleanup_action_button",
        "_system_action", "_system_desc", "_system_action_button",
    }
    relevant_methods = (
        "_retranslate_ui", "_apply_table_headers", "_render_snapshot",
        "_render_diagnostic_snapshot", "_render_protection_result",
        "_render_cleanup_state", "_render_startup_entries", "_render_process_entries",
        "_refresh_history",
    )
    referenced: set[str] = set()
    for method_name in relevant_methods:
        method = _class_and_method(tree, "MainWindow", method_name)
        for node in ast.walk(method):
            if (
                isinstance(node, ast.Attribute)
                and isinstance(node.value, ast.Name)
                and node.value.id == "self"
                and node.attr.startswith("_")
                and node.attr not in method_names
            ):
                referenced.add(node.attr)

    missing = sorted(referenced - assigned - dynamic_attributes)
    assert not missing, f"UI methods reference uninitialized attributes: {missing}"


def test_all_pages_and_dialogs_are_refreshed_by_language_change() -> None:
    tree = _source_tree()
    retranslate = _class_and_method(tree, "MainWindow", "_retranslate_ui")
    calls = {
        node.func.attr
        for node in ast.walk(retranslate)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
    }
    required_calls = {
        "_apply_table_headers", "_render_snapshot", "_render_diagnostic_snapshot",
        "_render_protection_result", "_render_cleanup_state", "_render_startup_entries",
        "_render_process_entries", "_refresh_history",
    }
    assert required_calls <= calls

    static_dialog_calls = {
        node.func.attr
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "QMessageBox"
        and node.func.attr in {"information", "warning", "critical"}
    }
    assert not static_dialog_calls, (
        "Static QMessageBox helpers can leave standard button labels in the OS language"
    )


def test_runtime_language_toggle_visits_all_pages_when_qt_is_available(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        pytest.skip("PySide6 is not installed in this test environment")

    from zentry.ui import main_window

    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(main_window, "get_app_data_directory", lambda: tmp_path)
    window = main_window.MainWindow(provider=object())
    try:
        assert window._pages.count() == 7
        for page_index in range(window._pages.count()):
            window._pages.setCurrentIndex(page_index)
            window._toggle_language()
            assert window._language == "en"
            assert window._nav_buttons[page_index].text().endswith(
                (
                    "Overview", "Diagnostics", "Cleanup", "Startup", "Processes",
                    "History", "System protection",
                )[page_index]
            )
            assert window._history_table.horizontalHeaderItem(0).text() == "Time"
            window._toggle_language()
            assert window._language == "es"
            assert window._history_table.horizontalHeaderItem(0).text() == "Hora"
    finally:
        window.close()
        app.processEvents()


def test_visible_widget_captions_are_not_hard_coded_in_one_language() -> None:
    tree = _source_tree()
    offenders: list[str] = []
    allowed_numeric_placeholders = {"— / 100"}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            continue
        attr = node.func.attr
        if attr in {"QLabel", "QPushButton", "setText", "setToolTip", "setPlaceholderText"}:
            if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                value = node.args[0].value
                if value not in allowed_numeric_placeholders:
                    offenders.append(f"line {node.lineno}: {attr}({value!r})")
    assert not offenders, "Hard-coded visible UI strings found:\n" + "\n".join(offenders)
