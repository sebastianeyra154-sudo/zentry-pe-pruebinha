from __future__ import annotations

import ast
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
UI_SOURCE = PROJECT_ROOT / "zentry" / "ui" / "main_window.py"


def _tree() -> ast.Module:
    return ast.parse(UI_SOURCE.read_text(encoding="utf-8"))


def _class(tree: ast.Module, name: str) -> ast.ClassDef:
    return next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == name
    )


def _method(tree: ast.Module, class_name: str, method_name: str) -> ast.FunctionDef:
    class_node = _class(tree, class_name)
    return next(
        node for node in class_node.body
        if isinstance(node, ast.FunctionDef) and node.name == method_name
    )


def _calls(method: ast.FunctionDef) -> list[ast.Call]:
    return [node for node in ast.walk(method) if isinstance(node, ast.Call)]


def _attribute_calls(method: ast.FunctionDef, attr: str) -> list[ast.Call]:
    return [
        node for node in _calls(method)
        if isinstance(node.func, ast.Attribute) and node.func.attr == attr
    ]


def test_gui_does_not_import_or_execute_operating_system_mutation_apis() -> None:
    tree = _tree()
    forbidden_imports = {
        "psutil", "winreg", "send2trash", "subprocess", "shutil", "os"
    }
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported_roots = {alias.name.split(".")[0] for alias in node.names}
            assert not forbidden_imports.intersection(imported_roots)
        elif isinstance(node, ast.ImportFrom):
            assert (node.module or "").split(".")[0] not in forbidden_imports

    gui_text = UI_SOURCE.read_text(encoding="utf-8")
    assert ".unlink(" not in gui_text
    assert ".rmtree(" not in gui_text
    assert "send2trash(" not in gui_text


def test_all_slow_operations_are_submitted_to_named_workers() -> None:
    tree = _tree()
    expected = {
        "_start_scan": "diagnostics",
        "_run_diagnostics": "diagnostics",
        "_scan_protection": "protection",
        "_analyze_cleanup": "cleanup",
        "_confirm_cleanup": "cleanup",
        "_load_startup": "startup",
        "_load_processes": "processes",
        "_sample_activity": "activity",
    }
    for method_name, task_key in expected.items():
        method = _method(tree, "MainWindow", method_name)
        calls = _attribute_calls(method, "_run_worker")
        assert calls, f"{method_name} must submit work to Worker"
        assert any(
            call.args and isinstance(call.args[0], ast.Constant)
            and call.args[0].value == task_key
            for call in calls
        ), f"{method_name} must use task key {task_key!r}"


def test_worker_results_use_bound_gui_slots_and_operation_lock() -> None:
    tree = _tree()
    worker = _class(tree, "Worker")
    bases = [ast.unparse(base) for base in worker.bases]
    assert "QThread" in bases
    worker_run = _method(tree, "Worker", "run")
    worker_run_source = ast.unparse(worker_run)
    assert "self.finished_data.emit(self, result)" in worker_run_source
    assert "self.failed.emit(self, 'worker_operation_failed')" in worker_run_source
    assert "self.progress.emit(self, message)" in worker_run_source

    run_worker = _method(tree, "MainWindow", "_run_worker")
    source = ast.unparse(run_worker)
    assert "self._task_is_running(task_key)" in source
    assert "worker.finished_data.connect(self._on_worker_data)" in source
    assert "worker.failed.connect(self._on_worker_failed)" in source
    assert "worker.progress.connect(self._show_worker_progress)" in source


def test_cleanup_preview_and_execution_run_in_background_sequentially() -> None:
    tree = _tree()
    confirm = _method(tree, "MainWindow", "_confirm_cleanup")
    assert _attribute_calls(confirm, "_run_worker")
    assert "confirm_title" not in ast.unparse(confirm), (
        "The destructive confirmation dialog must wait for the async preview result"
    )
    assert any(
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "preview_cleanup"
        for lambda_node in ast.walk(confirm)
        if isinstance(lambda_node, ast.Lambda)
        for node in ast.walk(lambda_node.body)
    )

    preview_result = _method(tree, "MainWindow", "_on_cleanup_preview")
    assert _attribute_calls(preview_result, "_show_message_box")
    assert _attribute_calls(preview_result, "_run_worker")
    assert "confirm_title" in ast.unparse(preview_result)
    delete_calls = [
        node for lambda_node in ast.walk(preview_result)
        if isinstance(lambda_node, ast.Lambda)
        for node in ast.walk(lambda_node.body)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "delete_files"
    ]
    assert delete_calls, "The provider deletion call must be inside a worker callable"
    assert any(
        keyword.arg == "confirmed"
        and isinstance(keyword.value, ast.Constant)
        and keyword.value.value is True
        for call in delete_calls
        for keyword in call.keywords
    ), "Only the post-confirmation worker call may pass confirmed=True"


def test_gui_only_exposes_explicitly_approved_candidates_as_selectable() -> None:
    tree = _tree()
    on_cleanup = ast.unparse(_method(tree, "MainWindow", "_on_cleanup"))
    assert "FileClassification.SAFE_CANDIDATE" in on_cleanup
    assert "CleanupPolicyDecision.ALLOW" in on_cleanup
    assert "candidate.fingerprint is not None" in on_cleanup
    assert "Unapproved candidates omitted from GUI selection" in UI_SOURCE.read_text(
        encoding="utf-8"
    )


def test_worker_failure_restores_only_the_failed_operation() -> None:
    tree = _tree()
    restore = _method(tree, "MainWindow", "_restore_after_worker_failure")
    source = ast.unparse(restore)
    for task in ("diagnostics", "protection", "cleanup", "startup", "processes"):
        assert f"task_key == '{task}'" in source
    assert "self._cleanup_loading = False" in source
    assert "self._processes_loading = False" in source
    assert "self._startup_loading = False" in source


def test_initialization_does_not_start_scans_or_mutations() -> None:
    tree = _tree()
    init = _method(tree, "MainWindow", "__init__")
    source = ast.unparse(init)
    for forbidden in (
        "_start_scan(", "_run_diagnostics(", "_analyze_cleanup(",
        "_confirm_cleanup(", "_scan_protection(", "_load_startup(", "_load_processes(",
    ):
        assert forbidden not in source
