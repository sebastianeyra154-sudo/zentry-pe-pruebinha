"""Static checks for the GUI's visual and accessibility contracts.

Runtime accessibility still needs testing with PySide6 on Windows; these tests
verify that the intended controls, page routing, and focus styles are present.
"""

from __future__ import annotations

import ast
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
UI_PATH = PROJECT_ROOT / "zentry" / "ui" / "main_window.py"
THEME_PATH = PROJECT_ROOT / "zentry" / "ui" / "theme.py"


def _ui_tree() -> ast.Module:
    return ast.parse(UI_PATH.read_text(encoding="utf-8"))


def _main_window_class(tree: ast.Module) -> ast.ClassDef:
    return next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
    )


def _method(tree: ast.Module, name: str) -> ast.FunctionDef:
    cls = _main_window_class(tree)
    return next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == name
    )


def test_seven_pages_include_system_protection_and_shared_navigation() -> None:
    tree = _ui_tree()
    build_pages = _method(tree, "_build_pages")
    page_builders = [
        node.func.attr
        for node in ast.walk(build_pages)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr.startswith("_build_")
    ]
    assert page_builders == [
        "_build_overview",
        "_build_diagnostics_page",
        "_build_cleanup_page",
        "_build_startup_page",
        "_build_processes_page",
        "_build_history_page",
        "_build_protection_page",
    ]

    navigate = _method(tree, "_navigate_to")
    source = ast.unparse(navigate)
    assert "self._scan_protection()" in source
    assert "self._pages.setCurrentIndex(index)" in source


def test_destructive_cleanup_action_is_distinct_and_disabled_without_scan() -> None:
    tree = _ui_tree()
    cleanup_page = ast.unparse(_method(tree, "_build_cleanup_page"))
    render_cleanup = ast.unparse(_method(tree, "_render_cleanup_state"))
    overview = ast.unparse(_method(tree, "_build_overview"))
    assert "dangerButton" in cleanup_page
    assert "_delete_selected_button.setEnabled(False)" in render_cleanup
    assert "scanButton" in overview


def test_cleanup_table_keeps_full_paths_out_of_visible_cells() -> None:
    tree = _ui_tree()
    source = UI_PATH.read_text(encoding="utf-8")
    assert 'self._t("reason")' in source
    assert "QTableWidgetItem(candidate.reason)" in source
    assert "QTableWidgetItem(candidate.path)" not in source
    assert "name_item.setData(Qt.ItemDataRole.UserRole, candidate.path)" not in source
    assert "cleanup_table_description" in source


def test_theme_has_visible_focus_and_text_backed_status_states() -> None:
    theme = THEME_PATH.read_text(encoding="utf-8")
    assert ":focus" in theme
    assert "QPushButton#dangerButton:focus" in theme
    for state in (
        "statusLoading", "statusReady", "statusEmpty", "statusError",
        "statusProtected", "statusReview", "statusCandidate",
    ):
        assert f"QLabel#{state}" in theme
    assert "QLabel#badgeSafe" in theme
    assert "QLabel#badgeProtected" in theme
    assert "QLabel#badgeReview" in theme


def test_interactive_navigation_and_tables_expose_accessible_metadata() -> None:
    tree = _ui_tree()
    sidebar = ast.unparse(_method(tree, "_build_sidebar"))
    retranslate = ast.unparse(_method(tree, "_retranslate_ui"))
    make_table = ast.unparse(_method(tree, "_make_table"))
    assert "setCheckable(True)" in sidebar
    assert "setAccessibleName" in sidebar
    assert "setAccessibleDescription" in sidebar
    assert "setAccessibleName" in retranslate
    assert "setAccessibleDescription" in retranslate
    assert "setFocusPolicy" in make_table
    assert "setAlternatingRowColors(True)" in make_table


def test_system_protection_page_is_read_only_and_explains_scan_limitations() -> None:
    tree = _ui_tree()
    page = ast.unparse(_method(tree, "_build_protection_page"))
    retranslate = ast.unparse(_method(tree, "_retranslate_ui"))
    assert "self._provider" not in page
    assert "self._scan_protection" in page
    assert "system_protection_limit" in retranslate
    assert "system_protection_body" in retranslate


def _relative_luminance(hex_color: str) -> float:
    rgb = [int(hex_color[index:index + 2], 16) / 255 for index in (1, 3, 5)]
    linear = [
        component / 12.92
        if component <= 0.04045
        else ((component + 0.055) / 1.055) ** 2.4
        for component in rgb
    ]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def test_key_text_and_status_color_pairs_meet_wcag_aa_contrast_target() -> None:
    theme = THEME_PATH.read_text(encoding="utf-8").lower()
    pairs = (
        ("#a7c0e2", "#071427"),
        ("#8faed3", "#071427"),
        ("#f5f9ff", "#071427"),
        ("#a7d7f0", "#032a30"),
        ("#2de4c6", "#08182b"),
        ("#a8f9dc", "#0b2b2c"),
        ("#ffd0da", "#301822"),
        ("#ffe4a6", "#302711"),
        ("#c8efff", "#102b3c"),
        ("#c6f4df", "#102b27"),
        ("#d0dbe5", "#121e2c"),
        ("#ffd3d8", "#31171d"),
    )
    for foreground, background in pairs:
        assert foreground in theme
        assert background in theme
        light, dark = sorted(
            (_relative_luminance(foreground), _relative_luminance(background)),
            reverse=True,
        )
        ratio = (light + 0.05) / (dark + 0.05)
        assert ratio >= 4.5, (
            f"Contrast ratio is too low for {foreground} on {background}: {ratio:.2f}"
        )
