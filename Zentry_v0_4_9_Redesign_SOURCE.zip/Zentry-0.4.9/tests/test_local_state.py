from __future__ import annotations

import ast
from pathlib import Path

from zentry.core.history import HistoryOperation, HistoryResult
from zentry.core.local_state import get_app_data_directory


def test_windows_path_prefers_localappdata_without_creating_directory(tmp_path: Path) -> None:
    local_app_data = tmp_path / "Local App Data"
    result = get_app_data_directory(
        environ={"LOCALAPPDATA": str(local_app_data)},
        home_directory=tmp_path / "home",
        platform="win32",
    )
    assert result == local_app_data / "Zentry"
    assert not result.exists()


def test_windows_path_has_safe_fallback_when_localappdata_missing(tmp_path: Path) -> None:
    result = get_app_data_directory(
        environ={},
        home_directory=tmp_path / "profile",
        platform="win32",
    )
    assert result == tmp_path / "profile" / "AppData" / "Local" / "Zentry"


def test_linux_path_respects_xdg_state_home(tmp_path: Path) -> None:
    result = get_app_data_directory(
        environ={"XDG_STATE_HOME": str(tmp_path / "state")},
        home_directory=tmp_path / "home",
        platform="linux",
    )
    assert result == tmp_path / "state" / "zentry"


def test_history_ui_has_translations_for_every_operation_and_result() -> None:
    source_path = Path(__file__).parents[1] / "zentry" / "ui" / "main_window.py"
    module = ast.parse(source_path.read_text(encoding="utf-8"))
    translations_node = next(
        node.value
        for node in module.body
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Name) and target.id == "TRANSLATIONS"
            for target in node.targets
        )
    )
    translations = ast.literal_eval(translations_node)

    for language in ("es", "en"):
        keys = translations[language]
        for operation in HistoryOperation:
            assert f"history_op_{operation.value}" in keys
        for result in HistoryResult:
            assert f"history_result_{result.value}" in keys
        for key in (
            "history_operation",
            "history_result",
            "history_files",
            "history_estimated_bytes",
            "history_moved_bytes",
            "history_omissions",
            "history_clear_confirm",
            "history_clear_done",
            "history_clear_missing",
            "history_clear_failed",
        ):
            assert key in keys
