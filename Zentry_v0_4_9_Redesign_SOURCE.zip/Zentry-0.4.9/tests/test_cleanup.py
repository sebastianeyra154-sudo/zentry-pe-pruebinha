from __future__ import annotations

import os
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

import pytest

import zentry.core.cleanup as cleanup_module
from zentry.core.cleanup import (
    CleanupConfirmationRequired,
    CleanupService,
)
from zentry.core.safety import WindowsSafetyClassifier
from zentry.core.scanner import CleanupScanner
from zentry.models import (
    CleanupPolicyDecision,
    CleanupResult,
    CleanupScanSummary,
    FileCandidate,
    FileClassification,
)


NOW = datetime.now(timezone.utc)
CATEGORY = "Temporary test files"


class CleanupHarness:
    def __init__(
        self,
        root: Path,
        service: CleanupService,
        scanner: CleanupScanner,
        roots_provider: Callable[[], list[tuple[str, Path]]],
    ) -> None:
        self.root = root
        self.service = service
        self.scanner = scanner
        self.roots_provider = roots_provider

    def scan(self, min_age_days: int = 31):
        roots = self.roots_provider()
        self.service.invalidate_scan()
        summary = self.scanner.scan(roots, min_age_days=min_age_days, now=NOW)
        self.service._register_scan(summary, roots, min_age_days)
        return summary


def _set_old_timestamps(path: Path, days: int = 45) -> None:
    old = (NOW - timedelta(days=days)).timestamp()
    os.utime(path, (old, old))


@pytest.fixture

def harness(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> CleanupHarness:
    root = tmp_path / "approved-temp"
    root.mkdir()
    windows = tmp_path / "Windows"
    windows.mkdir()
    program_files = tmp_path / "Program Files"
    program_files.mkdir()
    profile = tmp_path / "profile"
    profile.mkdir()
    monkeypatch.setenv("SystemRoot", str(windows))
    monkeypatch.setenv("SystemDrive", str(tmp_path))
    monkeypatch.setenv("ProgramFiles", str(program_files))
    monkeypatch.setenv("ProgramFiles(x86)", str(program_files))
    monkeypatch.setenv("ProgramW6432", str(program_files))
    monkeypatch.setenv("USERPROFILE", str(profile))
    monkeypatch.setenv("LOCALAPPDATA", str(profile / "AppData" / "Local"))
    monkeypatch.setenv("APPDATA", str(profile / "AppData" / "Roaming"))

    roots = [(CATEGORY, root)]
    classifier = WindowsSafetyClassifier()
    scanner = CleanupScanner(classifier)
    service = CleanupService(classifier, roots_provider=lambda: list(roots))
    return CleanupHarness(root, service, scanner, lambda: list(roots))


def _scan_old_candidate(
    harness: CleanupHarness,
    name: str = "old.cache",
    content: bytes = b"old cache data",
    min_age_days: int = 31,
):
    path = harness.root / name
    path.write_bytes(content)
    _set_old_timestamps(path)
    summary = harness.scan(min_age_days=min_age_days)
    matching = [item for item in summary.candidates if item.name == name]
    assert len(matching) == 1
    return path, matching[0]


def _protected_candidate(path: Path) -> FileCandidate:
    metadata = path.stat()
    return FileCandidate(
        path=str(path.resolve()),
        name=path.name,
        category=CATEGORY,
        size_bytes=metadata.st_size,
        last_access=datetime.fromtimestamp(metadata.st_atime, tz=timezone.utc),
        last_modified=datetime.fromtimestamp(metadata.st_mtime, tz=timezone.utc),
        classification=FileClassification.PROTECTED,
        reason="Synthetic protected item for test only.",
        policy_decision=CleanupPolicyDecision.BLOCK,
        fingerprint=CleanupScanner._build_fingerprint(metadata),
    )


def _fake_trash(trash_dir: Path) -> Callable[[str], None]:
    trash_dir.mkdir(parents=True, exist_ok=True)

    def move_to_test_trash(raw_path: str) -> None:
        source = Path(raw_path)
        destination = trash_dir / source.name
        source.rename(destination)

    return move_to_test_trash


def test_preview_groups_explicit_selection_and_estimates_bytes(
    harness: CleanupHarness,
) -> None:
    first_path = harness.root / "one.cache"
    first_path.write_bytes(b"12345")
    _set_old_timestamps(first_path)
    second_path = harness.root / "two.cache"
    second_path.write_bytes(b"1234567")
    _set_old_timestamps(second_path)
    summary = harness.scan()
    first = next(candidate for candidate in summary.candidates if candidate.name == "one.cache")
    second = next(candidate for candidate in summary.candidates if candidate.name == "two.cache")

    preview = harness.service.preview_selection([first, second])

    assert preview.requested_files == 2
    assert preview.eligible_files == 2
    assert preview.rejected_files == 0
    assert preview.estimated_bytes == 12
    assert [
        (item.category, item.file_count, item.estimated_bytes)
        for item in preview.categories
    ] == [(CATEGORY, 2, 12)]
    assert "not permanent-delete fallback" in preview.consequence
    assert first_path.exists()


def test_only_candidate_from_current_scan_reaches_trash(
    harness: CleanupHarness,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    candidate_path, candidate = _scan_old_candidate(harness)
    forged = replace(candidate)
    trash_dir = tmp_path / "test-trash"
    sent: list[str] = []
    fake_move = _fake_trash(trash_dir)

    def track_move(raw_path: str) -> None:
        sent.append(raw_path)
        fake_move(raw_path)

    monkeypatch.setattr(cleanup_module, "send2trash", track_move)
    result = harness.service.execute_selected(
        [candidate, forged], min_age_days=31, confirmed=True
    )

    assert sent == [str(candidate_path.resolve())]
    assert not candidate_path.exists()
    assert (trash_dir / candidate_path.name).exists()
    assert result.selected_files == 2
    assert result.moved_files == 1
    assert result.skipped_files == 1
    assert result.failed_files == 0


def test_protected_candidate_is_rejected_even_if_gui_selects_it(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path = harness.root / "protected.cache"
    path.write_bytes(b"protected synthetic data")
    _set_old_timestamps(path)
    protected = _protected_candidate(path)
    harness.service._register_scan(
        CleanupScanSummary((protected,), 1, 1, 1, 0, 0, 0),
        harness.roots_provider(),
        31,
    )
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    result = harness.service.execute_selected(
        [protected], min_age_days=31, confirmed=True
    )

    assert calls == []
    assert path.exists()
    assert result.moved_files == 0
    assert result.skipped_files == 1


def test_changed_candidate_is_blocked_and_left_intact(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)
    path.write_bytes(b"changed with different size")
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    result = harness.service.execute_selected(
        [candidate], min_age_days=31, confirmed=True
    )

    assert calls == []
    assert path.exists()
    assert result.skipped_changed_files == 1
    assert result.moved_files == 0


def test_send2trash_error_never_falls_back_to_permanent_delete(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)

    def fail_to_trash(raw_path: str) -> None:
        assert raw_path == str(path.resolve())
        raise OSError("synthetic trash failure")

    monkeypatch.setattr(cleanup_module, "send2trash", fail_to_trash)
    result = harness.service.execute_selected(
        [candidate], min_age_days=31, confirmed=True
    )

    assert path.exists()
    assert result.failed_files == 1
    assert result.moved_files == 0
    assert result.moved_bytes == 0


def test_empty_selection_does_nothing_without_confirmation(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    result = harness.service.execute_selected(
        [], min_age_days=31, confirmed=False
    )

    assert result == CleanupResult(0, 0, 0, 0, 0)
    assert calls == []


def test_nonempty_selection_requires_explicit_confirmation(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    with pytest.raises(CleanupConfirmationRequired):
        harness.service.execute_selected(
            [candidate], min_age_days=31, confirmed=False
        )

    assert calls == []
    assert path.exists()


def test_candidate_from_old_scan_is_invalid_after_new_scan(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)
    harness.scan()
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    result = harness.service.execute_selected(
        [candidate], min_age_days=31, confirmed=True
    )

    assert calls == []
    assert path.exists()
    assert result.skipped_files == 1


def test_changing_age_threshold_requires_rescan(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness, min_age_days=31)
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    with pytest.raises(ValueError, match="threshold differs from the scan"):
        harness.service.execute_selected(
            [candidate], min_age_days=32, confirmed=True
        )

    assert calls == []
    assert path.exists()


def test_missing_file_is_skipped_without_calling_trash(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)
    path.rename(path.with_suffix(".renamed"))
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    result = harness.service.execute_selected(
        [candidate], min_age_days=31, confirmed=True
    )

    assert calls == []
    assert result.skipped_changed_files == 1
    assert path.with_suffix(".renamed").exists()


def test_candidate_replaced_with_symlink_is_rejected(
    harness: CleanupHarness,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)
    outside = tmp_path / "outside-secret.cache"
    outside.write_bytes(b"must remain outside the approved root")
    moved_original = harness.root / "original-saved.cache"
    path.rename(moved_original)
    try:
        path.symlink_to(outside)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symlink creation is unavailable in this environment: {type(exc).__name__}")

    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)
    result = harness.service.execute_selected(
        [candidate], min_age_days=31, confirmed=True
    )

    assert calls == []
    assert outside.read_bytes() == b"must remain outside the approved root"
    assert result.moved_files == 0
    assert result.skipped_files == 1


def test_success_return_without_moving_source_is_reported_as_failure(
    harness: CleanupHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path, candidate = _scan_old_candidate(harness)
    calls: list[str] = []
    monkeypatch.setattr(cleanup_module, "send2trash", calls.append)

    result = harness.service.execute_selected(
        [candidate], min_age_days=31, confirmed=True
    )

    assert calls == [str(path.resolve())]
    assert path.exists()
    assert result.failed_files == 1
    assert result.moved_files == 0
    assert result.moved_bytes == 0
