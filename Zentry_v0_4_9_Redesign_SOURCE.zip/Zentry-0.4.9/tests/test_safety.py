from __future__ import annotations

import os
from pathlib import Path, PureWindowsPath
from types import SimpleNamespace

import pytest

from zentry.core.safety import SafetyAssessment, WindowsSafetyClassifier
from zentry.models import CleanupPolicyDecision, FileClassification


@pytest.fixture

def system_environment(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> dict[str, Path]:
    windows = tmp_path / "Windows"
    program_files = tmp_path / "Program Files"
    profile = tmp_path / "Users" / "test-user"
    local_app_data = profile / "AppData" / "Local"
    for directory in (windows, program_files, profile, local_app_data):
        directory.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("SystemRoot", str(windows))
    monkeypatch.setenv("SystemDrive", str(tmp_path))
    monkeypatch.setenv("ProgramFiles", str(program_files))
    monkeypatch.delenv("ProgramFiles(x86)", raising=False)
    monkeypatch.delenv("ProgramW6432", raising=False)
    monkeypatch.setenv("USERPROFILE", str(profile))
    monkeypatch.setenv("LOCALAPPDATA", str(local_app_data))
    return {
        "volume": tmp_path,
        "windows": windows,
        "program_files": program_files,
        "profile": profile,
        "local_app_data": local_app_data,
    }


def make_classifier(system_environment: dict[str, Path]) -> WindowsSafetyClassifier:
    classifier = WindowsSafetyClassifier()
    # WRP is not applicable to the POSIX temp-tree fixtures. Dedicated tests
    # override this flag/checker to validate Windows API failure behavior.
    classifier._is_windows = False
    classifier._wrp_checker = None
    return classifier


def test_known_windows_trees_are_protected(
    system_environment: dict[str, Path],
) -> None:
    windows = system_environment["windows"]
    protected_relative_paths = (
        Path("System32") / "kernel32.dll",
        Path("SysWOW64") / "example.dll",
        Path("WinSxS") / "manifest.xml",
        Path("Servicing") / "Packages" / "package.mum",
        Path("Installer") / "package.msi",
        Path("System32") / "Config" / "SYSTEM",
        Path("System32") / "Recovery" / "winre.wim",
        Path("System32") / "DriverStore" / "FileRepository" / "driver.inf",
        Path("System32") / "Boot" / "BCD",
        Path("Boot") / "BCD",
        Path("Recovery") / "winre.wim",
    )
    classifier = make_classifier(system_environment)

    for relative_path in protected_relative_paths:
        candidate = windows / relative_path
        candidate.parent.mkdir(parents=True, exist_ok=True)
        candidate.write_text("fixture", encoding="utf-8")
        classification, reason = classifier.classify(candidate)
        assert classification is FileClassification.PROTECTED, relative_path
        assert reason.strip(), relative_path


def test_windows_apps_and_system_volume_information_are_protected(
    system_environment: dict[str, Path],
) -> None:
    program_files = system_environment["program_files"]
    volume = system_environment["volume"]
    classifier = make_classifier(system_environment)

    app = program_files / "WindowsApps" / "Package" / "app.exe"
    app.parent.mkdir(parents=True)
    app.write_text("fixture", encoding="utf-8")

    metadata = volume / "System Volume Information" / "tracking.log"
    metadata.parent.mkdir()
    metadata.write_text("fixture", encoding="utf-8")

    assert classifier.classify(app)[0] is FileClassification.PROTECTED
    assert classifier.classify(metadata)[0] is FileClassification.PROTECTED


def test_volume_root_system_files_are_protected_but_similar_temp_names_reviewed(
    system_environment: dict[str, Path],
) -> None:
    volume = system_environment["volume"]
    classifier = make_classifier(system_environment)

    for filename in ("pagefile.sys", "swapfile.sys", "hiberfil.sys"):
        target = volume / filename
        target.write_text("fixture", encoding="utf-8")
        classification, reason = classifier.classify(target)
        assert classification is FileClassification.PROTECTED
        assert "Windows-managed" in reason
        target.unlink()

        lookalike = volume / "Temp" / filename
        lookalike.parent.mkdir(exist_ok=True)
        lookalike.write_text("fixture", encoding="utf-8")
        assert classifier.classify(lookalike)[0] is FileClassification.REVIEW_REQUIRED


def test_profile_registry_hives_are_protected_in_profile_context(
    system_environment: dict[str, Path],
) -> None:
    profile = system_environment["profile"]
    local_app_data = system_environment["local_app_data"]
    classifier = make_classifier(system_environment)

    ntuser = profile / "NTUSER.DAT"
    ntuser.write_text("fixture", encoding="utf-8")
    usrclass = local_app_data / "Microsoft" / "Windows" / "UsrClass.dat"
    usrclass.parent.mkdir(parents=True)
    usrclass.write_text("fixture", encoding="utf-8")

    assert classifier.classify(ntuser)[0] is FileClassification.PROTECTED
    assert classifier.classify(usrclass)[0] is FileClassification.PROTECTED


def test_unknown_path_is_review_not_safe_candidate(
    system_environment: dict[str, Path],
) -> None:
    candidate = system_environment["volume"] / "unknown.dat"
    candidate.write_text("unknown", encoding="utf-8")
    assessment = make_classifier(system_environment).assess(candidate)

    assert assessment.classification is FileClassification.REVIEW_REQUIRED
    assert assessment.policy_decision is CleanupPolicyDecision.NOT_EVALUATED
    assert not assessment.cleanup_permitted_by_classifier
    assert assessment.reason


def test_safe_candidate_and_policy_decision_are_separate(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "old-cache.bin"
    candidate.write_bytes(b"cache")
    classifier = make_classifier(system_environment)

    informational = classifier.assess(candidate)
    assert informational.classification is FileClassification.REVIEW_REQUIRED
    assert informational.policy_decision is CleanupPolicyDecision.NOT_EVALUATED

    cleanup_assessment = classifier.assess_for_cleanup(
        candidate,
        (root,),
        "Known disposable test cache.",
    )
    assert cleanup_assessment.classification is FileClassification.SAFE_CANDIDATE
    assert cleanup_assessment.policy_decision is CleanupPolicyDecision.ALLOW
    assert cleanup_assessment.cleanup_permitted_by_classifier
    assert "Age" in cleanup_assessment.policy_reason


def test_missing_or_failing_wrp_blocks_cleanup_on_windows(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "old-cache.bin"
    candidate.write_bytes(b"cache")
    classifier = make_classifier(system_environment)
    classifier._is_windows = True
    classifier._wrp_checker = None

    assessment = classifier.assess_for_cleanup(candidate, (root,), "Test cache")
    assert assessment.classification is FileClassification.REVIEW_REQUIRED
    assert assessment.policy_decision is CleanupPolicyDecision.REVIEW_REQUIRED

    def failed_native_call(_handle: object, _filename: str) -> int:
        raise OSError("native call failed")

    classifier._wrp_checker = failed_native_call
    failed = classifier.assess_for_cleanup(candidate, (root,), "Test cache")
    assert failed.classification is FileClassification.REVIEW_REQUIRED
    assert failed.policy_decision is CleanupPolicyDecision.REVIEW_REQUIRED


def test_wrp_positive_result_blocks_cleanup(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "old-cache.bin"
    candidate.write_bytes(b"cache")
    classifier = make_classifier(system_environment)
    classifier._is_windows = True
    classifier._wrp_checker = lambda _handle, _filename: 1

    assessment = classifier.assess_for_cleanup(candidate, (root,), "Test cache")
    assert assessment.classification is FileClassification.PROTECTED
    assert assessment.policy_decision is CleanupPolicyDecision.BLOCK


def test_wrp_false_result_allows_only_explicit_disposable_root(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "old-cache.bin"
    candidate.write_bytes(b"cache")
    classifier = make_classifier(system_environment)
    classifier._is_windows = True
    classifier._wrp_checker = lambda _handle, _filename: 0

    result = classifier.assess_for_cleanup(candidate, (root,), "Known temp cache")
    assert result.classification is FileClassification.SAFE_CANDIDATE
    assert result.policy_decision is CleanupPolicyDecision.ALLOW

    outside = system_environment["volume"] / "Documents" / "keep.bin"
    outside.parent.mkdir()
    outside.write_bytes(b"user data")
    outside_result = classifier.assess_for_cleanup(
        outside, (root,), "Not a valid rationale"
    )
    assert outside_result.classification is FileClassification.REVIEW_REQUIRED
    assert outside_result.policy_decision is CleanupPolicyDecision.REVIEW_REQUIRED


def test_suspicious_extensions_require_review_in_disposable_root(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    classifier = make_classifier(system_environment)

    for filename in ("setup.exe", "library.dll", "driver.sys"):
        target = root / filename
        target.write_text("fixture", encoding="utf-8")
        assessment = classifier.assess_for_cleanup(target, (root,), "Temp file")
        assert assessment.classification is FileClassification.REVIEW_REQUIRED
        assert assessment.policy_decision is CleanupPolicyDecision.REVIEW_REQUIRED


def test_symlink_is_rejected_when_supported(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    target = root / "target.txt"
    target.write_text("content", encoding="utf-8")
    link = root / "link.txt"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"Symlink creation is unavailable on this host: {exc}")

    assessment = make_classifier(system_environment).assess_for_cleanup(
        link, (root,), "Test cache"
    )
    assert assessment.classification is FileClassification.REPARSE_POINT
    assert assessment.policy_decision is CleanupPolicyDecision.BLOCK


def test_reparse_point_attribute_is_detected_independent_of_host(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_stat = SimpleNamespace(st_mode=0, st_file_attributes=0x0400)
    monkeypatch.setattr(os, "lstat", lambda _path: fake_stat)
    status = WindowsSafetyClassifier._inspect_reparse_chain(Path("/definitely/fake"))
    assert status is True


def test_reparse_check_failure_is_inaccessible_not_allowed(
    system_environment: dict[str, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "cache.bin"
    candidate.write_bytes(b"cache")
    classifier = make_classifier(system_environment)

    original_lstat = os.lstat

    def failing_lstat(path: os.PathLike[str] | str) -> os.stat_result:
        if Path(path) == candidate:
            raise PermissionError("denied")
        return original_lstat(path)

    monkeypatch.setattr(os, "lstat", failing_lstat)
    assessment = classifier.assess_for_cleanup(candidate, (root,), "Temp cache")
    assert assessment.classification is FileClassification.INACCESSIBLE
    assert assessment.policy_decision is CleanupPolicyDecision.BLOCK


def test_path_boundary_does_not_confuse_temp_with_temp2(tmp_path: Path) -> None:
    classifier = WindowsSafetyClassifier()
    root = tmp_path / "Temp"
    sibling = tmp_path / "Temp2"
    root.mkdir()
    sibling.mkdir()
    candidate = sibling / "file.bin"
    candidate.write_text("outside", encoding="utf-8")

    assert not classifier.is_under_allowed_root(candidate, (root,))


def test_windows_path_comparison_is_case_insensitive_and_component_aware() -> None:
    root = PureWindowsPath(r"C:\Temp")
    inside = PureWindowsPath(r"c:\TEMP\cache.bin")
    similar = PureWindowsPath(r"C:\Temp2\cache.bin")
    classifier = WindowsSafetyClassifier()

    assert classifier._is_path_within(inside, root)
    assert not classifier._is_path_within(similar, root)


def test_efi_boot_context_is_protected_on_any_drive(
    system_environment: dict[str, Path],
) -> None:
    volume = system_environment["volume"]
    candidate = volume / "EFI" / "Microsoft" / "Boot" / "BCD"
    candidate.parent.mkdir(parents=True)
    candidate.write_text("fixture", encoding="utf-8")
    classifier = make_classifier(system_environment)

    classification, reason = classifier.classify(candidate)
    assert classification is FileClassification.PROTECTED
    assert "EFI" in reason

    # Exercise Windows drive semantics independent of the current test host.
    classifier._protected_rules = ()
    other_drive_reason = classifier._protected_reason(
        PureWindowsPath(r"D:\EFI\Microsoft\Boot\BCD")
    )
    assert other_drive_reason is not None
    assert "EFI" in other_drive_reason


def test_legacy_tuple_api_remains_compatible(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "cache.bin"
    candidate.write_bytes(b"cache")
    classifier = make_classifier(system_environment)

    classification, reason = classifier.classify_for_cleanup(
        candidate, (root,), "Disposable fixture"
    )
    assert classification is FileClassification.SAFE_CANDIDATE
    assert reason == "Disposable fixture"


def test_assessment_rejects_inconsistent_allow_state() -> None:
    with pytest.raises(ValueError, match="ALLOW requires SAFE_CANDIDATE"):
        SafetyAssessment(
            classification=FileClassification.PROTECTED,
            reason="Protected fixture",
            policy_decision=CleanupPolicyDecision.ALLOW,
        )


def test_empty_disposable_reason_does_not_authorize_cleanup(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "cache.bin"
    candidate.write_bytes(b"cache")
    assessment = make_classifier(system_environment).assess_for_cleanup(
        candidate, (root,), "  "
    )
    assert assessment.classification is FileClassification.REVIEW_REQUIRED
    assert assessment.policy_decision is CleanupPolicyDecision.REVIEW_REQUIRED


def test_wrp_positive_result_takes_precedence_over_extension_signal(
    system_environment: dict[str, Path],
) -> None:
    root = system_environment["volume"] / "Temp"
    root.mkdir()
    candidate = root / "signed-component.dll"
    candidate.write_bytes(b"fixture")
    classifier = make_classifier(system_environment)
    classifier._is_windows = True
    classifier._wrp_checker = lambda _handle, _filename: 1

    assessment = classifier.assess(candidate)
    assert assessment.classification is FileClassification.PROTECTED
    assert "Resource Protection" in assessment.reason


def test_ancestor_directory_symlink_is_rejected_when_supported(
    system_environment: dict[str, Path],
) -> None:
    volume = system_environment["volume"]
    real_root = volume / "RealTemp"
    real_root.mkdir()
    candidate = real_root / "cache.bin"
    candidate.write_bytes(b"cache")
    link_root = volume / "TempLink"
    try:
        link_root.symlink_to(real_root, target_is_directory=True)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"Directory symlink creation is unavailable: {exc}")

    classifier = make_classifier(system_environment)
    linked_candidate = link_root / candidate.name
    assessment = classifier.assess_for_cleanup(
        linked_candidate, (link_root,), "Temporary cache"
    )
    assert assessment.classification is FileClassification.REPARSE_POINT
    assert assessment.policy_decision is CleanupPolicyDecision.BLOCK


def test_system_volume_information_is_protected_on_other_windows_drives(
    system_environment: dict[str, Path],
) -> None:
    classifier = make_classifier(system_environment)
    reason = classifier._protected_reason(
        PureWindowsPath(r"D:\System Volume Information\tracking.log")
    )
    assert reason is not None
    assert "System Volume Information" in reason
