from __future__ import annotations

from dataclasses import fields
from datetime import datetime, timedelta, timezone

import pytest

from zentry.models import (
    CleanupOutcome,
    CleanupPolicyDecision,
    CleanupResult,
    CleanupScanSummary,
    FileCandidate,
    FileClassification,
    FileFingerprint,
    ProcessInfo,
    ScanHistoryItem,
    StartupEntry,
    SystemProtectionSummary,
    SystemSnapshot,
)


NOW = datetime.now(timezone.utc)


def make_candidate(**overrides: object) -> FileCandidate:
    values: dict[str, object] = {
        "path": "C:/Users/test/AppData/Local/Temp/example.tmp",
        "name": "example.tmp",
        "category": "User temporary files",
        "size_bytes": 1024,
        "last_access": NOW - timedelta(days=45),
        "last_modified": NOW - timedelta(days=45),
        "classification": FileClassification.SAFE_CANDIDATE,
        "reason": "Old file in an approved temporary directory.",
    }
    values.update(overrides)
    return FileCandidate(**values)  # type: ignore[arg-type]


def make_history(**overrides: object) -> ScanHistoryItem:
    values: dict[str, object] = {
        "timestamp": NOW,
        "health_score": 92,
        "cpu_percent": 15.5,
        "memory_percent": 42.0,
        "disk_percent": 61.0,
        "reclaimable_bytes": 1024,
        "cleaned_bytes": 512,
    }
    values.update(overrides)
    return ScanHistoryItem(**values)  # type: ignore[arg-type]


def test_file_classification_is_not_delete_authorization() -> None:
    candidate = make_candidate()
    assert candidate.classification is FileClassification.SAFE_CANDIDATE
    assert candidate.policy_decision is CleanupPolicyDecision.NOT_EVALUATED


def test_policy_cannot_allow_protected_or_inaccessible_file() -> None:
    with pytest.raises(ValueError, match="Only SAFE_CANDIDATE"):
        make_candidate(
            classification=FileClassification.PROTECTED,
            policy_decision=CleanupPolicyDecision.ALLOW,
        )

    with pytest.raises(ValueError, match="Only SAFE_CANDIDATE"):
        make_candidate(
            classification=FileClassification.INACCESSIBLE,
            policy_decision=CleanupPolicyDecision.ALLOW,
        )


def test_file_candidate_requires_timezone_aware_timestamps() -> None:
    with pytest.raises(ValueError, match="timezone-aware"):
        make_candidate(last_access=datetime(2026, 1, 1))


def test_file_fingerprint_must_match_candidate_size() -> None:
    fingerprint = FileFingerprint(
        size_bytes=2048,
        accessed_ns=NOW.timestamp_ns() if hasattr(NOW, "timestamp_ns") else int(NOW.timestamp() * 1_000_000_000),
        modified_ns=int(NOW.timestamp() * 1_000_000_000),
        device_id=1,
        file_id=2,
    )
    with pytest.raises(ValueError, match="fingerprint size"):
        make_candidate(fingerprint=fingerprint)


def test_system_snapshot_validates_percentages_and_counts() -> None:
    valid = SystemSnapshot(
        cpu_percent=20.0,
        memory_percent=50.0,
        disk_percent=70.0,
        disk_free_gb=100.0,
        startup_count=4,
        startup_high_impact_count=1,
        process_count=120,
        collected_at=NOW,
    )
    assert 0 <= valid.health_score <= 100

    with pytest.raises(ValueError, match="between 0 and 100"):
        SystemSnapshot(101, 50, 70, 100, 4, 1, 120, NOW)
    with pytest.raises(ValueError, match="cannot exceed startup_count"):
        SystemSnapshot(20, 50, 70, 100, 2, 3, 120, NOW)


def test_process_and_startup_models_validate_basic_contracts() -> None:
    assert ProcessInfo(100, "example.exe", 150.0, 4.0, "running").pid == 100
    assert StartupEntry("Example", "example.exe --start", "Current user").source

    with pytest.raises(ValueError, match="pid"):
        ProcessInfo(-1, "example.exe", 0.0, 4.0, "running")
    with pytest.raises(ValueError, match="memory_percent"):
        ProcessInfo(100, "example.exe", 0.0, 101.0, "running")


def test_scan_summary_counts_are_non_negative_and_reclaim_is_estimated() -> None:
    allowed = make_candidate()
    denied = make_candidate(
        path="C:/Users/test/AppData/Local/Temp/denied.tmp",
        name="denied.tmp",
        policy_decision=CleanupPolicyDecision.BLOCK,
    )
    summary = CleanupScanSummary(
        candidates=(allowed, denied),
        scanned_roots=1,
        scanned_files=2,
        protected_files=0,
        review_files=0,
        inaccessible_items=0,
        skipped_reparse_points=0,
    )
    assert summary.reclaimable_bytes == 1024

    with pytest.raises(ValueError, match="scanned_files"):
        CleanupScanSummary((), 1, -1, 0, 0, 0, 0)
    with pytest.raises(TypeError, match="must be a tuple"):
        CleanupScanSummary([], 0, 0, 0, 0, 0, 0)  # type: ignore[arg-type]


def test_cleanup_result_exposes_derived_outcome_and_rejects_impossible_counts() -> None:
    assert CleanupResult(0, 0, 0, 0, 0).outcome is CleanupOutcome.NO_SELECTION
    assert CleanupResult(2, 2, 120, 0, 0).outcome is CleanupOutcome.COMPLETED
    assert CleanupResult(2, 1, 60, 1, 0).outcome is CleanupOutcome.PARTIAL
    assert CleanupResult(2, 0, 0, 2, 0).outcome is CleanupOutcome.FAILED
    assert CleanupResult(2, 0, 0, 0, 0).outcome is CleanupOutcome.INCOMPLETE
    assert CleanupResult(2, 0, 0, 0, 2).outcome is CleanupOutcome.SKIPPED

    with pytest.raises(ValueError, match="cannot exceed selected_files"):
        CleanupResult(1, 1, 1, 1, 0)


def test_protection_summary_validates_roots_and_counts() -> None:
    summary = SystemProtectionSummary(1, 10, 4, 5, 1, ("C:/Windows",))
    assert summary.protected_roots == ("C:/Windows",)

    with pytest.raises(ValueError, match="non-empty strings"):
        SystemProtectionSummary(1, 10, 4, 5, 1, ("",))


def test_history_persistence_round_trip_contains_aggregates_only() -> None:
    item = make_history()
    record = item.to_persistence_record()
    restored = ScanHistoryItem.from_persistence_record(record)

    assert restored == item
    assert record["schema_version"] == 1
    assert not any(key in record for key in ("path", "name", "command", "pid"))


def test_history_reader_accepts_legacy_record_without_optional_fields() -> None:
    record = {
        "timestamp": NOW.isoformat(),
        "health_score": 90,
        "cpu_percent": 10.0,
        "memory_percent": 40.0,
        "disk_percent": 55.0,
    }
    restored = ScanHistoryItem.from_persistence_record(record)
    assert restored.reclaimable_bytes == 0
    assert restored.cleaned_bytes == 0


def test_history_rejects_invalid_ranges_naive_timestamp_and_unknown_version() -> None:
    with pytest.raises(ValueError, match="health_score"):
        make_history(health_score=101)
    with pytest.raises(ValueError, match="timezone-aware"):
        make_history(timestamp=datetime(2026, 1, 1))
    with pytest.raises(ValueError, match="Unsupported history schema version"):
        ScanHistoryItem.from_persistence_record(
            make_history().to_persistence_record() | {"schema_version": 999}
        )


def test_sensitive_models_are_marked_session_only() -> None:
    candidate_fields = {item.name: item for item in fields(FileCandidate)}
    startup_fields = {item.name: item for item in fields(StartupEntry)}
    process_fields = {item.name: item for item in fields(ProcessInfo)}
    history_fields = {item.name: item for item in fields(ScanHistoryItem)}

    assert candidate_fields["path"].metadata["persist"] is False
    assert candidate_fields["name"].metadata["privacy"] == "session_only"
    assert startup_fields["command"].metadata["privacy"] == "session_only"
    assert process_fields["pid"].metadata["privacy"] == "session_only"
    assert history_fields["timestamp"].metadata["persist"] is True
    assert history_fields["cleaned_bytes"].metadata["privacy"] == "aggregate"


def test_cleanup_result_reports_policy_omissions_separately() -> None:
    result = CleanupResult(3, 1, 24, 0, 1, skipped_files=1)
    assert result.omitted_files == 2
    assert result.outcome is CleanupOutcome.PARTIAL

    with pytest.raises(ValueError, match="cannot exceed selected_files"):
        CleanupResult(1, 0, 0, 0, 1, skipped_files=1)
