# Zentry 0.4.9 — Arquitectura y responsabilidades

## 1. Alcance

Zentry es una aplicación de escritorio local en Python/PySide6 orientada al diagnóstico de equipo Windows, al análisis conservador de archivos antiguos y a la limpieza elegida por el usuario. La versión del paquete fuente se lee de `zentry/__init__.py` (`0.4.9`); la documentación no declara que sea una release estable certificada. La interfaz recibió un rediseño visual inspirado en una consola de diagnóstico oscura, con acentos cian/violeta y estado visible de modo seguro.

No incluye IA, desinstalación de aplicaciones, terminación de procesos, gestión de servicios ni modificaciones del Registro. La vista de inicio usa el Registro solo para lectura.

## 2. Vista de capas

```text
zentry/__main__.py
        |
        v
zentry/app.py ---- logging_setup.py / theme.py
        |
        v
zentry/ui/main_window.py
        |  Workers Qt / signals
        v
SystemDiagnosticsProvider (providers/system.py)
        |\
        | \---- HistoryStore (core/history.py) / local_state.py
        |
        +---- CleanupScanner (core/scanner.py)
        |            |
        |            v
        |      WindowsSafetyClassifier (core/safety.py)
        |
        +---- CleanupService (core/cleanup.py)
                     |
                     v
               send2trash

zentry/models.py define contratos de datos compartidos.
```

Los modelos transportan datos entre capas; no crean widgets ni llaman por sí solos al Registro o al sistema operativo. Las operaciones de diagnóstico y escaneo deben ejecutarse fuera del hilo de GUI mediante los workers Qt del `MainWindow`.

## 3. Módulos de la aplicación

### Punto de entrada y GUI

- `zentry/__main__.py`: ejecuta `main()` y devuelve el código de salida de Qt.
- `zentry/app.py`: configura logging, crea `QApplication`, aplica estilos, crea el provider y muestra la ventana.
- `zentry/ui/main_window.py`: páginas Overview/Resumen, Diagnostics/Diagnóstico, Cleanup/Limpieza, Startup/Inicio, Processes/Procesos, History/Historial y System Protection/Protección del sistema. Gestiona navegación, textos ES/EN, workers, selección, confirmaciones y visualización del historial. No debe convertirse en la implementación de las operaciones de archivos.
- `zentry/ui/theme.py`: hoja de estilos, contraste, controles y foco de teclado.

### Contratos

`zentry/models.py` define enums y dataclasses como:

- `FileClassification` y `CleanupPolicyDecision`: clasificación informativa y decisión de política, conceptos separados.
- `SystemSnapshot`, `ProcessInfo`, `StartupEntry` y otros resultados de diagnóstico.
- `FileFingerprint` y `FileCandidate`: datos de archivo de sesión; pueden contener rutas y nombres privados, no deben persistirse en el historial agregado.
- `CleanupScanSummary`, `CleanupResult` y `SystemProtectionSummary`.
- `ScanHistoryItem`: compatibilidad con filas agregadas antiguas.

`SystemSnapshot.health_score` es una heurística determinista. Aplica penalizaciones por CPU, memoria y disco por encima de umbrales y una penalización adicional por el contador estimado de impacto del inicio. El provider estima aproximadamente un elemento de alto impacto por cada cuatro entradas de inicio; no mide consumo real ni causalidad. No es una métrica científica ni una garantía sobre el estado del PC.

### Core

- `zentry/core/safety.py`: `WindowsSafetyClassifier`, reglas conservadoras de rutas protegidas, comprobaciones de archivo regular, límites de raíz, symlinks/junctions/reparse points y comprobación WRP cuando la API está disponible.
- `zentry/core/scanner.py`: `CleanupScanner.scan()` recorre raíces aprobadas incrementalmente, evalúa fechas, pide la clasificación de seguridad y devuelve candidatos elegibles; `scan_system_protection()` hace un análisis informativo de recursos. El scanner no mueve ni elimina archivos.
- `zentry/core/cleanup.py`: `CleanupService` registra candidatos exactos del escaneo actual, construye vista previa y exige confirmación. Revalida cada candidato e invoca `send2trash`; si la operación falla, no ejecuta un fallback de borrado permanente.
- `zentry/core/history.py`: `HistoryEvent`, `HistoryStore`, esquema de historial v2, migración de registros agregados antiguos, límite de entradas/tamaño y escritura atómica.
- `zentry/core/local_state.py`: resuelve la carpeta de datos locales por plataforma; no la crea por sí solo.
- `zentry/core/logging_setup.py`: logging rotativo, límites de tamaño y helper para registrar excepciones sin mensaje/traceback sensible.

### Provider de sistema

`zentry/providers/system.py` es la frontera de acceso al SO y a `psutil`:

- `collect_snapshot()`/diagnósticos: CPU, memoria, volúmenes y contadores.
- `collect_process_details()` y `list_processes()`: enumeración de solo lectura. Procesos que desaparecen o datos denegados pueden resultar parciales; la API de compatibilidad omite filas cuando el modelo exige valores numéricos disponibles.
- `collect_startup_diagnostics()`/`list_startup_entries()`: lectura de `Run`/`RunOnce` y carpetas de inicio conocidas. No deshabilita entradas.
- `scan_cleanup()`, `preview_cleanup()`, `scan_system_protection()` y `delete_files()`: delegación a scanner/cleanup service.

### Datos locales

En Windows, `get_app_data_directory()` devuelve `%LOCALAPPDATA%\Zentry` cuando esa variable está disponible. El historial está en `history.json`, los logs en `logs\zentry.log`. El historial no almacena nombres ni rutas por archivo; almacena eventos agregados con fecha, operación, resultado, contadores, estimaciones de bytes, códigos de error y algunas métricas agregadas.

## 4. Flujo de limpieza

1. La GUI pide un escaneo; un worker llama al provider.
2. `CleanupScanner` acepta solo raíces explícitas y archivos regulares dentro del alcance.
3. Para cada archivo, revisa los metadatos y las fechas, pide `WindowsSafetyClassifier.assess_for_cleanup()` y solo devuelve como candidato aquel con `SAFE_CANDIDATE` y decisión `ALLOW`.
4. `CleanupService` registra las referencias de los candidatos originados en ese escaneo. Una ruta arbitraria enviada por GUI no es suficiente para autorizar.
5. La GUI muestra vista previa y solicita confirmación.
6. El servicio vuelve a validar la ruta, raíz, clasificación, huella y antigüedad antes de llamar a `send2trash`.
7. Se informa de enviados, bytes asociados, fallidos y omitidos; se registra un resumen agregado.

La secuencia no elimina todas las carreras de sistema de archivos: hay un intervalo residual entre la última verificación y la operación basada en ruta de `send2trash`.

## 5. Constructor y CI

- `build_windows.bat`: flujo por pasos para doble clic, espera al final y códigos de salida para errores.
- `build_windows.ps1`: constructor con transcript en `.build-logs`; `-NonInteractive` se usa en CI.
- `requirements.txt`: rangos de dependencias de ejecución.
- `requirements-dev.txt`: versiones directas de dependencias y herramientas de tests/build.
- `.github/workflows/build-windows.yml`: runner `windows-latest`, Python 3.12, pruebas, build, smoke test de proceso por diez segundos y artifact de 14 días. Es una definición de workflow; se necesita consultar el run real para afirmar que fue exitoso.

## 6. Pruebas

`tests/` contiene pruebas para modelos, provider, scanner, safety, cleanup, historial, logging, traducciones, GUI/runtime e instrucciones de build. Muchas pruebas usan mocks y carpetas temporales; no sustituyen pruebas en Windows para WRP, Registry, NTFS reparse points, papelera ni ejecución del EXE.
