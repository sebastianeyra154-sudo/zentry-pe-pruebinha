# Zentry — guía de desarrollo y pruebas

## 1. Requisitos declarados

- Python: CPython; los scripts de build aceptan 3.11–3.14. El workflow de GitHub Actions está configurado para Python 3.12. Esto es configuración prevista, no una matriz de versiones validada.
- GUI: PySide6.
- Diagnóstico: psutil.
- Papelera: send2trash.
- Tests: pytest.
- Empaquetado: PyInstaller.
- Sistema de validación nativa requerido: Windows para Registro, WRP, reparse points NTFS, Papelera y prueba del EXE.

Dependencias de ejecución están en `requirements.txt`; versiones directas de desarrollo/build en `requirements-dev.txt`. No hay lockfile completo con hashes de las dependencias transitivas.

## 2. Preparar entorno

Desde PowerShell normal en la raíz:

```powershell
py -3.12 --version
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pip check
```

Si el launcher/versión 3.12 no está disponible, usa una instalación CPython funcional de las versiones aceptadas por el constructor y comprueba la versión real. No es necesario activar el entorno.

## 3. Comprobaciones básicas

```powershell
.\.venv\Scripts\python.exe -m compileall -q zentry tests
.\.venv\Scripts\python.exe -m pytest -q -rs
```

Para una sola suite:

```powershell
.\.venv\Scripts\python.exe -m pytest -q tests/test_safety.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_scanner.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_cleanup.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_system_provider.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_history.py tests/test_logging_setup.py tests/test_local_state.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_translations.py tests/test_gui_accessibility.py tests/test_gui_runtime_integration.py tests/test_ui_service_integration.py
```

### Principios de pruebas

- Usa `tmp_path` para archivos de prueba.
- Usa mocks para `send2trash`, Registro, WRP y errores de sistema donde no haga falta probar la API nativa.
- No elimines archivos reales del usuario para demostrar la limpieza.
- Las pruebas con mocks prueban el contrato simulado; no equivalen a probar Windows real.
- Si una prueba requiere symlinks/junctions o Qt y se omite por capacidades ausentes, regístralo. No conviertas un skip en un “PASÓ”.
- Reproduce cada fallo antes de cambiar el código; no relajes seguridad solo para hacer pasar un test.

## 4. Arquitectura para cambios

Respeta esta dirección de dependencias:

1. `models.py`: contratos sin lógica de GUI o llamadas al SO.
2. `core/safety.py`: clasificar y explicar; no ejecutar limpieza.
3. `core/scanner.py`: descubrir candidatos en raíces permitidas; solo lectura.
4. `core/cleanup.py`: vista previa, registro de candidatos del escaneo actual, revalidación y envío a Papelera.
5. `providers/system.py`: frontera para el sistema operativo y delegación a servicios.
6. `core/history.py`/`logging_setup.py`: almacenamiento agregado y log local con privacidad.
7. `ui/main_window.py`: presentación y control del flujo; las operaciones lentas van a workers Qt.

No permitas que la GUI eluda el servicio para llamar directamente a `send2trash`, Registry APIs o enumeración del sistema. No agregues dependencias sin justificar problema, alternativa y coste de mantenimiento.

## 5. Antes de enviar una contribución

- Ejecuta `compileall`, `pytest -q -rs` y `pip check`.
- Revisa `git diff --check` y `git status --short`.
- Confirma que no se han incluido `.venv`, `__pycache__`, `.pytest_cache`, `build`, `dist`, logs, historial local ni datos del usuario.
- Añade tests para fallos/estados límite y explica qué no pudo validarse.
- No afirmes que un cambio está probado en Windows sin evidencia de un runner Windows o una máquina Windows.

## 6. Estado de validación de esta documentación

Validación local de Zentry 0.4.9: `compileall` pasó y `pytest` devolvió **141 passed, 3 skipped** en este entorno. PySide6 no está instalado aquí, por lo que la prueba que inicia la GUI se omite. Esto no es una ejecución de Windows ni un resultado de CI; la prueba runtime de traducciones y el EXE deben confirmarse en Windows.
