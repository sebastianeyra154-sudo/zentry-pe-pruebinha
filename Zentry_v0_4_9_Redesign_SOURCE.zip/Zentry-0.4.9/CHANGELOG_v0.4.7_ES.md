# Cambios de Zentry 0.4.7

Corrección de etiquetas de navegación en inglés tras la ejecución de pruebas de Windows.

- Se separaron las etiquetas de menú `startup_nav` y `system_protection_nav` de los nombres de página, para que el menú use `Startup` y `System protection` sin cambiar los textos descriptivos de las páginas.
- Se añadió una prueba de regresión que verifica que tanto la creación de la navegación como el cambio de idioma usan esas claves concisas.
- Versión declarada del paquete: `0.4.7`.

## Validación disponible

- En el entorno actual: `136 passed, 3 skipped`.
- El entorno actual no tiene PySide6; por eso la prueba que crea la GUI real se omite aquí. La ejecución del usuario en Windows debe repetirse para confirmar el test runtime de Qt y continuar con PyInstaller.
- Esta versión todavía no se considera un EXE validado en Windows hasta que el build termine correctamente.
