# Zentry v0.4.9

- Corrige un error de inicialización de la GUI: `_latest_activity` ahora se inicializa antes de construir la interfaz y ejecutar la primera traducción. La traducción vuelve a llamar a `_render_snapshot()`, que necesita ese atributo incluso cuando todavía no hay un diagnóstico ni una muestra del gráfico.
- No cambia el flujo de diagnóstico, el escáner de limpieza, ni las reglas de confirmación/eliminación.

Validación local: `compileall` y pruebas disponibles. La batería de interfaz con PySide6 debe confirmarse en Windows; este entorno no tiene PySide6 instalado.
