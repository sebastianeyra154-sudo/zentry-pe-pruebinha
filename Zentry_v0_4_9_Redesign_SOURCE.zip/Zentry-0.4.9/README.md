# Zentry 0.4.9

Zentry es una aplicación de escritorio local orientada al diagnóstico de Windows y al mantenimiento prudente del almacenamiento. Está diseñada para personas que no quieren ejecutar comandos del sistema ni decidir manualmente qué archivos son temporales.

La interfaz usa PySide6, un tema oscuro azul marino con acentos cian/violeta, navegación lateral, barra superior con el estado «Modo seguro» y selector de idioma español/inglés. La estética no sustituye las reglas de seguridad: la aplicación analiza primero, explica los resultados y pide confirmación antes de enviar archivos seleccionados a la Papelera. Abrir Zentry no inicia un escaneo ni una limpieza automática.

> **Estado de la entrega:** este repositorio contiene código fuente, pruebas y scripts de construcción; no incluye un `Zentry.exe` precompilado. No hay evidencia adjunta de una ejecución exitosa reciente de GitHub Actions ni de una validación visual en Windows. Consulta [`DESARROLLO_Y_PRUEBAS_ES.md`](DESARROLLO_Y_PRUEBAS_ES.md) y [`GUIA_RELEASE_ES.md`](GUIA_RELEASE_ES.md).

## Vista del rediseño

La siguiente imagen es una **maqueta visual de referencia**, no una captura de una ejecución real ni evidencia de que el EXE esté compilado. Los valores que aparecen en ella son ilustrativos.

![Maqueta de la interfaz de Zentry](docs/zentry-dashboard-mockup.png)

## Qué hace esta versión

- **Resumen y diagnóstico:** lee CPU, memoria, almacenamiento y contadores del sistema disponibles. Los datos que no pueden determinarse no deben interpretarse como cero real.
- **Procesos:** muestra información básica en modo de lectura. No termina procesos.
- **Inicio de Windows:** consulta entradas estándar `Run`/`RunOnce` del Registro y carpetas de inicio conocidas, usando acceso de lectura. No deshabilita entradas.
- **Limpieza:** busca candidatos antiguos en raíces específicas de temporales y cachés. La antigüedad predeterminada es 31 días y exige que tanto la marca de último acceso como la de última modificación superen el umbral.
- **Protección del sistema:** clasifica rutas y cuenta recursos protegidos de forma informativa. No es un inventario exhaustivo de todas las particiones/archivos críticos.
- **Limpieza confirmada:** ofrece vista previa, selección, confirmación y envío a la Papelera mediante `send2trash`. Si falla, no se llama a `unlink()` ni `rmtree()` como alternativa de borrado.
- **Historial:** mantiene un historial JSON local versionado, limitado y agregado; no guarda de forma predeterminada las rutas y nombres individuales de archivos.
- **Logs:** usa rotación local y minimiza los detalles de excepciones.
- **Idiomas:** permite cambiar ES/EN dentro de la aplicación; la elección no se persiste entre ejecuciones.

## Lo que NO hace

Esta versión no incorpora chatbot de IA, desinstalador de aplicaciones, terminación de procesos, modificación de servicios, edición de Registro, cambio de configuración del sistema ni optimizaciones automáticas al iniciar. No se ejecuta como administrador por defecto.

## Ejecutar Zentry sin desarrollar

### Si ya tienes un ejecutable generado

Una compilación aprobada produce `dist\Zentry.exe`. En esa situación, abre el ejecutable con doble clic. No se incluye un instalador ni un actualizador automático.

### Obtener un EXE de CI

El workflow `.github/workflows/build-windows.yml` puede publicar el artifact `Zentry-windows-py3.12-<arquitectura>` cuando el build y el smoke test de arranque terminan correctamente. Los artifacts tienen una retención configurada de 14 días; no son releases permanentes. No se afirma que exista actualmente un artifact válido: comprueba el resultado de una ejecución de Actions antes de descargarlo.

## Ejecutar desde código fuente en Windows

Se recomienda una ruta corta como `C:\Zentry`. El script constructor valida la instalación de CPython y acepta versiones 3.11–3.14; el workflow está configurado para Python 3.12. Eso describe la configuración del proyecto, no prueba por sí solo que todas esas versiones hayan pasado un build real de Windows.

1. Instala una instalación funcional de CPython desde una fuente confiable.
2. Extrae el repositorio en `C:\Zentry`.
3. Abre PowerShell normal (no administrador) en esa carpeta.
4. Ejecuta los comandos de [`INSTALACION_WINDOWS_ES.md`](INSTALACION_WINDOWS_ES.md) para crear `.venv`, instalar dependencias, ejecutar pruebas e iniciar la aplicación.

No es necesario activar el entorno virtual con `Activate.ps1`: usa siempre `.\.venv\Scripts\python.exe` tal como aparece en las instrucciones. No cambies `ExecutionPolicy` para utilizar Zentry.

## Compilar el EXE en Windows

Desde el Explorador, haz doble clic en `build_windows.bat`. Como alternativa, consulta la sección PowerShell de [`INSTALACION_WINDOWS_ES.md`](INSTALACION_WINDOWS_ES.md).

El constructor muestra pasos `[PASO x/8]`, detecta CPython, prepara `.venv`, instala `requirements-dev.txt`, ejecuta sintaxis y pruebas antes de compilar, crea `dist\Zentry.exe`, verifica que exista y tenga tamaño mayor que cero y deja visible el resultado. Abre `dist` automáticamente solo si la comprobación de build tiene éxito.

La existencia y el tamaño del archivo **no demuestran que toda la aplicación funcione**; la interacción de la GUI debe validarse aparte. Consulta la guía de solución de problemas si no aparece `dist`.

## Subir el proyecto a GitHub y crear el EXE

Consulta [`SUBIR_A_GITHUB_ES.md`](SUBIR_A_GITHUB_ES.md) para subir el proyecto completo, ejecutar el workflow de Windows, descargar el artifact y recopilar logs si falla.

## Documentación del proyecto

- [`CHANGELOG_v0.4.9_ES.md`](CHANGELOG_v0.4.9_ES.md): inicialización de la muestra del panel antes de la primera traducción.

- [`INSTALACION_WINDOWS_ES.md`](INSTALACION_WINDOWS_ES.md): comandos exactos para instalación, tests, ejecución y build.
- [`ARCHITECTURE_ES.md`](ARCHITECTURE_ES.md): capas, módulos, flujo y contratos.
- [`SEGURIDAD_Y_LIMITACIONES_ES.md`](SEGURIDAD_Y_LIMITACIONES_ES.md): matriz de riesgo, efectos y límites reales.
- [`SOLUCION_DE_PROBLEMAS_ES.md`](SOLUCION_DE_PROBLEMAS_ES.md): Python, PySide6/Qt, rutas largas, build y logs.
- [`DESARROLLO_Y_PRUEBAS_ES.md`](DESARROLLO_Y_PRUEBAS_ES.md): entorno, pruebas y flujo de contribución.
- [`GUIA_RELEASE_ES.md`](GUIA_RELEASE_ES.md): checklist de release y estado de decisiones pendientes.
- [`README_PROMPT12_ES.md`](README_PROMPT12_ES.md): detalle específico del constructor de Windows.

## Requisitos y dependencias

Dependencias de ejecución (`requirements.txt`):

- `PySide6>=6.8,<7`: interfaz de escritorio Qt.
- `psutil>=7.0,<8`: métricas de CPU, RAM, almacenamiento y procesos.
- `send2trash>=1.8,<2`: envío de archivos a la Papelera compatible con el entorno.

`requirements-dev.txt` incluye esas dependencias y fija versiones directas para pruebas y empaquetado: PySide6 6.12.0, psutil 7.2.2, send2trash 1.8.3, pytest 9.1.1 y PyInstaller 6.22.3. Las dependencias transitivas no están bloqueadas por un archivo lock con hashes; no se garantiza reproducibilidad binaria byte a byte.

No se ha elegido una licencia. No añadas una insignia o declaración de licencia open source hasta que se tome la decisión y se incluya el archivo legal correspondiente.

## Pruebas y estado de validación documentado

Comandos principales:

```powershell
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -m compileall -q zentry tests
.\.venv\Scripts\python.exe -m pytest -q -rs
```

En la ejecución local actual, la suite devolvió `141 passed, 3 skipped`; PySide6 no está instalado aquí, así que la prueba de GUI real se omite. Las pruebas omitidas requieren PySide6 en ejecución. Esto no es una prueba de Windows, del Registro real, de WRP nativo, de la Papelera de Windows ni del EXE final. El workflow está configurado para `windows-latest`/Python 3.12, pero hace falta inspeccionar una ejecución real antes de declarar CI exitoso.

## Seguridad y privacidad

Lee [`SEGURIDAD_Y_LIMITACIONES_ES.md`](SEGURIDAD_Y_LIMITACIONES_ES.md) antes de usar limpieza. En particular: antiguo no significa innecesario; la lista de protección es conservadora, no exhaustiva; la Papelera no garantiza recuperación en todos los volúmenes; y no se debe probar el borrado sobre archivos importantes del usuario.
