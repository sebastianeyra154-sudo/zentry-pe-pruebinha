@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" >nul 2>&1
if errorlevel 1 goto :root_error

set "PROJECT_ROOT=%CD%"
set "VENV=%PROJECT_ROOT%\.venv"
set "VENV_PYTHON=%VENV%\Scripts\python.exe"
set "PYTHON_EXE="
set "PYTHON_ARGS="
set "PYTHON_SOURCE="
set "EXE_PATH=%PROJECT_ROOT%\dist\Zentry.exe"
set "EXE_SIZE="

title Zentry - Windows Build

echo.
echo ============================================================
echo                  ZENTRY - WINDOWS BUILD
echo ============================================================
echo Project: %PROJECT_ROOT%
echo.

echo [PASO 1/8] Detectar un Python real compatible...
if exist "%VENV_PYTHON%" goto :use_existing_venv
if exist "%VENV%" goto :broken_venv

call :try_candidate "py.exe" "-3" "Python Launcher"
if defined PYTHON_EXE goto :python_selected

for /f "delims=" %%P in ('where.exe python3.exe 2^>nul') do call :try_candidate "%%P" "" "PATH python3.exe"
if defined PYTHON_EXE goto :python_selected

for /f "delims=" %%P in ('where.exe python.exe 2^>nul') do call :try_candidate "%%P" "" "PATH python.exe"
if defined PYTHON_EXE goto :python_selected

REM Rutas habituales por usuario: probar el binario; no confiar solo en el nombre.
for /d %%D in ("%LocalAppData%\Programs\Python\Python3*") do if exist "%%~D\python.exe" call :try_candidate "%%~D\python.exe" "" "Instalacion por usuario"
if defined PYTHON_EXE goto :python_selected

REM Rutas habituales globales y de 32 bits.
for /d %%D in ("%ProgramFiles%\Python3*") do if exist "%%~D\python.exe" call :try_candidate "%%~D\python.exe" "" "Program Files"
if defined PYTHON_EXE goto :python_selected
for /d %%D in ("%ProgramFiles(x86)%\Python3*") do if exist "%%~D\python.exe" call :try_candidate "%%~D\python.exe" "" "Program Files x86"
if defined PYTHON_EXE goto :python_selected

REM Alias versionados de Microsoft Store: solo se aceptan si ejecutan el probe real.
for /d %%D in ("%LocalAppData%\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.*") do if exist "%%~D\python.exe" call :try_candidate "%%~D\python.exe" "" "Microsoft Store verificado"
if defined PYTHON_EXE goto :python_selected

goto :python_error

:use_existing_venv
set "PYTHON_EXE=%VENV_PYTHON%"
set "PYTHON_ARGS="
set "PYTHON_SOURCE=.venv existente"
"%PYTHON_EXE%" -c "import sys; raise SystemExit(0 if sys.implementation.name == 'cpython' and (3,11) <= sys.version_info[:2] < (3,15) else 2)" >nul 2>&1
if errorlevel 1 goto :venv_python_error
echo       Interprete existente en .venv:
"%PYTHON_EXE%" -c "import sys; print('       Ejecutable:', sys.executable); print('       Version:', sys.version.split()[0])"
if errorlevel 1 goto :venv_python_error
goto :setup_venv

:python_selected
echo       Seleccion: %PYTHON_SOURCE%
"%PYTHON_EXE%" %PYTHON_ARGS% -c "import sys; print('       Ejecutable:', sys.executable); print('       Version:', sys.version.split()[0])"
if errorlevel 1 goto :python_error

echo.
:setup_venv
echo [PASO 2/8] Crear o validar el entorno virtual del proyecto...
if exist "%VENV_PYTHON%" goto :venv_ready
"%PYTHON_EXE%" %PYTHON_ARGS% -m venv "%VENV%"
if errorlevel 1 goto :venv_error
if not exist "%VENV_PYTHON%" goto :venv_error

:venv_ready
"%VENV_PYTHON%" -c "import sys; raise SystemExit(0 if sys.implementation.name == 'cpython' and (3,11) <= sys.version_info[:2] < (3,15) else 2)" >nul 2>&1
if errorlevel 1 goto :venv_python_error
"%VENV_PYTHON%" -c "import sys; print('       Entorno usado:', sys.executable); print('       Version:', sys.version.split()[0])"
if errorlevel 1 goto :venv_python_error

echo.
echo [PASO 3/8] Instalar dependencias declaradas y herramientas fijadas...
if not exist "%PROJECT_ROOT%\requirements-dev.txt" goto :requirements_error
"%VENV_PYTHON%" -m pip --disable-pip-version-check install -r "%PROJECT_ROOT%\requirements-dev.txt"
if errorlevel 1 goto :dependency_error
"%VENV_PYTHON%" -m pip check
if errorlevel 1 goto :dependency_error
"%VENV_PYTHON%" -m pip freeze
if errorlevel 1 goto :dependency_error

echo.
echo [PASO 4/8] Comprobar sintaxis Python...
"%VENV_PYTHON%" -m compileall -q "%PROJECT_ROOT%\zentry" "%PROJECT_ROOT%\tests"
if errorlevel 1 goto :syntax_error

echo.
echo [PASO 5/8] Ejecutar pruebas automatizadas...
"%VENV_PYTHON%" -m pytest -q -rs
if errorlevel 1 goto :test_error

echo.
echo [PASO 6/8] Limpiar solo artefactos del proyecto...
if exist "%PROJECT_ROOT%\build" rmdir /s /q "%PROJECT_ROOT%\build"
if exist "%PROJECT_ROOT%\build" goto :cleanup_error
if exist "%PROJECT_ROOT%\dist" rmdir /s /q "%PROJECT_ROOT%\dist"
if exist "%PROJECT_ROOT%\dist" goto :cleanup_error
if exist "%PROJECT_ROOT%\Zentry.spec" del /q "%PROJECT_ROOT%\Zentry.spec"
if exist "%PROJECT_ROOT%\Zentry.spec" goto :cleanup_error
for /r "%PROJECT_ROOT%\zentry" %%F in (*.pyc) do del /q "%%F" >nul 2>&1
for /d /r "%PROJECT_ROOT%\zentry" %%D in (__pycache__) do if exist "%%D" rmdir /s /q "%%D" >nul 2>&1
for /r "%PROJECT_ROOT%\tests" %%F in (*.pyc) do del /q "%%F" >nul 2>&1
for /d /r "%PROJECT_ROOT%\tests" %%D in (__pycache__) do if exist "%%D" rmdir /s /q "%%D" >nul 2>&1

echo.
echo [PASO 7/8] Compilar Zentry.exe con PyInstaller...
echo       Se usa el hook estandar de PyInstaller para Qt/PySide6.
echo       Los warnings se muestran; no se silencian errores fatales.
"%VENV_PYTHON%" -m PyInstaller --noconfirm --clean --onefile --windowed --name Zentry --log-level INFO --paths "%PROJECT_ROOT%" --distpath "%PROJECT_ROOT%\dist" --workpath "%PROJECT_ROOT%\build" --specpath "%PROJECT_ROOT%" "%PROJECT_ROOT%\zentry\__main__.py"
if errorlevel 1 goto :build_error

echo.
echo [PASO 8/8] Verificar el ejecutable generado...
if not exist "%EXE_PATH%" goto :exe_error
for %%F in ("%EXE_PATH%") do set "EXE_SIZE=%%~zF"
if not defined EXE_SIZE goto :exe_error
if "%EXE_SIZE%"=="0" goto :exe_error

echo       Archivo: %EXE_PATH%
echo       Tamano: %EXE_SIZE% bytes
certutil -hashfile "%EXE_PATH%" SHA256
echo.
echo ============================================================
echo BUILD SUCCESSFUL - executable generated and size verified
echo ============================================================
echo.
echo Nota: la existencia y el tamano no demuestran que toda la GUI funcione.
echo Abre Zentry.exe para hacer una comprobacion manual de arranque.
echo.
echo Abriendo la carpeta dist...
start "" explorer.exe "%PROJECT_ROOT%\dist"
echo.
echo La consola quedara abierta. Pulsa una tecla para terminar.
pause >nul
popd
exit /b 0

:try_candidate
if defined PYTHON_EXE exit /b 0
set "CANDIDATE=%~1"
set "CANDIDATE_ARGS=%~2"
set "CANDIDATE_LABEL=%~3"
REM No ejecutar los aliases directos de WindowsApps: pueden abrir Microsoft Store.
for %%A in ("%CANDIDATE%") do if /i "%%~dpA"=="%LocalAppData%\Microsoft\WindowsApps\" exit /b 0
if not exist "%CANDIDATE%" (
    where.exe "%CANDIDATE%" >nul 2>&1
    if errorlevel 1 exit /b 0
)
"%CANDIDATE%" %CANDIDATE_ARGS% -c "import sys; raise SystemExit(0 if sys.implementation.name == 'cpython' and (3,11) <= sys.version_info[:2] < (3,15) else 2)" >nul 2>&1
if errorlevel 1 exit /b 0
set "PYTHON_EXE=%CANDIDATE%"
set "PYTHON_ARGS=%CANDIDATE_ARGS%"
set "PYTHON_SOURCE=%CANDIDATE_LABEL%: %CANDIDATE%"
exit /b 0

:root_error
echo [FALLO] No se pudo acceder a la carpeta del proyecto.
goto :fatal_10

:python_error
echo.
echo [FALLO] No se encontro una instalacion real de CPython compatible.
echo Se requiere Python 3.11, 3.12, 3.13 o 3.14. Los alias de Microsoft Store se aceptan solo si ejecutan el probe.
echo Comprueba en PowerShell: py -3 --version, python3 --version, python --version
goto :fatal_10

:broken_venv
echo.
echo [FALLO] Existe una carpeta .venv pero no contiene Scripts\python.exe.
echo El constructor no la borrara automaticamente. Haz copia y renombra o elimina solo esa .venv, luego repite.
goto :fatal_11

:venv_error
echo.
echo [FALLO] No se pudo crear el entorno virtual .venv.
goto :fatal_11

:venv_python_error
echo.
echo [FALLO] El Python de .venv no es valido o no es CPython 3.11-3.14.
echo El constructor no modificara ni eliminara el entorno existente.
echo Si esta danado, haz copia de seguridad y recrea .venv manualmente.
goto :fatal_11

:requirements_error
echo.
echo [FALLO] No existe requirements-dev.txt en la raiz del proyecto.
goto :fatal_12

:dependency_error
echo.
echo [FALLO] No se pudieron instalar o validar las dependencias.
goto :fatal_12

:syntax_error
echo.
echo [FALLO] La comprobacion de sintaxis fallo. No se iniciara PyInstaller.
goto :fatal_13

:test_error
echo.
echo [FALLO] Una o mas pruebas fallaron. No se iniciara PyInstaller.
echo Revisa el traceback anterior y vuelve a ejecutar pytest para reproducirlo.
goto :fatal_13

:cleanup_error
echo.
echo [FALLO] No se pudo limpiar un artefacto del proyecto; no se ha iniciado el build.
goto :fatal_14

:build_error
echo.
echo [FALLO] PyInstaller no pudo generar la aplicacion.
echo Revisa la salida completa. Los warnings no se ocultan y el codigo de salida es fatal si PyInstaller falla.
goto :fatal_15

:exe_error
echo.
echo [FALLO] dist\Zentry.exe no existe o su tamano es cero.
goto :fatal_16

:fatal_10
set "EXIT_CODE=10"
goto :fatal_end
:fatal_11
set "EXIT_CODE=11"
goto :fatal_end
:fatal_12
set "EXIT_CODE=12"
goto :fatal_end
:fatal_13
set "EXIT_CODE=13"
goto :fatal_end
:fatal_14
set "EXIT_CODE=14"
goto :fatal_end
:fatal_15
set "EXIT_CODE=15"
goto :fatal_end
:fatal_16
set "EXIT_CODE=16"
:fatal_end
echo.
echo Build detenido en la etapa actual. No se afirma que el EXE sea funcional.
echo Para guardar todos los mensajes en un log, usa el comando documentado en README_PROMPT12_ES.md.
echo.
echo Pulsa una tecla para cerrar esta ventana.
pause >nul
popd
exit /b %EXIT_CODE%
