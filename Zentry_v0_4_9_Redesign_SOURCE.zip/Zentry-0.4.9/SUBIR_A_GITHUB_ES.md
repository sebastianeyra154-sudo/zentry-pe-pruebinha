# Subir Zentry a GitHub y ejecutar el build de Windows

Esta guía usa un paquete fuente limpio que contiene el código acumulado, las pruebas, los scripts de compilación y `.github/workflows/build-windows.yml`.

> El ZIP no incluye `Zentry.exe`. El EXE se crea en un runner Windows de GitHub Actions si el workflow termina correctamente. No declares el build exitoso hasta comprobar la ejecución real.

## Opción recomendada: crear un repositorio nuevo y vacío

### 1. Descargar y extraer

1. Descarga `Zentry_GitHub_Ready_SOURCE.zip`.
2. Extrae el ZIP en una ruta corta, por ejemplo `C:\Zentry`.
3. Comprueba que `C:\Zentry` contiene `zentry`, `tests`, `requirements.txt`, `requirements-dev.txt`, `build_windows.bat`, `build_windows.ps1` y `.github\workflows\build-windows.yml`.
4. Abre el Explorador en `C:\Zentry`, haz clic en la barra de direcciones, escribe `powershell` y pulsa Enter.
5. No abras PowerShell como administrador.

### 2. Verificar el proyecto antes de subirlo

Ejecuta estas órdenes una a una:

```powershell
git --version
Get-ChildItem
Get-Content .gitignore
```

La versión incluida de `.gitignore` excluye `.venv`, bytecode, caches de tests, artefactos `build`/`dist`, logs y archivos `.env`.

Si quieres validar el código localmente y tienes CPython instalado:

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m compileall -q zentry tests
.\.venv\Scripts\python.exe -m pytest -q -rs
```

Estas pruebas locales no reemplazan la compilación de Windows en Actions. No cambies `ExecutionPolicy` y no uses administrador.

### 3. Crear el repositorio remoto

1. Entra en GitHub y crea un repositorio nuevo.
2. Elige un nombre, por ejemplo `Zentry`.
3. Déjalo **vacío**: no selecciones la opción de crear README, `.gitignore` ni licencia, porque esos archivos ya están en el paquete y la licencia del proyecto sigue pendiente.
4. Copia la URL HTTPS del repositorio que GitHub muestra.

### 4. Inicializar Git y revisar los archivos

En PowerShell, desde la raíz `C:\Zentry`:

```powershell
git init -b main
git add --all
git diff --cached --check
git diff --cached --stat
git status --short
```

**Revisa la salida antes de hacer commit.** Debe contener los módulos de Zentry, pruebas, documentación, dependencias y workflow; no debe contener `.venv`, `dist`, `build`, `.build-logs`, `.env`, claves o logs personales. Si aparece algo sensible, no continúes: quítalo del área preparada y corrige `.gitignore`.

### 5. Crear el commit y conectar el remoto

```powershell
git commit -m "build: prepare Zentry Windows CI"
```

Luego copia y ejecuta esto. El script te pide la URL para no guardar ningún token ni URL inventada:

```powershell
$repoUrl = Read-Host "Pega la URL HTTPS del repositorio vacio de GitHub"
if ([string]::IsNullOrWhiteSpace($repoUrl) -or $repoUrl -notmatch '^https://github\.com/[^/]+/[^/]+(?:\.git)?$') {
    throw "La URL no parece una URL HTTPS de un repositorio GitHub. No se ha configurado el remoto."
}
git remote add origin $repoUrl
git push -u origin main
```

Si Git solicita autenticación, usa el mecanismo normal de Git Credential Manager/navegador. **No pegues tokens en la URL, en scripts ni en el chat.**

## Si ya tienes un repositorio Git local

No ejecutes `git init` de nuevo ni sobrescribas una carpeta que tenga cambios pendientes. Primero:

```powershell
git status --short
git remote -v
git branch --show-current
```

Si ya existe un repositorio con cambios, crea una copia de seguridad. Integra los archivos del paquete conscientemente en esa copia y revisa `git diff` antes del commit. No uses `git push --force` para resolver conflictos.

## Ejecutar GitHub Actions

El workflow está en `.github/workflows/build-windows.yml` y usa `windows-latest` con Python 3.12. Los eventos configurados incluyen `push` a `main`/`master`, pull requests, tags `v*` y ejecución manual.

1. Abre el repositorio en GitHub.
2. Entra en **Actions**.
3. Selecciona **Windows build — Zentry**.
4. Si quieres iniciarlo manualmente, pulsa **Run workflow**, selecciona la rama predeterminada y confirma. La opción manual requiere que el workflow exista en la rama predeterminada; el `push` a `main` también debe dispararlo.
5. Abre la ejecución y espera a que todos los pasos obligatorios estén verdes.
6. Revisa `Build`, `Smoke-test packaged executable startup` y la publicación de artifacts.
7. En la sección **Artifacts**, descarga `Zentry-windows-py3.12-<arquitectura>` y extrae `Zentry.exe`.

El artifact tiene retención temporal de 14 días; no equivale a una GitHub Release permanente. El smoke test espera diez segundos para ver si el proceso termina enseguida; no es una prueba visual completa ni acredita que cada función funcione.

## Si el workflow falla

1. En **Actions**, abre la ejecución roja.
2. Expande el primer paso fallido y copia el primer error causal junto con el nombre del paso.
3. Descarga el artifact `Zentry-build-logs-<run_id>` si se publicó.
4. Comparte solo el fragmento mínimo necesario: elimina nombres personales, rutas privadas, tokens, claves, URL de repositorios privados y datos de diagnóstico.

El build local crea logs bajo `.build-logs`, pero esta carpeta está ignorada por Git. No subas esos logs indiscriminadamente: pueden contener rutas locales o detalles de entorno.

## Archivos importantes que ya incluye el paquete

```text
zentry/                         Código de la aplicación
 tests/                         Tests automatizados
requirements.txt                Dependencias de runtime
requirements-dev.txt            Dependencias de pruebas/build
build_windows.bat               Constructor de doble clic
build_windows.ps1               Constructor con diagnósticos y logging
.github/workflows/build-windows.yml  Build y artifacts en runner Windows
README.md                       Entrada principal de documentación
INSTALACION_WINDOWS_ES.md       Instalación/ejecución
ARCHITECTURE_ES.md              Arquitectura
SEGURIDAD_Y_LIMITACIONES_ES.md  Riesgos y límites
SOLUCION_DE_PROBLEMAS_ES.md     Diagnóstico de fallos
DESARROLLO_Y_PRUEBAS_ES.md      Pruebas y desarrollo
GUIA_RELEASE_ES.md               Checklist de release
```

No se incluye una licencia porque todavía no se ha elegido expresamente. Tampoco se incluye una clave API ni un EXE precompilado.
