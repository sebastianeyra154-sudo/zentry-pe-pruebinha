# Instalación, ejecución y compilación de Zentry en Windows

Esta guía separa el uso del programa del trabajo de desarrollo. Todos los comandos se ejecutan en PowerShell normal, **sin administrador**. No es necesario activar `.venv` ni modificar `ExecutionPolicy`.

## A. Usar un `Zentry.exe` ya generado

Este paquete fuente no incluye un EXE precompilado. Si un run exitoso de GitHub Actions ya publicó un artifact:

1. Abre el repositorio en GitHub y entra a **Actions**.
2. Abre una ejecución de `Windows build — Zentry` que haya terminado correctamente.
3. Descarga el artifact `Zentry-windows-py3.12-<arquitectura>`.
4. Extrae el ZIP del artifact y ejecuta `Zentry.exe` con doble clic.

El artifact se conserva durante 14 días según el workflow actual. No hay workflow configurado para publicar automáticamente una GitHub Release ni un instalador. Comprueba el resultado de Actions antes de asumir que el artefacto existe.

## B. Preparar ejecución desde código fuente

### 1. Extraer el código

Usa una ruta corta, por ejemplo:

```text
C:\Zentry
```

La carpeta raíz debe contener `requirements.txt`, `requirements-dev.txt`, `build_windows.bat`, `zentry\` y `tests\`.

### 2. Abrir PowerShell en la carpeta del proyecto

En el Explorador de archivos, entra en `C:\Zentry`, selecciona la barra de dirección, escribe `powershell` y pulsa Enter. Verifica la ubicación:

```powershell
Get-Location
Get-ChildItem
```

### 3. Comprobar Python

El constructor acepta CPython 3.11–3.14 y verifica que el intérprete funcione; el workflow de CI está configurado para Python 3.12. Eso no constituye evidencia de que se hayan probado todos los intérpretes o de que un run de CI concreto haya pasado.

Ejemplo si el launcher `py` tiene Python 3.12 instalado:

```powershell
py -3.12 --version
py -3.12 -m venv .venv
```

Si `py -3.12` no está disponible, no inventes la ruta. Prueba:

```powershell
python --version
python3 --version
```

Si ninguno ejecuta una instalación real de CPython, instala Python desde una fuente confiable o usa `build_windows.bat`, que dispone de su propio detector. Evita los aliases de Microsoft Store que solo abren la tienda.

Si `.venv` ya existe, usa el Python de ese entorno en todos los pasos siguientes:

```powershell
.\.venv\Scripts\python.exe --version
```

No hace falta ejecutar `Activate.ps1`.

### 4. Instalar dependencias

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pip check
```

`requirements-dev.txt` incluye las dependencias de ejecución más pytest y PyInstaller. No uses `pip` sin asociarlo al ejecutable de `.venv`.

### 5. Ejecutar verificaciones

```powershell
.\.venv\Scripts\python.exe -m compileall -q zentry tests
.\.venv\Scripts\python.exe -m pytest -q -rs
```

Para conservar un log de pruebas:

```powershell
.\.venv\Scripts\python.exe -m pytest -q -rs 2>&1 | Tee-Object -FilePath .\pytest-local.log
```

### 6. Ejecutar la GUI desde fuente

```powershell
.\.venv\Scripts\python.exe -m zentry
```

El proceso debería abrir la ventana de Zentry. Si no lo hace, conserva el error visible y consulta [`SOLUCION_DE_PROBLEMAS_ES.md`](SOLUCION_DE_PROBLEMAS_ES.md). Al cerrar la ventana, la aplicación finaliza; no se ejecuta como administrador automáticamente.

## C. Compilar `Zentry.exe`

### Opción 1: doble clic

Haz doble clic en `build_windows.bat` desde la carpeta del proyecto. El script debe conservar la consola, mostrar `[PASO 1/8]` a `[PASO 8/8]`, detenerse si fallan sintaxis/tests y abrir `dist` solo después de verificar el EXE.

### Opción 2: PowerShell con logs

```powershell
.\build_windows.ps1
```

Este script crea un transcript con marca de tiempo en `.build-logs\build_YYYYMMDD_HHMMSS.log`. No uses `-NonInteractive` localmente salvo que quieras evitar la espera final y la apertura de Explorer; ese switch se emplea en CI.

### Opción 3: guardar toda la salida del BAT

```powershell
New-Item -ItemType Directory -Force .build-logs | Out-Null
.\build_windows.bat 2>&1 | Tee-Object -FilePath .\.build-logs\build-local.log
```

### Resultado

El constructor espera crear:

```text
C:\Zentry\dist\Zentry.exe
```

Además verifica que el archivo exista y tenga tamaño mayor que cero. La comprobación de tamaño no prueba las interacciones de la GUI. Abre el EXE manualmente y revisa todas las páginas antes de distribuirlo.

## D. Qué hace y qué no hace el constructor

Hace: detecta CPython funcional; crea/reutiliza `.venv`; instala `requirements-dev.txt`; ejecuta `pip check`, `compileall` y pytest; limpia `build`, `dist`, `Zentry.spec` generado y cachés de `zentry/` y `tests/`; ejecuta PyInstaller `--onefile --windowed`; verifica el EXE; calcula SHA-256.

No hace: elevación administrativa, cambios de `ExecutionPolicy`, borrado de carpetas fuera del proyecto, limpieza del `.venv`, instalación de Windows ni publicación de una Release. Ten en cuenta que `dist` anterior se limpia después de pasar las pruebas; si las pruebas fallan, un EXE previo podría seguir en `dist` y no debe confundirse con el resultado de esa ejecución.
