# Zentry — seguridad, efectos y limitaciones reales

Este documento describe el comportamiento del código actual. No sustituye una auditoría independiente ni una validación nativa en todas las versiones/configuraciones de Windows.

## 1. Matriz de comportamiento y efectos

| Función | Tipo | Efectos | Riesgo / límite |
|---|---|---|---|
| Resumen CPU/RAM/disco | Solo lectura | Consulta datos del sistema en memoria | Las métricas varían en el tiempo; valores no disponibles no equivalen a cero. |
| Vista Procesos | Solo lectura | Enumera procesos y datos básicos | Los procesos pueden desaparecer o denegar acceso durante la lectura. No se terminan. |
| Vista Inicio | Solo lectura | Lee claves estándar `Run`/`RunOnce` y carpetas de inicio conocidas | No es un inventario de todos los mecanismos de autoarranque de Windows. No modifica entradas. |
| Escaneo de archivos antiguos | Solo lectura | Enumeración de raíces aprobadas y lectura de metadatos | La edad no prueba que el archivo sea basura; los errores de acceso pueden dejar elementos sin inspeccionar. |
| Protección del sistema | Solo lectura | Recorre árboles configurados y cuenta categorías | Informativo; no inspecciona exhaustivamente todos los volúmenes, particiones EFI o recuperación. |
| Vista previa de limpieza | Solo lectura | Calcula cantidad de candidatos/bytes estimados | La estimación puede variar si los archivos cambian antes de actuar. |
| Limpiar selección | **Efecto en archivos** | Revalida e intenta enviar candidatos registrados a la Papelera | No hay borrado permanente alternativo en Zentry; aun así la recuperación no puede garantizarse en todos los volúmenes/entornos. |
| Borrar historial | **Elimina un archivo de datos local** | Elimina solo el archivo `history.json` configurado tras confirmación | No borra logs ni carpetas recursivamente. Puede fallar por permisos. |
| Logging | Escritura local | Crea y rota logs | Deben revisarse los logs antes de compartirlos, aunque el diseño minimiza datos personales. |
| Build local | Cambia el árbol del proyecto | Instala dependencias en `.venv`, limpia artefactos de build bajo la raíz y escribe `dist`/logs | No afecta deliberadamente servicios/Registro de Windows; puede reemplazar `build`, `dist`, `Zentry.spec` y bytecode dentro de `zentry/` y `tests/`. |

## 2. Raíces admitidas por el scanner

`default_cleanup_roots()` configura únicamente estas ubicaciones conocidas, si las rutas están disponibles:

- `%TEMP%`; si no está definida, `%TMP%`.
- `%SystemRoot%\Temp`.
- Caché predeterminada de Chrome: `%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache`.
- Caché predeterminada de Edge: `%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache`.
- `cache2` de perfiles de Firefox identificados dentro de `%LOCALAPPDATA%\Mozilla\Firefox\Profiles`.

No se habilita la raíz entera de `C:\`, el perfil completo del usuario, todo `AppData`, todo `Program Files` ni todo `%SystemRoot%` como raíz de limpieza genérica. Las raíces amplias se rechazan. Las ubicaciones exactas de caché dependen de perfiles/configuración; que una app use otra ruta significa que Zentry puede no encontrarla.

## 3. Regla de antigüedad

- Predeterminado: 31 días; configuración permitida: 1–3650 días.
- Tanto el último acceso como la última modificación deben ser anteriores al corte.
- Fechas ausentes, inválidas, incoherentes, futuras o que no se puedan leer llevan a exclusión/revisión, no a permiso.
- Los directorios no se ofrecen como candidatos; el escáner descubre archivos regulares.
- Los detalles de cada archivo son datos temporales de sesión y no deben persistirse en el historial agregado.

**Límite esencial:** Windows puede deshabilitar o diferir la actualización del último acceso. Una fecha antigua puede ser poco fiable y tampoco prueba que el archivo sea innecesario. El alcance limitado, las reglas de clasificación y la confirmación son barreras adicionales, no garantías absolutas.

## 4. SafetyClassifier y Windows Resource Protection (WRP)

`WindowsSafetyClassifier` protege rutas críticas conocidas, archivos especiales y recursos contextuales, rechaza rutas fuera del ámbito y comprueba objetos que parezcan symlink/junction/reparse point. En Windows consulta `SfcIsFileProtected`/WRP cuando el mecanismo esté disponible.

La lista estática de rutas es una defensa conservadora y **no identifica exhaustivamente todos los archivos críticos de todas las ediciones, arquitecturas y estados de Windows**. WRP tampoco representa todos los elementos importantes de todas las aplicaciones. La disponibilidad de la API no convierte un archivo en candidato; solo aporta una comprobación adicional.

Si la ubicación/identidad no es conocida, los metadatos no pueden leerse o una verificación queda indeterminada, el comportamiento esperado es revisión/bloqueo. Nunca uses la clasificación como una recomendación para borrar manualmente archivos fuera de las raíces permitidas.

El provider tiene contratos enriquecidos que pueden representar métricas desconocidas como `None` y estados parciales; los adaptadores de compatibilidad más antiguos usan modelos con campos numéricos obligatorios. En esos caminos, una métrica obligatoria no disponible puede provocar un estado de error o la omisión de filas incompletas, en vez de mostrar `N/D` por cada campo.

## 5. Revalidación y carrera entre procesos

`CleanupService` registra referencias exactas de candidatos procedentes del escaneo, genera una vista previa y necesita `confirmed=True` para una selección no vacía. La capa de GUI no autoriza por sí sola ninguna ruta. El servicio vuelve a comprobar raíz, path, metadatos/huella, antigüedad, tipo de archivo y clasificación antes de llamar a `send2trash`.

Queda una limitación TOCTOU (time-of-check to time-of-use): la ruta puede cambiar entre la última validación y la llamada a la Papelera. La biblioteca recibe una ruta, no un handle inmutable del archivo. Por eso se informa el resultado y no se promete recuperación garantizada.

Si `send2trash` arroja un error, Zentry informa del fallo y no ejecuta `unlink()`, `rmtree()` ni otro fallback de eliminación permanente. Después de la llamada, el sistema verifica si la ruta todavía existe; que no exista es una comprobación de resultado, no una garantía de recuperación futura.

## 6. Historial y privacidad

En Windows, el estado local está normalmente en `%LOCALAPPDATA%\Zentry`:

- `history.json`: eventos agregados y versionados.
- `logs\zentry.log`: log rotativo, tamaño máximo predeterminado de 1 MiB por archivo y tres respaldos.

El historial usa esquema `schema_version: 2`, acepta como máximo 500 eventos y rechaza archivos por encima de 4 MiB al cargarlos. Puede incluir marca de tiempo, tipo y resultado de operación, contadores, cantidades de bytes estimados/movidos, códigos de error y métricas agregadas. El contrato persistido no almacena rutas de candidatos, nombres de archivo, contenido, nombres de proceso, PID ni comandos de inicio.

Un JSON con sintaxis corrupta se trata como un error recuperable y el siguiente `append` empieza un historial nuevo; ese contenido corrupto no se conserva. Un esquema futuro desconocido y los errores de permisos no se sobrescriben automáticamente. El botón de historial no elimina los logs.

El botón **Borrar historial** elimina solo el JSON del historial después de confirmación; los logs permanecen. Para compartir logs, revisa/redacta nombre de usuario, rutas, organización y cualquier dato de entorno. No adjuntes `history.json` si no es necesario.

## 7. Funciones ausentes / decisiones pendientes

- No hay IA ni proveedor cloud/local integrado.
- No hay desinstalador, parada de procesos, deshabilitación de programas de inicio ni edición del Registro.
- No hay instalador, firma digital declarada ni actualización automática.
- No se ha elegido una licencia. Hasta que se añada `LICENSE` con una decisión expresa, no atribuyas una licencia al proyecto.
- El workflow contiene un smoke test corto de inicio; no sustituye prueba manual de cada página, accesibilidad, DPI, antivirus ni flujos de limpieza.
