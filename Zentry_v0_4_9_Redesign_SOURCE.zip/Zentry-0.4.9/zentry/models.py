"""Domain models and internal contracts for Zentry.

The models deliberately do not import Qt, Registry APIs, psutil, or other OS
adapters. Objects containing paths, process details, or startup commands are
session-only. ``ScanHistoryItem`` retains a compatibility contract for legacy
aggregate snapshots; current operation-event history is defined and persisted by
``zentry.core.history.HistoryEvent`` with an explicit versioned schema.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import ClassVar, Mapping


PERSISTED_HISTORY_SCHEMA_VERSION = 1


class FileClassification(str, Enum):
    """Observed classification of a file, not permission to remove it."""

    SAFE_CANDIDATE = "safe_candidate"
    REVIEW_REQUIRED = "review_required"
    PROTECTED = "protected"
    REPARSE_POINT = "reparse_point"
    INACCESSIBLE = "inaccessible"


class CleanupPolicyDecision(str, Enum):
    """Result of applying a cleanup policy to a candidate.

    ``NOT_EVALUATED`` is the safe default: being discovered as a
    ``SAFE_CANDIDATE`` does not itself authorize deletion. ``ALLOW`` means a
    policy evaluation permitted an action at that point in time; callers must
    still revalidate the path and file metadata immediately before acting.
    """

    NOT_EVALUATED = "not_evaluated"
    ALLOW = "allow"
    BLOCK = "block"
    REVIEW_REQUIRED = "review_required"


class CleanupOutcome(str, Enum):
    """Derived summary of a cleanup operation's aggregate counters."""

    NO_SELECTION = "no_selection"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"
    SKIPPED = "skipped"
    INCOMPLETE = "incomplete"


def _require_non_empty_string(value: object, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string")


def _require_string(value: object, field_name: str) -> None:
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string")


def _require_non_negative_int(value: object, field_name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{field_name} must be an integer")
    if value < 0:
        raise ValueError(f"{field_name} must be >= 0")


def _require_finite_number(value: object, field_name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a number")
    if not math.isfinite(float(value)):
        raise ValueError(f"{field_name} must be finite")


def _require_percent(value: object, field_name: str) -> None:
    _require_finite_number(value, field_name)
    if not 0 <= float(value) <= 100:
        raise ValueError(f"{field_name} must be between 0 and 100")


def _require_aware_datetime(value: object, field_name: str) -> None:
    if not isinstance(value, datetime):
        raise TypeError(f"{field_name} must be a datetime")
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"{field_name} must be timezone-aware")


def _record_int(record: Mapping[str, object], key: str, *, default: object = ...) -> int:
    value = record[key] if key in record else default
    if value is ...:
        raise ValueError(f"Missing required history field: {key}")
    _require_non_negative_int(value, key)
    return value


def _record_number(record: Mapping[str, object], key: str) -> float:
    if key not in record:
        raise ValueError(f"Missing required history field: {key}")
    value = record[key]
    _require_finite_number(value, key)
    return float(value)


@dataclass(frozen=True)
class SystemSnapshot:
    """System metrics collected for the current session.

    Aggregate values may be copied into ``ScanHistoryItem`` for persistence.
    This object itself is not written to disk by the domain layer.
    """

    cpu_percent: float
    memory_percent: float
    disk_percent: float
    disk_free_gb: float
    startup_count: int
    startup_high_impact_count: int
    process_count: int
    collected_at: datetime = field(default_factory=lambda: datetime.now().astimezone())

    def __post_init__(self) -> None:
        _require_percent(self.cpu_percent, "cpu_percent")
        _require_percent(self.memory_percent, "memory_percent")
        _require_percent(self.disk_percent, "disk_percent")
        _require_finite_number(self.disk_free_gb, "disk_free_gb")
        if self.disk_free_gb < 0:
            raise ValueError("disk_free_gb must be >= 0")
        _require_non_negative_int(self.startup_count, "startup_count")
        _require_non_negative_int(
            self.startup_high_impact_count, "startup_high_impact_count"
        )
        _require_non_negative_int(self.process_count, "process_count")
        if self.startup_high_impact_count > self.startup_count:
            raise ValueError("startup_high_impact_count cannot exceed startup_count")
        _require_aware_datetime(self.collected_at, "collected_at")

    @property
    def health_score(self) -> int:
        """Return the existing heuristic score (not a clinical/system guarantee)."""
        penalties = 0
        if self.cpu_percent >= 90:
            penalties += 25
        elif self.cpu_percent >= 75:
            penalties += 12
        if self.memory_percent >= 90:
            penalties += 25
        elif self.memory_percent >= 80:
            penalties += 12
        if self.disk_percent >= 95:
            penalties += 25
        elif self.disk_percent >= 85:
            penalties += 12
        penalties += min(self.startup_high_impact_count * 3, 15)
        return max(0, 100 - penalties)


@dataclass(frozen=True)
class StartupEntry:
    """Startup item for display during the current session only.

    ``command`` can contain usernames, paths, command-line arguments, or other
    local details. Do not include this object in persistent history/logs.
    """

    name: str = field(metadata={"privacy": "session_only"})
    command: str = field(metadata={"privacy": "session_only"})
    source: str = field(metadata={"privacy": "session_only"})

    def __post_init__(self) -> None:
        _require_string(self.name, "name")
        _require_string(self.command, "command")
        _require_non_empty_string(self.source, "source")


@dataclass(frozen=True)
class ProcessInfo:
    """Transient process metrics; process names and PIDs are session-only."""

    pid: int = field(metadata={"privacy": "session_only"})
    name: str = field(metadata={"privacy": "session_only"})
    cpu_percent: float
    memory_percent: float
    status: str = field(metadata={"privacy": "session_only"})

    def __post_init__(self) -> None:
        _require_non_negative_int(self.pid, "pid")
        _require_non_empty_string(self.name, "name")
        _require_finite_number(self.cpu_percent, "cpu_percent")
        if self.cpu_percent < 0:
            raise ValueError("cpu_percent must be >= 0")
        _require_percent(self.memory_percent, "memory_percent")
        _require_non_empty_string(self.status, "status")


@dataclass(frozen=True)
class FileFingerprint:
    """Session-only file metadata used by a future revalidation contract.

    Device/file identifiers are best-effort platform metadata. They must not
    be treated as globally unique or as a substitute for a fresh safety check.
    """

    size_bytes: int
    accessed_ns: int
    modified_ns: int
    device_id: int | None = None
    file_id: int | None = None

    def __post_init__(self) -> None:
        _require_non_negative_int(self.size_bytes, "size_bytes")
        # Timestamps may be negative for files whose timestamp predates the Unix
        # epoch, so enforce integer type without imposing a lower bound.
        for field_name in ("accessed_ns", "modified_ns"):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(f"{field_name} must be an integer")
        for field_name in ("device_id", "file_id"):
            value = getattr(self, field_name)
            if value is not None:
                _require_non_negative_int(value, field_name)


@dataclass(frozen=True)
class FileCandidate:
    """A discovered file, not an authorization to delete it.

    ``path``, ``name``, timestamps, reason, and fingerprint are session-only.
    They must not be copied into persistent history. ``policy_decision`` is
    intentionally ``NOT_EVALUATED`` unless a dedicated policy layer assigns a
    result; even ``ALLOW`` requires operation-time revalidation.
    """

    path: str = field(metadata={"privacy": "session_only", "persist": False})
    name: str = field(metadata={"privacy": "session_only", "persist": False})
    category: str
    size_bytes: int
    last_access: datetime = field(metadata={"privacy": "session_only", "persist": False})
    last_modified: datetime = field(metadata={"privacy": "session_only", "persist": False})
    classification: FileClassification
    reason: str = field(metadata={"privacy": "session_only", "persist": False})
    policy_decision: CleanupPolicyDecision = CleanupPolicyDecision.NOT_EVALUATED
    fingerprint: FileFingerprint | None = field(
        default=None,
        repr=False,
        metadata={"privacy": "session_only", "persist": False},
    )

    def __post_init__(self) -> None:
        _require_non_empty_string(self.path, "path")
        _require_non_empty_string(self.name, "name")
        _require_non_empty_string(self.category, "category")
        _require_non_negative_int(self.size_bytes, "size_bytes")
        _require_aware_datetime(self.last_access, "last_access")
        _require_aware_datetime(self.last_modified, "last_modified")
        _require_string(self.reason, "reason")
        if not isinstance(self.classification, FileClassification):
            raise TypeError("classification must be a FileClassification")
        if not isinstance(self.policy_decision, CleanupPolicyDecision):
            raise TypeError("policy_decision must be a CleanupPolicyDecision")
        if self.fingerprint is not None:
            if not isinstance(self.fingerprint, FileFingerprint):
                raise TypeError("fingerprint must be a FileFingerprint or None")
            if self.fingerprint.size_bytes != self.size_bytes:
                raise ValueError("fingerprint size must match size_bytes")
        if (
            self.policy_decision is CleanupPolicyDecision.ALLOW
            and self.classification is not FileClassification.SAFE_CANDIDATE
        ):
            raise ValueError(
                "Only SAFE_CANDIDATE items may have an ALLOW policy decision"
            )
    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024**2)

    @property
    def size_gb(self) -> float:
        return self.size_bytes / (1024**3)


@dataclass(frozen=True)
class CleanupScanSummary:
    """Session-only results from a cleanup scan; may contain private paths."""

    candidates: tuple[FileCandidate, ...]
    scanned_roots: int
    scanned_files: int
    protected_files: int
    review_files: int
    inaccessible_items: int
    skipped_reparse_points: int

    def __post_init__(self) -> None:
        if not isinstance(self.candidates, tuple):
            raise TypeError("candidates must be a tuple")
        if not all(isinstance(item, FileCandidate) for item in self.candidates):
            raise TypeError("candidates must contain FileCandidate instances")
        for field_name in (
            "scanned_roots",
            "scanned_files",
            "protected_files",
            "review_files",
            "inaccessible_items",
            "skipped_reparse_points",
        ):
            _require_non_negative_int(getattr(self, field_name), field_name)

    @property
    def reclaimable_bytes(self) -> int:
        """Estimate eligible bytes, never a promise or deletion authorization."""
        return sum(
            item.size_bytes
            for item in self.candidates
            if item.classification is FileClassification.SAFE_CANDIDATE
            and item.policy_decision
            in {
                CleanupPolicyDecision.NOT_EVALUATED,
                CleanupPolicyDecision.ALLOW,
            }
        )


@dataclass(frozen=True)
class CleanupResult:
    """Aggregate operation outcome; contains no individual filenames or paths.

    ``skipped_changed_files`` counts selected files whose identity, metadata,
    age, or path changed during revalidation. ``skipped_files`` counts other
    safety/policy omissions, including candidates not originating in the active
    scan. Both fields default to zero for backward compatibility.
    """

    selected_files: int
    moved_files: int
    moved_bytes: int
    failed_files: int
    skipped_changed_files: int
    skipped_files: int = 0

    def __post_init__(self) -> None:
        for field_name in (
            "selected_files",
            "moved_files",
            "moved_bytes",
            "failed_files",
            "skipped_changed_files",
            "skipped_files",
        ):
            _require_non_negative_int(getattr(self, field_name), field_name)
        outcomes = (
            self.moved_files
            + self.failed_files
            + self.skipped_changed_files
            + self.skipped_files
        )
        if outcomes > self.selected_files:
            raise ValueError("cleanup outcomes cannot exceed selected_files")
        if self.moved_files == 0 and self.moved_bytes != 0:
            raise ValueError("moved_bytes must be zero when moved_files is zero")

    @property
    def omitted_files(self) -> int:
        """Total selected files omitted because they changed or were blocked."""
        return self.skipped_changed_files + self.skipped_files

    @property
    def outcome(self) -> CleanupOutcome:
        if self.selected_files == 0:
            return CleanupOutcome.NO_SELECTION
        accounted = (
            self.moved_files
            + self.failed_files
            + self.skipped_changed_files
            + self.skipped_files
        )
        if accounted < self.selected_files:
            return CleanupOutcome.INCOMPLETE
        if self.moved_files == self.selected_files:
            return CleanupOutcome.COMPLETED
        if self.moved_files > 0:
            return CleanupOutcome.PARTIAL
        if self.omitted_files > 0 and self.failed_files == 0:
            return CleanupOutcome.SKIPPED
        return CleanupOutcome.FAILED


@dataclass(frozen=True)
class SystemProtectionSummary:
    """Session-only protection scan summary; roots are not persisted."""

    roots_checked: int
    files_seen: int
    protected_files: int
    system_managed_files: int
    inaccessible_items: int
    protected_roots: tuple[str, ...] = field(
        metadata={"privacy": "session_only", "persist": False}
    )

    def __post_init__(self) -> None:
        for field_name in (
            "roots_checked",
            "files_seen",
            "protected_files",
            "system_managed_files",
            "inaccessible_items",
        ):
            _require_non_negative_int(getattr(self, field_name), field_name)
        if not isinstance(self.protected_roots, tuple):
            raise TypeError("protected_roots must be a tuple")
        if not all(isinstance(root, str) and root.strip() for root in self.protected_roots):
            raise ValueError("protected_roots must contain non-empty strings")


@dataclass(frozen=True)
class ScanHistoryItem:
    """Persistable aggregate metrics; intentionally excludes paths and names.

    This model remains the compatibility format for legacy aggregate snapshots.
    New operation history uses ``HistoryEvent`` in ``zentry.core.history``. Use
    ``to_persistence_record`` and ``from_persistence_record`` for legacy records.
    """

    timestamp: datetime = field(metadata={"privacy": "aggregate", "persist": True})
    health_score: int = field(metadata={"privacy": "aggregate", "persist": True})
    cpu_percent: float = field(metadata={"privacy": "aggregate", "persist": True})
    memory_percent: float = field(metadata={"privacy": "aggregate", "persist": True})
    disk_percent: float = field(metadata={"privacy": "aggregate", "persist": True})
    reclaimable_bytes: int = field(metadata={"privacy": "aggregate", "persist": True})
    cleaned_bytes: int = field(
        default=0,
        metadata={"privacy": "aggregate", "persist": True},
    )

    SCHEMA_VERSION: ClassVar[int] = PERSISTED_HISTORY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _require_aware_datetime(self.timestamp, "timestamp")
        if isinstance(self.health_score, bool) or not isinstance(self.health_score, int):
            raise TypeError("health_score must be an integer")
        if not 0 <= self.health_score <= 100:
            raise ValueError("health_score must be between 0 and 100")
        _require_percent(self.cpu_percent, "cpu_percent")
        _require_percent(self.memory_percent, "memory_percent")
        _require_percent(self.disk_percent, "disk_percent")
        _require_non_negative_int(self.reclaimable_bytes, "reclaimable_bytes")
        _require_non_negative_int(self.cleaned_bytes, "cleaned_bytes")

    def to_persistence_record(self) -> dict[str, object]:
        """Return only the approved, privacy-minimized history fields."""
        return {
            "schema_version": self.SCHEMA_VERSION,
            "timestamp": self.timestamp.isoformat(),
            "health_score": self.health_score,
            "cpu_percent": self.cpu_percent,
            "memory_percent": self.memory_percent,
            "disk_percent": self.disk_percent,
            "reclaimable_bytes": self.reclaimable_bytes,
            "cleaned_bytes": self.cleaned_bytes,
        }

    @classmethod
    def from_persistence_record(
        cls,
        record: Mapping[str, object],
    ) -> ScanHistoryItem:
        """Validate and load a current or legacy aggregate history record."""
        if not isinstance(record, Mapping):
            raise TypeError("history record must be a mapping")

        version = record.get("schema_version", cls.SCHEMA_VERSION)
        if isinstance(version, bool) or not isinstance(version, int):
            raise TypeError("schema_version must be an integer")
        if version != cls.SCHEMA_VERSION:
            raise ValueError(f"Unsupported history schema version: {version}")

        timestamp_value = record.get("timestamp")
        if not isinstance(timestamp_value, str):
            raise TypeError("timestamp must be an ISO-8601 string")
        try:
            timestamp = datetime.fromisoformat(timestamp_value)
        except ValueError as exc:
            raise ValueError("timestamp must be a valid ISO-8601 datetime") from exc

        health_score = _record_int(record, "health_score")
        return cls(
            timestamp=timestamp,
            health_score=health_score,
            cpu_percent=_record_number(record, "cpu_percent"),
            memory_percent=_record_number(record, "memory_percent"),
            disk_percent=_record_number(record, "disk_percent"),
            reclaimable_bytes=_record_int(record, "reclaimable_bytes", default=0),
            cleaned_bytes=_record_int(record, "cleaned_bytes", default=0),
        )
