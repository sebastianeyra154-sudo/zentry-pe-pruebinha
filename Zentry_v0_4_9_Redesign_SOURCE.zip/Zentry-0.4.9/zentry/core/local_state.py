"""Resolve Zentry's per-user state directory without requiring elevation."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Mapping


def get_app_data_directory(
    *,
    environ: Mapping[str, str] | None = None,
    home_directory: Path | None = None,
    platform: str | None = None,
) -> Path:
    """Return the app's per-user state directory.

    On Windows the preferred location is ``%LOCALAPPDATA%\\Zentry``. A
    fallback mirrors the standard Windows layout when the environment variable
    is missing. On Linux, XDG_STATE_HOME is preferred, then ~/.local/state;
    macOS uses ~/Library/Application Support/Zentry.

    The function only calculates a path; it does not create directories.
    Arguments are injectable so path behavior can be tested without touching
    the user's real profile.
    """
    env = os.environ if environ is None else environ
    home = Path.home() if home_directory is None else Path(home_directory)
    current_platform = sys.platform if platform is None else platform

    if current_platform.startswith("win"):
        local_app_data = env.get("LOCALAPPDATA")
        if local_app_data and local_app_data.strip():
            return Path(local_app_data) / "Zentry"
        return home / "AppData" / "Local" / "Zentry"

    if current_platform == "darwin":
        return home / "Library" / "Application Support" / "Zentry"

    state_home = env.get("XDG_STATE_HOME")
    if state_home and state_home.strip():
        return Path(state_home) / "zentry"
    return home / ".local" / "state" / "zentry"
