"""Conservative, explainable file classification for Zentry.

This module does not delete, move, or otherwise mutate files. The informational
classification of a path is separate from the generic-cleanup policy decision.
The tuple-returning methods are retained for compatibility with the current
scanner/provider; new code should use ``assess`` or ``assess_for_cleanup``.

The protected path rules are intentionally conservative, not an exhaustive
inventory of every protected resource on every Windows version.
"""

from __future__ import annotations

import ctypes
import os
import stat
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path, PurePath, PureWindowsPath
from typing import Iterable

from zentry.models import CleanupPolicyDecision, FileClassification


_REPARSE_POINT_ATTRIBUTE = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x0400)
_SUSPICIOUS_SYSTEM_EXTENSIONS = frozenset({".dll", ".exe", ".sys"})
_SYSTEM_VOLUME_DIRECTORY = "system volume information"


@dataclass(frozen=True)
class ProtectedPathRule:
    """Known protected path prefix and its user-facing explanation."""

    path: Path
    reason: str


class _WrpStatus(Enum):
    PROTECTED = "protected"
    NOT_PROTECTED = "not_protected"
    UNAVAILABLE = "unavailable"
    NOT_APPLICABLE = "not_applicable"


@dataclass(frozen=True)
class SafetyAssessment:
    """Explainable classification and separate generic-cleanup policy result.

    ``policy_decision=ALLOW`` is only the result of this classifier's checks
    for a known disposable root. It is not a substitute for age-policy checks,
    user confirmation, or operation-time revalidation.
    """

    classification: FileClassification
    reason: str
    policy_decision: CleanupPolicyDecision = CleanupPolicyDecision.NOT_EVALUATED
    policy_reason: str = "Generic-cleanup policy was not evaluated."

    def __post_init__(self) -> None:
        if not isinstance(self.classification, FileClassification):
            raise TypeError("classification must be a FileClassification")
        if not isinstance(self.policy_decision, CleanupPolicyDecision):
            raise TypeError("policy_decision must be a CleanupPolicyDecision")
        if not isinstance(self.reason, str) or not self.reason.strip():
            raise ValueError("reason must be a non-empty string")
        if not isinstance(self.policy_reason, str) or not self.policy_reason.strip():
            raise ValueError("policy_reason must be a non-empty string")
        if (
            self.policy_decision is CleanupPolicyDecision.ALLOW
            and self.classification is not FileClassification.SAFE_CANDIDATE
        ):
            raise ValueError("ALLOW requires SAFE_CANDIDATE classification")

    @property
    def cleanup_permitted_by_classifier(self) -> bool:
        """Return whether this classifier's current assessment passed."""
        return (
            self.classification is FileClassification.SAFE_CANDIDATE
            and self.policy_decision is CleanupPolicyDecision.ALLOW
        )


class WindowsSafetyClassifier:
    """Classify paths conservatively without performing cleanup operations."""

    def __init__(self) -> None:
        system_root_value = os.environ.get("SystemRoot", r"C:\Windows")
        self._system_root = Path(system_root_value)
        drive_value = os.environ.get("SystemDrive", "C:")
        if not drive_value.endswith(("\\", "/")):
            drive_value += os.sep
        self._system_drive = Path(drive_value)
        self._is_windows = sys.platform == "win32"
        self._protected_rules = self._build_protected_rules()
        self._wrp_checker = self._load_wrp_checker()

    @property
    def protected_rules(self) -> tuple[ProtectedPathRule, ...]:
        return self._protected_rules

    def assess(self, path: Path) -> SafetyAssessment:
        """Classify a path for information only; do not authorize cleanup."""
        normalized = self._normalize_input_path(path)
        if isinstance(normalized, SafetyAssessment):
            return normalized
        lexical_path = normalized

        protected_reason = self._protected_reason(lexical_path)
        if protected_reason is not None:
            return self._result(
                FileClassification.PROTECTED,
                protected_reason,
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        contextual_classification = self._contextual_system_file_classification(
            lexical_path
        )
        if contextual_classification is not None:
            classification, reason = contextual_classification
            return self._result(
                classification, reason, CleanupPolicyDecision.NOT_EVALUATED
            )

        inspection = self._inspect_existing_path(lexical_path)
        if isinstance(inspection, SafetyAssessment):
            return inspection
        resolved_path, file_stat = inspection

        protected_reason = self._protected_reason(resolved_path)
        if protected_reason is not None:
            return self._result(
                FileClassification.PROTECTED,
                protected_reason,
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        contextual_classification = self._contextual_system_file_classification(
            resolved_path
        )
        if contextual_classification is not None:
            classification, reason = contextual_classification
            return self._result(
                classification, reason, CleanupPolicyDecision.NOT_EVALUATED
            )

        if not stat.S_ISREG(file_stat.st_mode):
            return self._result(
                FileClassification.REVIEW_REQUIRED,
                "The path is not a regular file; generic cleanup does not apply.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        wrp_status = self._check_wrp(resolved_path)
        if wrp_status is _WrpStatus.PROTECTED:
            return self._result(
                FileClassification.PROTECTED,
                "Windows Resource Protection reports this file as protected.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )
        if wrp_status is _WrpStatus.UNAVAILABLE:
            return self._result(
                FileClassification.REVIEW_REQUIRED,
                "Windows Resource Protection could not be checked; status is unknown.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        if resolved_path.suffix.casefold() in _SUSPICIOUS_SYSTEM_EXTENSIONS:
            return self._result(
                FileClassification.REVIEW_REQUIRED,
                "This extension can indicate executable/system code; "
                "manual review is required.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        return self._result(
            FileClassification.REVIEW_REQUIRED,
            "The path is not known to be disposable; cleanup eligibility "
            "is not inferred.",
            CleanupPolicyDecision.NOT_EVALUATED,
        )

    def classify(self, path: Path) -> tuple[FileClassification, str]:
        """Backward-compatible informational classification tuple."""
        assessment = self.assess(path)
        return assessment.classification, assessment.reason

    def assess_for_cleanup(
        self,
        path: Path,
        allowed_roots: Iterable[Path],
        disposable_reason: str,
    ) -> SafetyAssessment:
        """Classify a file and evaluate generic-cleanup scope separately.

        ``ALLOW`` only means the file passed the classifier's current checks in
        an explicitly disposable root. The caller must still enforce age rules,
        ask for user confirmation, and revalidate immediately before acting.
        """
        normalized = self._normalize_input_path(path)
        if isinstance(normalized, SafetyAssessment):
            return self._with_policy_failure(normalized)
        lexical_path = normalized

        protected_reason = self._protected_reason(lexical_path)
        if protected_reason is not None:
            return self._blocked(FileClassification.PROTECTED, protected_reason)

        contextual_classification = self._contextual_system_file_classification(
            lexical_path
        )
        if contextual_classification is not None:
            classification, reason = contextual_classification
            if classification is FileClassification.PROTECTED:
                return self._blocked(classification, reason)
            return self._needs_review(classification, reason)

        inspection = self._inspect_existing_path(lexical_path)
        if isinstance(inspection, SafetyAssessment):
            return self._with_policy_failure(inspection)
        resolved_path, file_stat = inspection

        protected_reason = self._protected_reason(resolved_path)
        if protected_reason is not None:
            return self._blocked(FileClassification.PROTECTED, protected_reason)

        contextual_classification = self._contextual_system_file_classification(
            resolved_path
        )
        if contextual_classification is not None:
            classification, reason = contextual_classification
            if classification is FileClassification.PROTECTED:
                return self._blocked(classification, reason)
            return self._needs_review(classification, reason)

        if not stat.S_ISREG(file_stat.st_mode):
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "The path is not a regular file; generic cleanup does not apply.",
            )

        root_result = self._find_matching_allowed_root(resolved_path, allowed_roots)
        if isinstance(root_result, SafetyAssessment):
            return self._with_policy_failure(root_result)
        if root_result is None:
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "The resolved path is outside all explicitly disposable roots.",
            )

        wrp_status = self._check_wrp(resolved_path)
        if wrp_status is _WrpStatus.PROTECTED:
            return self._blocked(
                FileClassification.PROTECTED,
                "Windows Resource Protection reports this file as protected.",
            )
        if wrp_status is _WrpStatus.UNAVAILABLE:
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "Windows Resource Protection could not be checked; "
                "cleanup is not authorized.",
            )

        if resolved_path.suffix.casefold() in _SUSPICIOUS_SYSTEM_EXTENSIONS:
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "This extension can indicate executable/system code; "
                "manual review is required.",
            )

        if not isinstance(disposable_reason, str) or not disposable_reason.strip():
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "No disposable-location rationale was supplied; "
                "cleanup is not authorized.",
            )

        return SafetyAssessment(
            classification=FileClassification.SAFE_CANDIDATE,
            reason=disposable_reason.strip(),
            policy_decision=CleanupPolicyDecision.ALLOW,
            policy_reason=(
                "Classifier checks passed for a regular file inside an explicitly "
                "disposable root. Age, confirmation, and operation-time checks "
                "remain required."
            ),
        )

    def classify_for_cleanup(
        self,
        path: Path,
        allowed_roots: Iterable[Path],
        disposable_reason: str,
    ) -> tuple[FileClassification, str]:
        """Compatibility wrapper retained for the existing scanner/provider.

        Prefer ``assess_for_cleanup`` in new code so callers can inspect the
        independent ``policy_decision`` instead of inferring it from the enum.
        """
        assessment = self.assess_for_cleanup(path, allowed_roots, disposable_reason)
        return assessment.classification, assessment.reason

    def is_under_allowed_root(
        self,
        path: Path,
        allowed_roots: Iterable[Path],
    ) -> bool:
        """Compare canonical paths by path components, never by string prefix."""
        try:
            resolved_path = path.resolve(strict=False)
            roots = tuple(allowed_roots)
        except (OSError, RuntimeError, TypeError):
            return False

        for root in roots:
            try:
                resolved_root = root.resolve(strict=False)
            except (OSError, RuntimeError, TypeError):
                continue
            if self._is_path_within(resolved_path, resolved_root):
                return True
        return False

    def protected_root_strings(self) -> tuple[str, ...]:
        """Return the configured known protected roots for display/reporting."""
        return tuple(str(rule.path) for rule in self._protected_rules)

    @staticmethod
    def _result(
        classification: FileClassification,
        reason: str,
        policy_decision: CleanupPolicyDecision,
        policy_reason: str = "Generic-cleanup policy was not evaluated.",
    ) -> SafetyAssessment:
        return SafetyAssessment(
            classification=classification,
            reason=reason,
            policy_decision=policy_decision,
            policy_reason=policy_reason,
        )

    @staticmethod
    def _blocked(
        classification: FileClassification,
        reason: str,
    ) -> SafetyAssessment:
        return SafetyAssessment(
            classification=classification,
            reason=reason,
            policy_decision=CleanupPolicyDecision.BLOCK,
            policy_reason="Cleanup is blocked by a safety rule.",
        )

    @staticmethod
    def _needs_review(
        classification: FileClassification,
        reason: str,
    ) -> SafetyAssessment:
        return SafetyAssessment(
            classification=classification,
            reason=reason,
            policy_decision=CleanupPolicyDecision.REVIEW_REQUIRED,
            policy_reason=(
                "Cleanup is not permitted because the state is uncertain "
                "or requires review."
            ),
        )

    @staticmethod
    def _with_policy_failure(assessment: SafetyAssessment) -> SafetyAssessment:
        """Convert an inspection failure to an explicit non-permitting policy."""
        if assessment.classification in {
            FileClassification.PROTECTED,
            FileClassification.REPARSE_POINT,
            FileClassification.INACCESSIBLE,
        }:
            return SafetyAssessment(
                classification=assessment.classification,
                reason=assessment.reason,
                policy_decision=CleanupPolicyDecision.BLOCK,
                policy_reason=(
                    "Cleanup is blocked because inspection failed or a "
                    "protected object was found."
                ),
            )
        return WindowsSafetyClassifier._needs_review(
            assessment.classification, assessment.reason
        )

    def _normalize_input_path(self, path: Path) -> Path | SafetyAssessment:
        try:
            candidate = Path(path)
        except (TypeError, ValueError, OSError):
            return self._result(
                FileClassification.INACCESSIBLE,
                "The path value is invalid and could not be inspected.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        if not candidate.is_absolute():
            return self._result(
                FileClassification.REVIEW_REQUIRED,
                "An absolute path is required for reliable classification.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )
        if ".." in candidate.parts:
            return self._result(
                FileClassification.REVIEW_REQUIRED,
                "Parent-directory traversal is not accepted for classification.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )
        return candidate

    def _inspect_existing_path(
        self,
        path: Path,
    ) -> tuple[Path, os.stat_result] | SafetyAssessment:
        reparse_status = self._inspect_reparse_chain(path)
        if reparse_status is True:
            return self._result(
                FileClassification.REPARSE_POINT,
                "A symbolic link, junction, or reparse point exists in "
                "the path; inspection is blocked.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )
        if reparse_status is None:
            return self._result(
                FileClassification.INACCESSIBLE,
                "The path's reparse-point status could not be determined.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        try:
            resolved_path = path.resolve(strict=True)
            file_stat = os.lstat(resolved_path)
        except (OSError, RuntimeError, ValueError):
            return self._result(
                FileClassification.INACCESSIBLE,
                "The path could not be resolved and inspected safely.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )

        # Check once more after canonicalization to narrow replacement races.
        final_reparse_status = self._stat_reparse_status(file_stat)
        if final_reparse_status is True:
            return self._result(
                FileClassification.REPARSE_POINT,
                "The path became a reparse point during inspection; "
                "cleanup is blocked.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )
        if final_reparse_status is None:
            return self._result(
                FileClassification.INACCESSIBLE,
                "Windows reparse-point metadata was unavailable during inspection.",
                CleanupPolicyDecision.NOT_EVALUATED,
            )
        return resolved_path, file_stat

    @staticmethod
    def _inspect_reparse_chain(path: Path) -> bool | None:
        """Return True/False, or None when reparse metadata cannot be read."""
        try:
            current = path.absolute()
            while True:
                try:
                    current_stat = os.lstat(current)
                except (OSError, PermissionError, ValueError):
                    return None
                reparse_status = WindowsSafetyClassifier._stat_reparse_status(
                    current_stat
                )
                if reparse_status is not False:
                    return reparse_status
                parent = current.parent
                if parent == current:
                    return False
                current = parent
        except (OSError, RuntimeError, ValueError):
            return None

    @staticmethod
    def _stat_reparse_status(file_stat: os.stat_result) -> bool | None:
        """Return None if Windows cannot provide the required attribute data."""
        if stat.S_ISLNK(file_stat.st_mode):
            return True
        attributes = getattr(file_stat, "st_file_attributes", None)
        if attributes is None:
            return None if sys.platform == "win32" else False
        return bool(attributes & _REPARSE_POINT_ATTRIBUTE)

    def _find_matching_allowed_root(
        self,
        resolved_path: Path,
        allowed_roots: Iterable[Path],
    ) -> Path | SafetyAssessment | None:
        try:
            roots = tuple(allowed_roots)
        except TypeError:
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "The list of allowed roots could not be read.",
            )

        if not roots:
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "No explicitly disposable roots were provided.",
            )

        uncertain_root = False
        for root_value in roots:
            try:
                root = Path(root_value)
                if not root.is_absolute() or ".." in root.parts:
                    uncertain_root = True
                    continue
                root_reparse = self._inspect_reparse_chain(root)
                if root_reparse is None:
                    uncertain_root = True
                    continue
                if root_reparse:
                    # The candidate path is inspected independently as well.
                    # Never trust a root whose own ancestry has a reparse point.
                    uncertain_root = True
                    continue

                resolved_root = root.resolve(strict=True)
                if not resolved_root.is_dir():
                    uncertain_root = True
                    continue
            except (OSError, RuntimeError, TypeError, ValueError):
                uncertain_root = True
                continue

            if self._is_path_within(resolved_path, resolved_root):
                return resolved_root

        if uncertain_root:
            return self._needs_review(
                FileClassification.REVIEW_REQUIRED,
                "One or more allowed roots could not be validated reliably.",
            )
        return None

    def _build_protected_rules(self) -> tuple[ProtectedPathRule, ...]:
        windows = self._system_root
        drive = self._system_drive
        rules = [
            (
                windows / "System32",
                "Windows System32 contains core operating-system resources.",
            ),
            (
                windows / "SysWOW64",
                "Windows SysWOW64 contains 32-bit subsystem resources.",
            ),
            (
                windows / "WinSxS",
                "Windows component store; direct deletion is unsupported.",
            ),
            (windows / "Servicing", "Windows servicing resources are system-managed."),
            (
                windows / "Installer",
                "Windows Installer cache is used to repair, update, and "
                "uninstall applications.",
            ),
            (
                windows / "System32" / "Config",
                "Windows registry hives and related files are protected.",
            ),
            (
                windows / "System32" / "Recovery",
                "Windows recovery resources are protected.",
            ),
            (
                windows / "System32" / "DriverStore",
                "Windows driver package store; direct deletion is unsupported.",
            ),
            (windows / "System32" / "Boot", "Windows boot resources are protected."),
            (windows / "Boot", "Windows boot resources are protected."),
            (windows / "Recovery", "Windows recovery resources are protected."),
            (drive / "Boot", "Volume-root boot configuration resources are protected."),
            (drive / "Recovery", "Volume-root recovery resources are protected."),
            (drive / "EFI", "A volume-root EFI directory may contain boot resources."),
        ]

        program_files_roots = {
            value
            for value in (
                os.environ.get("ProgramFiles"),
                os.environ.get("ProgramFiles(x86)"),
                os.environ.get("ProgramW6432"),
            )
            if value
        }
        for program_files in program_files_roots:
            rules.append(
                (
                    Path(program_files) / "WindowsApps",
                    "Managed Windows application packages are not generic "
                    "cleanup targets.",
                )
            )

        return tuple(
            ProtectedPathRule(path=path, reason=reason) for path, reason in rules
        )

    def _protected_reason(self, path: Path) -> str | None:
        for rule in self._protected_rules:
            try:
                rule_path = rule.path.resolve(strict=False)
            except (OSError, RuntimeError, ValueError):
                # A configured protection root that cannot be canonicalized is
                # handled conservatively by matching its lexical spelling too.
                rule_path = rule.path
            if self._is_path_within(path, rule_path):
                return rule.reason

        components = self._path_components(path)
        if _SYSTEM_VOLUME_DIRECTORY in components:
            return (
                "System Volume Information stores system-managed recovery "
                "and volume metadata."
            )

        # Boot structures may exist on any mounted volume, not only SystemDrive.
        if components[:1] == ("boot",):
            return (
                "A volume-root Boot directory can contain boot "
                "configuration resources."
            )
        if components[:1] == ("efi",):
            return "A volume-root EFI directory may contain boot resources."
        if components[:1] == ("recovery",):
            return "A volume-root Recovery directory may contain recovery resources."

        return None

    @staticmethod
    def _path_components(path: PurePath) -> tuple[str, ...]:
        """Return components without the drive/anchor, case-folded."""
        parts = path.parts
        if parts and path.anchor:
            parts = parts[1:]
        return tuple(
            part.strip("\\/").casefold()
            for part in parts
            if part.strip("\\/")
        )

    def _contextual_system_file_classification(
        self,
        path: Path,
    ) -> tuple[FileClassification, str] | None:
        components = self._path_components(path)
        name = path.name.casefold()
        is_volume_root = bool(
            (path.anchor and path.parent == Path(path.anchor))
            or path.parent == self._system_drive
        )

        if name in {"pagefile.sys", "swapfile.sys", "hiberfil.sys"}:
            if is_volume_root:
                return (
                    FileClassification.PROTECTED,
                    "Windows-managed paging, swap, or hibernation file "
                    "at a volume root.",
                )
            return (
                FileClassification.REVIEW_REQUIRED,
                "The filename resembles a Windows-managed paging or "
                "hibernation file, but its context is not a recognized "
                "volume root.",
            )

        if name in {"ntuser.dat", "usrclass.dat"}:
            profile_root = os.environ.get("USERPROFILE")
            local_app_data = os.environ.get("LOCALAPPDATA")
            under_profile = bool(
                profile_root
                and self._is_path_within(path, Path(profile_root))
            )
            under_local_app_data = bool(
                local_app_data
                and self._is_path_within(path, Path(local_app_data))
            )
            user_components = {"users", "documents and settings"}
            has_user_profile_component = any(
                component in user_components for component in components
            )
            if (
                under_profile
                or (name == "ntuser.dat" and has_user_profile_component)
                or (
                    name == "usrclass.dat"
                    and (
                        under_local_app_data
                        or components[-4:]
                        == ("appdata", "local", "microsoft", "windows")
                    )
                )
            ):
                return (
                    FileClassification.PROTECTED,
                    "Windows user-profile registry hive; direct deletion is blocked.",
                )
            return (
                FileClassification.REVIEW_REQUIRED,
                "The filename resembles a user-profile registry hive; "
                "its context is not recognized.",
            )

        if name in {"bootmgr", "bootmgfw.efi", "bcd"}:
            in_boot_context = (
                components[:1] == ("boot",)
                or components[:3] == ("efi", "microsoft", "boot")
                or components[-2:] == ("system32", "boot")
            )
            if is_volume_root or in_boot_context:
                return (
                    FileClassification.PROTECTED,
                    "Windows boot-manager or BCD resource; generic "
                    "deletion is blocked.",
                )
            return (
                FileClassification.REVIEW_REQUIRED,
                "The filename resembles a boot resource, but its context "
                "is not recognized.",
            )

        return None

    @staticmethod
    def _is_path_within(path: PurePath, root: PurePath) -> bool:
        """Component-aware containment, including case-insensitive Windows paths."""
        if isinstance(path, PureWindowsPath) and isinstance(root, PureWindowsPath):
            path_parts = tuple(part.casefold() for part in path.parts)
            root_parts = tuple(part.casefold() for part in root.parts)
            return (
                len(path_parts) >= len(root_parts)
                and path_parts[: len(root_parts)] == root_parts
            )
        try:
            path.relative_to(root)
            return True
        except ValueError:
            return False

    @staticmethod
    def _is_reparse_point(path: Path) -> bool:
        """Compatibility helper; uncertain reparse status is treated as unsafe."""
        return WindowsSafetyClassifier._inspect_reparse_chain(path) is not False

    @staticmethod
    def _load_wrp_checker():
        if sys.platform != "win32":
            return None
        try:
            dll = ctypes.WinDLL("sfc.dll", use_last_error=True)
            function = dll.SfcIsFileProtected
            function.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
            function.restype = ctypes.c_int
            return function
        except (AttributeError, OSError, TypeError):
            return None

    def _check_wrp(self, path: Path) -> _WrpStatus:
        """Return tri-state WRP knowledge; missing/failed Windows checks are unknown."""
        if not self._is_windows:
            # WRP is a Windows-specific API. Its absence on other test hosts is
            # not itself an error; explicit path/containment rules still apply.
            return _WrpStatus.NOT_APPLICABLE
        if self._wrp_checker is None:
            return _WrpStatus.UNAVAILABLE
        try:
            result = self._wrp_checker(None, str(path))
        except Exception:
            # This boundary wraps a native function and intentionally treats any
            # call failure as uncertainty, never as permission.
            return _WrpStatus.UNAVAILABLE
        if result is None:
            return _WrpStatus.UNAVAILABLE
        return _WrpStatus.PROTECTED if bool(result) else _WrpStatus.NOT_PROTECTED
