"""Privacy-minimized, versioned local operation history for Zentry."""

from __future__ import annotations

import json
import logging
import os
import re
import stat
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Mapping
from uuid import NAMESPACE_OID, uuid4, uuid5

from zentry.models import ScanHistoryItem

LOGGER = logging.getLogger("zentry.history")
HISTORY_SCHEMA_VERSION = 2
DEFAULT_MAX_ENTRIES = 500
MAX_HISTORY_FILE_BYTES = 4 * 1024 * 1024
_ERROR_CODE_PATTERN = re.compile(r"^[a-z][a-z0-9_.-]{0,63}$")
_EVENT_ID_PATTERN = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$"
)


class HistoryOperation(str, Enum):
    SYSTEM_DIAGNOSTICS = "system_diagnostics"
    STALE_SCAN = "stale_scan"
    SYSTEM_PROTECTION_SCAN = "system_protection_scan"
    CLEANUP = "cleanup"
    APPLICATION_ERROR = "application_error"
    LEGACY_AGGREGATE = "legacy_aggregate"


class HistoryResult(str, Enum):
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    NO_CANDIDATES = "no_candidates"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"
    INCOMPLETE = "incomplete"


def _validate_optional_count(value: object, name: str) -> None:
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{name} must be an integer or None")
    if value < 0:
        raise ValueError(f"{name} must be >= 0")


def _validate_optional_percent(value: object, name: str) -> None:
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a number or None")
    if not 0 <= float(value) <= 100:
        raise ValueError(f"{name} must be between 0 and 100")


@dataclass(frozen=True)
class HistoryEvent:
    """One aggregate history event; deliberately has no paths or item names.

    File names, full paths, process names, startup commands, file contents,
    command-line arguments and raw exception messages are not representable by
    this persistence contract. Per-file details must remain session-only.
    """

    operation_type: HistoryOperation
    result: HistoryResult
    timestamp: datetime = field(default_factory=lambda: datetime.now().astimezone())
    event_id: str = field(default_factory=lambda: str(uuid4()))
    files_seen: int | None = None
    process_count: int | None = None
    candidate_files: int | None = None
    selected_files: int | None = None
    moved_files: int | None = None
    protected_files: int | None = None
    review_files: int | None = None
    inaccessible_items: int | None = None
    roots_checked: int | None = None
    skipped_files: int = 0
    failed_files: int = 0
    estimated_bytes: int | None = None
    moved_bytes: int | None = None
    error_codes: tuple[str, ...] = ()
    health_score: int | None = None
    cpu_percent: float | None = None
    memory_percent: float | None = None
    disk_percent: float | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.operation_type, HistoryOperation):
            raise TypeError("operation_type must be HistoryOperation")
        if not isinstance(self.result, HistoryResult):
            raise TypeError("result must be HistoryResult")
        if not isinstance(self.timestamp, datetime):
            raise TypeError("timestamp must be a datetime")
        if self.timestamp.tzinfo is None or self.timestamp.utcoffset() is None:
            raise ValueError("timestamp must be timezone-aware")
        if (
            not isinstance(self.event_id, str)
            or _EVENT_ID_PATTERN.fullmatch(self.event_id) is None
        ):
            raise ValueError("event_id must be a UUID")
        for field_name in (
            "files_seen",
            "candidate_files",
            "selected_files",
            "moved_files",
            "protected_files",
            "review_files",
            "inaccessible_items",
            "roots_checked",
            "skipped_files",
            "failed_files",
            "estimated_bytes",
            "moved_bytes",
            "health_score",
        ):
            _validate_optional_count(getattr(self, field_name), field_name)
        if self.health_score is not None and self.health_score > 100:
            raise ValueError("health_score must be between 0 and 100")
        for field_name in ("cpu_percent", "memory_percent", "disk_percent"):
            _validate_optional_percent(getattr(self, field_name), field_name)
        if not isinstance(self.error_codes, tuple):
            raise TypeError("error_codes must be a tuple")
        if len(self.error_codes) > 12:
            raise ValueError("error_codes may contain at most 12 entries")
        for code in self.error_codes:
            if (
                not isinstance(code, str)
                or _ERROR_CODE_PATTERN.fullmatch(code) is None
            ):
                raise ValueError("error_codes must contain safe machine-readable codes")

    def to_record(self) -> dict[str, object]:
        """Serialize only explicitly approved aggregate fields."""
        return {
            "event_id": self.event_id,
            "timestamp": self.timestamp.isoformat(),
            "operation_type": self.operation_type.value,
            "result": self.result.value,
            "files_seen": self.files_seen,
            "process_count": self.process_count,
            "candidate_files": self.candidate_files,
            "selected_files": self.selected_files,
            "moved_files": self.moved_files,
            "protected_files": self.protected_files,
            "review_files": self.review_files,
            "inaccessible_items": self.inaccessible_items,
            "roots_checked": self.roots_checked,
            "skipped_files": self.skipped_files,
            "failed_files": self.failed_files,
            "estimated_bytes": self.estimated_bytes,
            "moved_bytes": self.moved_bytes,
            "error_codes": list(self.error_codes),
            "health_score": self.health_score,
            "cpu_percent": self.cpu_percent,
            "memory_percent": self.memory_percent,
            "disk_percent": self.disk_percent,
        }

    @classmethod
    def from_record(cls, record: Mapping[str, object]) -> "HistoryEvent":
        """Load a validated event, ignoring unknown fields rather than re-saving them."""
        if not isinstance(record, Mapping):
            raise TypeError("history event must be an object")
        timestamp_value = record.get("timestamp")
        if not isinstance(timestamp_value, str):
            raise ValueError("history timestamp must be an ISO-8601 string")
        try:
            timestamp = datetime.fromisoformat(timestamp_value)
        except ValueError:
            raise ValueError("history timestamp is invalid") from None

        raw_codes = record.get("error_codes", [])
        if not isinstance(raw_codes, list) or not all(
            isinstance(code, str) for code in raw_codes
        ):
            raise ValueError("history error_codes must be a string array")

        return cls(
            event_id=_required_string(record, "event_id"),
            timestamp=timestamp,
            operation_type=HistoryOperation(_required_string(record, "operation_type")),
            result=HistoryResult(_required_string(record, "result")),
            files_seen=_optional_int(record, "files_seen"),
            process_count=_optional_int(record, "process_count"),
            candidate_files=_optional_int(record, "candidate_files"),
            selected_files=_optional_int(record, "selected_files"),
            moved_files=_optional_int(record, "moved_files"),
            protected_files=_optional_int(record, "protected_files"),
            review_files=_optional_int(record, "review_files"),
            inaccessible_items=_optional_int(record, "inaccessible_items"),
            roots_checked=_optional_int(record, "roots_checked"),
            skipped_files=_optional_int(record, "skipped_files", default=0),
            failed_files=_optional_int(record, "failed_files", default=0),
            estimated_bytes=_optional_int(record, "estimated_bytes"),
            moved_bytes=_optional_int(record, "moved_bytes"),
            error_codes=tuple(raw_codes),
            health_score=_optional_int(record, "health_score"),
            cpu_percent=_optional_float(record, "cpu_percent"),
            memory_percent=_optional_float(record, "memory_percent"),
            disk_percent=_optional_float(record, "disk_percent"),
        )


def _required_string(record: Mapping[str, object], key: str) -> str:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"history {key} must be a non-empty string")
    return value


def _optional_int(
    record: Mapping[str, object], key: str, *, default: int | None = None
) -> int | None:
    value = record.get(key, default)
    _validate_optional_count(value, key)
    return value  # type: ignore[return-value]


def _optional_float(record: Mapping[str, object], key: str) -> float | None:
    value = record.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{key} must be a number or None")
    return float(value)


class HistoryStoreError(RuntimeError):
    """Recoverable history error exposing only a stable, safe error code."""

    def __init__(self, code: str) -> None:
        if _ERROR_CODE_PATTERN.fullmatch(code) is None:
            code = "history_store_error"
        self.code = code
        super().__init__(code)


class HistoryStore:
    """Versioned local JSON store for privacy-minimized operation summaries."""

    def __init__(self, path: Path, *, max_entries: int = DEFAULT_MAX_ENTRIES) -> None:
        if isinstance(max_entries, bool) or not isinstance(max_entries, int):
            raise TypeError("max_entries must be an integer")
        if not 1 <= max_entries <= 10_000:
            raise ValueError("max_entries must be between 1 and 10000")
        self.path = Path(path)
        self.max_entries = max_entries

    def load(self) -> tuple[HistoryEvent, ...]:
        """Read current schema or migrate legacy aggregate history in memory."""
        try:
            file_stat = self.path.lstat()
        except FileNotFoundError:
            return ()
        except OSError as exc:
            raise HistoryStoreError(_os_error_code(exc, "history_read_failed")) from None

        if stat.S_ISLNK(file_stat.st_mode):
            raise HistoryStoreError("history_path_is_symlink")
        if not stat.S_ISREG(file_stat.st_mode):
            raise HistoryStoreError("history_path_not_regular_file")
        if file_stat.st_size > MAX_HISTORY_FILE_BYTES:
            raise HistoryStoreError("history_file_too_large")

        try:
            raw_text = self.path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise HistoryStoreError("history_encoding_invalid") from None
        except OSError as exc:
            raise HistoryStoreError(_os_error_code(exc, "history_read_failed")) from None
        try:
            raw = json.loads(raw_text)
        except json.JSONDecodeError:
            raise HistoryStoreError("history_json_corrupt") from None

        if isinstance(raw, list):
            return self._migrate_legacy_rows(raw)
        if not isinstance(raw, dict):
            raise HistoryStoreError("history_schema_invalid")

        version = raw.get("schema_version")
        if isinstance(version, bool) or not isinstance(version, int):
            raise HistoryStoreError("history_schema_invalid")
        if version != HISTORY_SCHEMA_VERSION:
            raise HistoryStoreError("history_schema_unsupported")
        raw_events = raw.get("events")
        if not isinstance(raw_events, list):
            raise HistoryStoreError("history_schema_invalid")
        if len(raw_events) > self.max_entries:
            raw_events = raw_events[: self.max_entries]
        try:
            return tuple(HistoryEvent.from_record(row) for row in raw_events)
        except (TypeError, ValueError, KeyError):
            raise HistoryStoreError("history_record_invalid") from None

    def append(self, event: HistoryEvent) -> tuple[HistoryEvent, ...]:
        """Add an event and atomically persist the bounded list.

        If JSON syntax is corrupted, the next append starts a new history file.
        Unsupported future schemas and permission errors are not overwritten.
        """
        if not isinstance(event, HistoryEvent):
            raise TypeError("event must be HistoryEvent")
        try:
            existing = self.load()
        except HistoryStoreError as exc:
            if exc.code != "history_json_corrupt":
                raise
            LOGGER.warning("History recovery started; code=%s", exc.code)
            existing = ()
        events = (event, *existing)[: self.max_entries]
        self._write(events)
        return events

    def clear(self) -> bool:
        """Delete only this configured history file; never recurse or remove logs.

        Returns ``True`` if a file or symlink was removed, ``False`` if it did
        not exist. Other state such as logs and parent directories is untouched.
        """
        try:
            self.path.lstat()
        except FileNotFoundError:
            return False
        except OSError as exc:
            raise HistoryStoreError(_os_error_code(exc, "history_delete_failed")) from None
        try:
            # unlink() removes this exact file or link; it does not follow links
            # and never recurses into the parent directory.
            self.path.unlink()
            return True
        except OSError as exc:
            raise HistoryStoreError(_os_error_code(exc, "history_delete_failed")) from None

    def _migrate_legacy_rows(self, rows: list[object]) -> tuple[HistoryEvent, ...]:
        migrated: list[HistoryEvent] = []
        for index, row in enumerate(rows[: self.max_entries]):
            if not isinstance(row, dict):
                raise HistoryStoreError("history_record_invalid")
            try:
                item = ScanHistoryItem.from_persistence_record(row)
            except (TypeError, ValueError, KeyError):
                raise HistoryStoreError("history_record_invalid") from None
            # A deterministic ID prevents a legacy row changing identity on each
            # load before the user has caused the file to be migrated to v2.
            legacy_identity = json.dumps(
                item.to_persistence_record(), sort_keys=True, separators=(",", ":")
            )
            migrated.append(
                HistoryEvent(
                    event_id=str(
                        uuid5(NAMESPACE_OID, f"zentry-legacy-{index}-{legacy_identity}")
                    ),
                    timestamp=item.timestamp,
                    operation_type=HistoryOperation.LEGACY_AGGREGATE,
                    result=HistoryResult.SUCCESS,
                    estimated_bytes=item.reclaimable_bytes,
                    moved_bytes=item.cleaned_bytes,
                    health_score=item.health_score,
                    cpu_percent=item.cpu_percent,
                    memory_percent=item.memory_percent,
                    disk_percent=item.disk_percent,
                )
            )
        return tuple(migrated)

    def _write(self, events: tuple[HistoryEvent, ...]) -> None:
        payload = {
            "schema_version": HISTORY_SCHEMA_VERSION,
            "events": [event.to_record() for event in events],
        }
        temporary_path: Path | None = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            # Refuse to overwrite a symlink introduced after load().
            try:
                existing_stat = self.path.lstat()
            except FileNotFoundError:
                existing_stat = None
            if existing_stat is not None and stat.S_ISLNK(existing_stat.st_mode):
                raise HistoryStoreError("history_path_is_symlink")

            descriptor, temporary_name = tempfile.mkstemp(
                prefix=".zentry-history-", suffix=".tmp", dir=self.path.parent
            )
            temporary_path = Path(temporary_name)
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2, allow_nan=False)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, self.path)
            temporary_path = None
        except HistoryStoreError:
            raise
        except (OSError, TypeError, ValueError) as exc:
            raise HistoryStoreError(_os_error_code(exc, "history_write_failed")) from None
        finally:
            if temporary_path is not None:
                try:
                    temporary_path.unlink(missing_ok=True)
                except OSError:
                    LOGGER.warning("Temporary history artifact cleanup failed")


def _os_error_code(exc: Exception, fallback: str) -> str:
    if isinstance(exc, PermissionError):
        return "permission_denied"
    if isinstance(exc, FileNotFoundError):
        return "path_not_found"
    return fallback
