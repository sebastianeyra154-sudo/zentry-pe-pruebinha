"""Privacy-conscious, bounded logging for Zentry."""

from __future__ import annotations

import logging
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from uuid import uuid4

from zentry.core.local_state import get_app_data_directory

DEFAULT_LOG_MAX_BYTES = 1 * 1024 * 1024
DEFAULT_LOG_BACKUP_COUNT = 3
_SAFE_CODE = re.compile(r"^[a-z][a-z0-9_.-]{0,63}$")
_SAFE_TYPE = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,63}$")


def configure_logging(
    *,
    data_directory: Path | None = None,
    max_bytes: int = DEFAULT_LOG_MAX_BYTES,
    backup_count: int = DEFAULT_LOG_BACKUP_COUNT,
) -> Path | None:
    """Configure bounded file logging; return the log path or None on fallback.

    The function is safe to call more than once. It configures only the zentry
    logger hierarchy, does not alter the root logger, and does not log exception
    messages or tracebacks that could contain user paths or command arguments.
    """
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes < 1:
        raise ValueError("max_bytes must be a positive integer")
    if (
        isinstance(backup_count, bool)
        or not isinstance(backup_count, int)
        or not 0 <= backup_count <= 20
    ):
        raise ValueError("backup_count must be between 0 and 20")

    base_directory = get_app_data_directory() if data_directory is None else Path(data_directory)
    log_path = base_directory / "logs" / "zentry.log"
    logger = logging.getLogger("zentry")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    _close_handlers(logger)

    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            log_path,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
    except OSError as exc:
        fallback_handler: logging.Handler
        if sys.stderr is not None:
            fallback_handler = logging.StreamHandler(sys.stderr)
        else:
            fallback_handler = logging.NullHandler()
        fallback_handler.setFormatter(_formatter())
        logger.addHandler(fallback_handler)
        code = "permission_denied" if isinstance(exc, PermissionError) else "log_file_unavailable"
        logger.warning("File logging unavailable; error_code=%s", code)
        return None

    handler.setFormatter(_formatter())
    logger.addHandler(handler)
    logger.info("Logging configured; rotation_limit_bytes=%d backups=%d", max_bytes, backup_count)
    return log_path


def log_safe_exception(
    logger: logging.Logger,
    category: str,
    exception: BaseException,
) -> str:
    """Log a useful error correlation ID without message, arguments or traceback."""
    safe_category = category if _SAFE_CODE.fullmatch(category) else "unexpected_error"
    exception_type = type(exception).__name__
    if not _SAFE_TYPE.fullmatch(exception_type):
        exception_type = "UnknownException"
    event_id = uuid4().hex[:12]
    logger.error(
        "Operation failed; event_id=%s category=%s exception_type=%s",
        event_id,
        safe_category,
        exception_type,
    )
    return event_id


def _formatter() -> logging.Formatter:
    return logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )


def _close_handlers(logger: logging.Logger) -> None:
    for handler in tuple(logger.handlers):
        logger.removeHandler(handler)
        try:
            handler.close()
        except OSError:
            # Handler cleanup must not stop the application starting.
            continue
