"""Confirmed, revalidated cleanup operations for Zentry.

The scanner and safety classifier are read-only. This module is the only layer
that calls ``send2trash``. It accepts only the exact in-memory candidate objects
registered from the most recent validated scan; paths supplied directly by the
GUI are never accepted.

The last path-based check and ``send2trash(path)`` cannot be an atomic operation.
A narrow TOCTOU window remains if another process replaces a file after our last
validation and before the trash implementation acts. This module never falls
back to permanent deletion.
"""

from __future__ import annotations

import logging
import os
import stat
import sys
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Iterable

from send2trash import send2trash

from zentry.core.safety import SafetyAssessment, WindowsSafetyClassifier
from zentry.core.scanner import MAX_AGE_DAYS, MIN_AGE_DAYS
from zentry.models import (
    CleanupPolicyDecision,
    CleanupResult,
    CleanupScanSummary,
    FileCandidate,
    FileClassification,
    FileFingerprint,
)

_LOGGER = logging.getLogger(__name__)
_REPARSE_POINT_ATTRIBUTE = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x0400)


class CleanupConfirmationRequired(RuntimeError):
    """Raised when a non-empty selection was not explicitly confirmed."""


@dataclass(frozen=True)
class CleanupCategoryPreview:
    """Dry-run breakdown for one user-visible category; contains no paths."""

    category: str
    file_count: int
    estimated_bytes: int

    def __post_init__(self) -> None:
        if not isinstance(self.category, str) or not self.category.strip():
            raise ValueError("category must not be empty")
        for field_name in ("file_count", "estimated_bytes"):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(f"{field_name} must be an integer")
            if value < 0:
                raise ValueError(f"{field_name} must be non-negative")


@dataclass(frozen=True)
class CleanupPreview:
    """Preview of a selected set before confirmation; performs no mutation."""

    requested_files: int
    eligible_files: int
    rejected_files: int
    estimated_bytes: int
    categories: tuple[CleanupCategoryPreview, ...]
    consequence: str = (
        "Eligible files will be handed to the operating-system trash facility. "
        "This is not permanent-delete fallback, but recovery is not guaranteed "
        "for every volume or environment."
    )

    def __post_init__(self) -> None:
        for field_name in (
            "requested_files",
            "eligible_files",
            "rejected_files",
            "estimated_bytes",
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(f"{field_name} must be an integer")
            if value < 0:
                raise ValueError(f"{field_name} must be non-negative")
        if not isinstance(self.categories, tuple) or not all(
            isinstance(item, CleanupCategoryPreview) for item in self.categories
        ):
            raise TypeError("categories must be a tuple of CleanupCategoryPreview")
        if not isinstance(self.consequence, str) or not self.consequence.strip():
            raise ValueError("consequence must be a non-empty string")
        if self.eligible_files + self.rejected_files != self.requested_files:
            raise ValueError("eligible and rejected counts must equal requested files")
        if sum(item.file_count for item in self.categories) != self.eligible_files:
            raise ValueError("category file counts must equal eligible_files")
        if sum(item.estimated_bytes for item in self.categories) != self.estimated_bytes:
            raise ValueError("category byte counts must equal estimated_bytes")


@dataclass(frozen=True)
class _ApprovedRoot:
    category: str
    path: Path


@dataclass(frozen=True)
class _Registration:
    candidate: FileCandidate
    root: _ApprovedRoot
    min_age_days: int


class CleanupService:
    """Operate on exact candidates from the latest registered scanner result.

    This object has an in-memory, single-scan manifest. A newer scan replaces
    the prior manifest, and a confirmed cleanup attempt consumes it to prevent
    replaying stale candidate objects. The service itself does not perform the
    scan: ``SystemDiagnosticsProvider.scan_cleanup`` registers its result.
    """

    def __init__(
        self,
        classifier: WindowsSafetyClassifier,
        roots_provider: Callable[[], Iterable[tuple[str, Path]]],
    ) -> None:
        self._classifier = classifier
        self._roots_provider = roots_provider
        self._registrations: dict[int, _Registration] = {}
        self._scan_min_age_days: int | None = None

    def invalidate_scan(self) -> None:
        """Invalidate the prior scan before a new scan starts."""
        self._registrations.clear()
        self._scan_min_age_days = None

    def _register_scan(
        self,
        summary: CleanupScanSummary,
        roots: Iterable[tuple[str, Path]],
        min_age_days: int,
    ) -> None:
        """Register eligible objects from a completed scanner result.

        This is an internal integration seam for the provider, not an API for
        accepting arbitrary GUI-supplied paths. Only candidates with an explicit
        SAFE_CANDIDATE + ALLOW decision and a scanner fingerprint are retained.
        """
        self._validate_min_age_days(min_age_days)
        self.invalidate_scan()
        approved_roots = self._prepare_roots(roots)
        self._scan_min_age_days = min_age_days

        for candidate in summary.candidates:
            if not self._candidate_has_cleanup_decision(candidate):
                continue
            if candidate.fingerprint is None:
                continue
            candidate_path = Path(candidate.path)
            matching_root = next(
                (
                    root
                    for root in approved_roots
                    if root.category == candidate.category
                    and self._is_within_path(candidate_path, root.path)
                ),
                None,
            )
            if matching_root is None:
                continue
            # Store the actual immutable object reference, not an ID parsed from
            # GUI data. Reconstructed candidates with the same path are rejected.
            self._registrations[id(candidate)] = _Registration(
                candidate=candidate,
                root=matching_root,
                min_age_days=min_age_days,
            )

    def preview_selection(
        self,
        candidates: Iterable[FileCandidate],
    ) -> CleanupPreview:
        """Return selected-category counts and estimated bytes without mutation."""
        selected = self._unique_objects(candidates)
        registered = [candidate for candidate in selected if self._registration_for(candidate)]
        rejected = len(selected) - len(registered)
        counts: Counter[str] = Counter()
        bytes_by_category: Counter[str] = Counter()
        for candidate in registered:
            counts[candidate.category] += 1
            bytes_by_category[candidate.category] += candidate.size_bytes

        categories = tuple(
            CleanupCategoryPreview(
                category=category,
                file_count=counts[category],
                estimated_bytes=bytes_by_category[category],
            )
            for category in sorted(counts)
        )
        return CleanupPreview(
            requested_files=len(selected),
            eligible_files=len(registered),
            rejected_files=rejected,
            estimated_bytes=sum(item.estimated_bytes for item in categories),
            categories=categories,
        )

    def execute_selected(
        self,
        candidates: Iterable[FileCandidate],
        *,
        min_age_days: int,
        confirmed: bool,
    ) -> CleanupResult:
        """Revalidate and send the requested scanned candidates to the trash.

        Only the current scan's exact candidate objects are trusted. Unknown,
        protected, inaccessible, or policy-rejected objects are counted as
        skipped. Changed metadata is separately reported. A false confirmation
        prevents all mutation.
        """
        selected = self._unique_objects(candidates)
        if not selected:
            return CleanupResult(0, 0, 0, 0, 0, skipped_files=0)
        self._validate_min_age_days(min_age_days)
        if confirmed is not True:
            raise CleanupConfirmationRequired(
                "Explicit user confirmation is required before cleanup."
            )
        if self._scan_min_age_days is None:
            return CleanupResult(
                len(selected), 0, 0, 0, 0, skipped_files=len(selected)
            )
        if min_age_days != self._scan_min_age_days:
            raise ValueError(
                "Cleanup age threshold differs from the scan; run a new scan first."
            )

        moved_files = 0
        moved_bytes = 0
        failed_files = 0
        skipped_changed_files = 0
        skipped_files = 0
        issue_counts: Counter[str] = Counter()

        try:
            current_roots = self._prepare_roots(self._roots_provider())
        except Exception:
            current_roots = ()
            issue_counts["allowed_roots_unavailable"] += len(selected)

        for candidate in selected:
            registration = self._registration_for(candidate)
            if registration is None:
                skipped_files += 1
                issue_counts["candidate_not_from_current_scan"] += 1
                continue
            if registration.min_age_days != min_age_days:
                skipped_files += 1
                issue_counts["age_policy_changed"] += 1
                continue

            current_root = next(
                (
                    root
                    for root in current_roots
                    if root.category == registration.root.category
                    and self._same_path(root.path, registration.root.path)
                ),
                None,
            )
            if current_root is None:
                skipped_files += 1
                issue_counts["approved_root_changed_or_unavailable"] += 1
                continue

            reason = self._revalidate_candidate(candidate, registration, current_root)
            if reason is not None:
                if reason == "file_changed":
                    skipped_changed_files += 1
                else:
                    skipped_files += 1
                issue_counts[reason] += 1
                continue

            candidate_path = Path(candidate.path)
            try:
                # No unlink/rmtree or other fallback is allowed here. If
                # send2trash fails, leave the original path alone and report it.
                send2trash(str(candidate_path))
            except Exception as exc:
                failed_files += 1
                issue_counts["send2trash_failed"] += 1
                _LOGGER.warning(
                    "Cleanup failed while sending an item to trash; error_type=%s",
                    type(exc).__name__,
                )
                continue

            try:
                still_exists = os.path.lexists(candidate_path)
            except OSError:
                still_exists = True
            if still_exists:
                failed_files += 1
                issue_counts["move_not_verified"] += 1
                _LOGGER.warning(
                    "Cleanup move could not be verified; path remains or status is unknown"
                )
                continue

            moved_files += 1
            moved_bytes += candidate.size_bytes

        # Consume the manifest after any confirmed non-empty attempt; a caller
        # cannot replay the same candidate objects after the result is returned.
        self.invalidate_scan()
        _LOGGER.info(
            "Cleanup finished: selected=%d moved=%d moved_bytes=%d skipped=%d "
            "skipped_changed=%d failed=%d",
            len(selected),
            moved_files,
            moved_bytes,
            skipped_files,
            skipped_changed_files,
            failed_files,
        )
        if issue_counts:
            # Log reason codes and counts only; never record paths or filenames.
            _LOGGER.info("Cleanup reason counts: %s", dict(sorted(issue_counts.items())))

        return CleanupResult(
            selected_files=len(selected),
            moved_files=moved_files,
            moved_bytes=moved_bytes,
            failed_files=failed_files,
            skipped_changed_files=skipped_changed_files,
            skipped_files=skipped_files,
        )

    def _revalidate_candidate(
        self,
        candidate: FileCandidate,
        registration: _Registration,
        current_root: _ApprovedRoot,
    ) -> str | None:
        """Return a non-sensitive reason code when any check fails."""
        if not self._candidate_has_cleanup_decision(candidate):
            return "policy_blocked"
        fingerprint = candidate.fingerprint
        if fingerprint is None:
            return "fingerprint_missing"

        try:
            path = Path(candidate.path)
            if not path.is_absolute() or ".." in path.parts:
                return "path_invalid"

            metadata = os.lstat(path)
            reparse_status = self._reparse_chain_status(path)
            if reparse_status is True:
                return "reparse_point"
            if reparse_status is None:
                return "reparse_status_unknown"
            if not stat.S_ISREG(metadata.st_mode):
                return "not_regular_file"

            resolved = path.resolve(strict=True)
            registered_path = Path(registration.candidate.path)
            if not self._same_path(resolved, registered_path):
                return "path_changed"
            if not self._is_within_path(resolved, registration.root.path):
                return "outside_scan_root"
            if not self._is_within_path(resolved, current_root.path):
                return "outside_current_root"

            fingerprint_result = self._matches_fingerprint(metadata, fingerprint)
            if fingerprint_result is not True:
                return "file_changed" if fingerprint_result is False else "identity_unverifiable"

            now = datetime.now().astimezone()
            cutoff = now - timedelta(days=registration.min_age_days)
            access = datetime.fromtimestamp(metadata.st_atime, tz=now.tzinfo)
            modified = datetime.fromtimestamp(metadata.st_mtime, tz=now.tzinfo)
            if access > cutoff or modified > cutoff:
                return "file_changed"
            if (
                access != candidate.last_access
                or modified != candidate.last_modified
            ):
                return "file_changed"

            assessment = self._classifier.assess_for_cleanup(
                path,
                (registration.root.path, current_root.path),
                f"Known disposable location: {candidate.category}.",
            )
            if not self._assessment_allows_cleanup(assessment):
                return "policy_blocked"

            # Final check after classifier work to reduce the replacement window.
            final_metadata = os.lstat(path)
            final_reparse_status = self._reparse_chain_status(path)
            if final_reparse_status is True:
                return "reparse_point"
            if final_reparse_status is None:
                return "reparse_status_unknown"
            if not stat.S_ISREG(final_metadata.st_mode):
                return "not_regular_file"
            if not self._same_path(path.resolve(strict=True), resolved):
                return "path_changed"
            final_fingerprint_result = self._matches_fingerprint(
                final_metadata, fingerprint
            )
            if final_fingerprint_result is not True:
                return (
                    "file_changed"
                    if final_fingerprint_result is False
                    else "identity_unverifiable"
                )
            if not self._is_within_path(path.resolve(strict=True), current_root.path):
                return "outside_current_root"
            return None
        except FileNotFoundError:
            return "file_changed"
        except PermissionError:
            return "inaccessible"
        except (OSError, RuntimeError, ValueError, TypeError, OverflowError):
            return "inaccessible"

    @staticmethod
    def _candidate_has_cleanup_decision(candidate: FileCandidate) -> bool:
        return (
            isinstance(candidate, FileCandidate)
            and candidate.classification is FileClassification.SAFE_CANDIDATE
            and candidate.policy_decision is CleanupPolicyDecision.ALLOW
            and candidate.fingerprint is not None
        )

    def _registration_for(self, candidate: object) -> _Registration | None:
        if not isinstance(candidate, FileCandidate):
            return None
        registration = self._registrations.get(id(candidate))
        if registration is None or registration.candidate is not candidate:
            return None
        return registration

    @staticmethod
    def _unique_objects(candidates: Iterable[FileCandidate]) -> list[FileCandidate]:
        selected: list[FileCandidate] = []
        seen: set[int] = set()
        for candidate in candidates:
            # Keep unknown object types in the request count; they will be safely
            # rejected by _registration_for rather than treated as a path.
            identity = id(candidate)
            if identity not in seen:
                selected.append(candidate)
                seen.add(identity)
        return selected

    def _prepare_roots(
        self,
        roots: Iterable[tuple[str, Path]],
    ) -> tuple[_ApprovedRoot, ...]:
        prepared: list[_ApprovedRoot] = []
        for category, root_value in roots:
            try:
                if not isinstance(category, str) or not category.strip():
                    continue
                root = Path(root_value)
                if not root.is_absolute() or ".." in root.parts:
                    continue
                root_meta = os.lstat(root)
                if not stat.S_ISDIR(root_meta.st_mode):
                    continue
                if self._reparse_chain_status(root) is not False:
                    continue
                resolved_root = root.resolve(strict=True)
                if not resolved_root.is_dir():
                    continue
                prepared.append(_ApprovedRoot(category.strip(), resolved_root))
            except (OSError, RuntimeError, ValueError, TypeError):
                continue
        return tuple(prepared)

    @staticmethod
    def _assessment_allows_cleanup(assessment: SafetyAssessment) -> bool:
        return (
            isinstance(assessment, SafetyAssessment)
            and assessment.classification is FileClassification.SAFE_CANDIDATE
            and assessment.policy_decision is CleanupPolicyDecision.ALLOW
        )

    @staticmethod
    def _matches_fingerprint(
        metadata: os.stat_result,
        fingerprint: FileFingerprint,
    ) -> bool | None:
        """Compare identity and stable metadata; None means identity is unknown."""
        device_id = getattr(metadata, "st_dev", None)
        file_id = getattr(metadata, "st_ino", None)
        if (
            device_id is None
            or file_id in (None, 0)
            or fingerprint.device_id is None
            or fingerprint.file_id in (None, 0)
        ):
            return None

        accessed_ns = getattr(metadata, "st_atime_ns", None)
        modified_ns = getattr(metadata, "st_mtime_ns", None)
        if accessed_ns is None:
            accessed_ns = int(float(metadata.st_atime) * 1_000_000_000)
        if modified_ns is None:
            modified_ns = int(float(metadata.st_mtime) * 1_000_000_000)

        return (
            int(device_id) == fingerprint.device_id
            and int(file_id) == fingerprint.file_id
            and int(metadata.st_size) == fingerprint.size_bytes
            and int(accessed_ns) == fingerprint.accessed_ns
            and int(modified_ns) == fingerprint.modified_ns
        )

    @staticmethod
    def _reparse_chain_status(path: Path) -> bool | None:
        """Return True for any link/reparse ancestor, None if uncertain."""
        try:
            current = path.absolute()
            while True:
                metadata = os.lstat(current)
                if stat.S_ISLNK(metadata.st_mode):
                    return True
                attributes = getattr(metadata, "st_file_attributes", None)
                if sys.platform == "win32" and attributes is None:
                    return None
                if attributes is not None and attributes & _REPARSE_POINT_ATTRIBUTE:
                    return True
                is_junction = getattr(current, "is_junction", None)
                if callable(is_junction):
                    try:
                        if is_junction():
                            return True
                    except OSError:
                        return None
                parent = current.parent
                if parent == current:
                    return False
                current = parent
        except (OSError, RuntimeError, ValueError):
            return None

    @staticmethod
    def _is_within_path(path: Path, root: Path) -> bool:
        try:
            path_value = os.path.normcase(os.path.normpath(str(path.resolve(strict=True))))
            root_value = os.path.normcase(os.path.normpath(str(root.resolve(strict=True))))
            return os.path.commonpath((path_value, root_value)) == root_value
        except (OSError, RuntimeError, ValueError):
            return False

    @staticmethod
    def _same_path(first: Path, second: Path) -> bool:
        try:
            first_value = os.path.normcase(os.path.normpath(str(first.resolve(strict=True))))
            second_value = os.path.normcase(os.path.normpath(str(second.resolve(strict=True))))
            return first_value == second_value
        except (OSError, RuntimeError, ValueError):
            # Candidate paths are expected to exist. If either side is missing,
            # equality cannot be established and the comparison fails closed.
            return False

    @staticmethod
    def _validate_min_age_days(value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError("min_age_days must be an integer")
        if not MIN_AGE_DAYS <= value <= MAX_AGE_DAYS:
            raise ValueError(
                f"min_age_days must be between {MIN_AGE_DAYS} and {MAX_AGE_DAYS}"
            )
