"""Core safety and scanning services."""
