"""Read-only scanners for stale cleanup candidates and system protection.

The stale scanner only traverses explicitly supplied disposable roots. It does
not move or delete files. Windows last-access timestamps may be disabled or
updated lazily, so age is only a conservative filter, not proof that a file is
unnecessary.
"""

from __future__ import annotations

import math
import os
import stat
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Iterable, Iterator

from zentry.core.safety import SafetyAssessment, WindowsSafetyClassifier
from zentry.models import (
    CleanupPolicyDecision,
    CleanupScanSummary,
    FileCandidate,
    FileClassification,
    FileFingerprint,
    SystemProtectionSummary,
)

DEFAULT_MIN_AGE_DAYS = 31
MIN_AGE_DAYS = 1
MAX_AGE_DAYS = 3650
_REPARSE_POINT_ATTRIBUTE = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x0400)

ProgressCallback = Callable[[str], None]


@dataclass(frozen=True)
class ScanIssue:
    """Transient explanation for an item excluded from candidate results.

    The path may include a username or private filename. This object is for an
    in-memory callback only and must not be persisted to history/logs.
    """

    category: str
    classification: FileClassification
    reason: str
    path: Path = field(repr=False, compare=False)


IssueCallback = Callable[[ScanIssue], None]


@dataclass(frozen=True)
class _PreparedRoot:
    category: str
    path: Path


@dataclass(frozen=True)
class _WalkEvent:
    path: Path
    metadata: os.stat_result | None
    is_file: bool
    classification: FileClassification | None = None
    reason: str = ""


@dataclass(frozen=True)
class _FileOutcome:
    candidate: FileCandidate | None = None
    classification: FileClassification | None = None
    reason: str = ""


class CleanupScanner:
    """Discover stale regular files in an explicit allowlist without mutation."""

    def __init__(self, classifier: WindowsSafetyClassifier | None = None) -> None:
        self._classifier = classifier or WindowsSafetyClassifier()

    def scan(
        self,
        roots: Iterable[tuple[str, Path]],
        min_age_days: int = DEFAULT_MIN_AGE_DAYS,
        progress: ProgressCallback | None = None,
        *,
        issue_callback: IssueCallback | None = None,
        now: datetime | None = None,
    ) -> CleanupScanSummary:
        """Find old files in explicitly approved disposable roots.

        Callers should normally pass :func:`default_cleanup_roots`. Broad roots
        such as a drive root, the whole Windows directory, a full user profile,
        or an entire application-data/program-files root are rejected even if
        they are passed explicitly. Only candidates are retained in memory;
        directory entries are processed incrementally.

        ``issue_callback`` receives transient reasons for excluded items. Its
        paths must not be persisted. ``now`` exists for deterministic tests.
        """
        self._validate_min_age_days(min_age_days)
        scan_time = now if now is not None else datetime.now().astimezone()
        if scan_time.tzinfo is None or scan_time.utcoffset() is None:
            raise ValueError("now must be a timezone-aware datetime")
        cutoff = scan_time - timedelta(days=min_age_days)

        candidates: list[FileCandidate] = []
        counts = {
            "scanned_files": 0,
            "protected_files": 0,
            "review_files": 0,
            "inaccessible_items": 0,
            "skipped_reparse_points": 0,
        }

        def report_progress(message: str) -> None:
            self._safe_progress(progress, message)

        def report_issue(
            category: str,
            path: Path,
            classification: FileClassification,
            reason: str,
        ) -> None:
            counter = {
                FileClassification.PROTECTED: "protected_files",
                FileClassification.REVIEW_REQUIRED: "review_files",
                FileClassification.INACCESSIBLE: "inaccessible_items",
                FileClassification.REPARSE_POINT: "skipped_reparse_points",
            }.get(classification)
            if counter is not None:
                counts[counter] += 1
            if issue_callback is not None:
                try:
                    issue_callback(
                        ScanIssue(
                            category=category,
                            classification=classification,
                            reason=reason,
                            path=path,
                        )
                    )
                except Exception:
                    # A consumer callback is observational, not scan policy.
                    pass

        prepared_roots: list[_PreparedRoot] = []
        try:
            root_iterator = iter(roots)
        except TypeError:
            root_iterator = iter(())
            report_issue(
                "Unknown root",
                Path.cwd(),
                FileClassification.REVIEW_REQUIRED,
                "The configured cleanup roots could not be enumerated.",
            )

        for item in root_iterator:
            try:
                category_value, root_value = item
                category = str(category_value).strip()
                root = Path(root_value)
                if not category:
                    raise ValueError("cleanup root category is empty")
            except (TypeError, ValueError, OSError):
                report_issue(
                    "Unknown root",
                    Path.cwd(),
                    FileClassification.REVIEW_REQUIRED,
                    "A cleanup root has an invalid category or path.",
                )
                continue

            prepared, classification, reason, missing = self._prepare_root(
                category, root
            )
            if prepared is None:
                # An absent optional browser cache is normal. Other invalid root
                # states are counted and explained, and are never traversed.
                if not missing and classification is not None:
                    report_issue(category, root, classification, reason)
                continue
            prepared_roots.append(prepared)

        # Scan broadest-to-narrowest, retaining only non-overlapping roots. This
        # avoids duplicates when e.g. two explicitly approved cache roots nest.
        unique_roots: list[_PreparedRoot] = []
        seen_paths: set[str] = set()
        for root in sorted(prepared_roots, key=lambda item: len(item.path.parts)):
            canonical_key = os.path.normcase(str(root.path))
            if canonical_key in seen_paths:
                continue
            overlaps_existing_root = any(
                self._is_path_within(root.path, accepted.path)
                for accepted in unique_roots
            )
            if overlaps_existing_root:
                report_progress(
                    f"Skipped overlapping cleanup root for category: {root.category}."
                )
                continue
            seen_paths.add(canonical_key)
            unique_roots.append(root)

        allowed_roots = tuple(root.path for root in unique_roots)
        for root in unique_roots:
            report_progress(f"Scanning approved category: {root.category}.")
            for event in self._walk_events(root.path):
                if event.is_file:
                    counts["scanned_files"] += 1
                    # Most cache/temp files are recent and cannot become cleanup
                    # candidates. Check the enumeration snapshot first so those
                    # files avoid multiple lstat(), resolve(), and safety checks.
                    # Old/invalid timestamps still go through the complete
                    # identity, reparse-point, containment, and policy revalidation
                    # before a candidate can be exposed to the UI.
                    if counts["scanned_files"] % 500 == 0:
                        report_progress(
                            f"Scanned {counts['scanned_files']} files across "
                            "approved roots."
                        )
                if event.classification is not None:
                    report_issue(
                        root.category,
                        event.path,
                        event.classification,
                        event.reason,
                    )
                    continue
                if not event.is_file or event.metadata is None:
                    continue

                quick_dates = self._read_timestamps(event.metadata, scan_time)
                if quick_dates is not None and (
                    quick_dates[0] > cutoff or quick_dates[1] > cutoff
                ):
                    # Fresh files are not candidates. Skipping early is safe:
                    # only old files continue to the full validation pipeline,
                    # and execution revalidates every selected file again.
                    continue

                outcome = self._inspect_stale_file(
                    event=event,
                    root=root,
                    allowed_roots=allowed_roots,
                    min_age_days=min_age_days,
                    cutoff=cutoff,
                    scan_time=scan_time,
                )
                if outcome.candidate is not None:
                    candidates.append(outcome.candidate)
                elif outcome.classification is not None:
                    report_issue(
                        root.category,
                        event.path,
                        outcome.classification,
                        outcome.reason,
                    )

        candidates.sort(key=lambda item: item.size_bytes, reverse=True)
        report_progress(
            "Scan complete: "
            f"{counts['scanned_files']} files inspected, "
            f"{len(candidates)} stale candidates, "
            f"{counts['protected_files']} protected, "
            f"{counts['review_files']} requiring review, "
            f"{counts['inaccessible_items']} inaccessible, "
            f"{counts['skipped_reparse_points']} reparse points skipped."
        )
        return CleanupScanSummary(
            candidates=tuple(candidates),
            scanned_roots=len(unique_roots),
            **counts,
        )

    def _inspect_stale_file(
        self,
        *,
        event: _WalkEvent,
        root: _PreparedRoot,
        allowed_roots: tuple[Path, ...],
        min_age_days: int,
        cutoff: datetime,
        scan_time: datetime,
    ) -> _FileOutcome:
        """Apply metadata, containment, safety and revalidation in that order."""
        path = event.path
        initial_metadata = event.metadata
        try:
            metadata = self._read_file_metadata(path)
            status = self._validate_entry_reparse_status(metadata)
            if status is True:
                return self._issue(
                    FileClassification.REPARSE_POINT,
                    "The item became a symlink, junction, or reparse point; excluded.",
                )
            if status is None:
                return self._issue(
                    FileClassification.INACCESSIBLE,
                    "Reparse-point metadata is unavailable; item excluded.",
                )
            if not stat.S_ISREG(metadata.st_mode):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The item is no longer a regular file; item excluded.",
                )
            if not self._same_file_identity(initial_metadata, metadata):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The file changed or was replaced during directory enumeration.",
                )

            resolved_path = path.resolve(strict=True)
            if not self._is_path_within(resolved_path, root.path):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The resolved file is outside the explicitly approved root.",
                )

            # Resolve is allowed only after lstat-based link inspection. Check the
            # lexical path again to narrow the race where it changes into a link.
            lexical_after_resolve = self._read_file_metadata(path)
            lexical_status = self._validate_entry_reparse_status(lexical_after_resolve)
            if lexical_status is True:
                return self._issue(
                    FileClassification.REPARSE_POINT,
                    "The path changed into a reparse point during inspection.",
                )
            if lexical_status is None:
                return self._issue(
                    FileClassification.INACCESSIBLE,
                    "The path's reparse-point status became unknown; item excluded.",
                )
            if not self._same_file_identity(metadata, lexical_after_resolve):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The file changed while its canonical path was being checked.",
                )

            dates = self._read_timestamps(lexical_after_resolve, scan_time)
            if dates is None:
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "Last-access or last-modification time is missing, invalid, "
                    "inconsistent, or in the future; item excluded.",
                )
            access_time, modified_time = dates
            if access_time > cutoff or modified_time > cutoff:
                # Recent files do not need review and are never returned as candidates.
                return _FileOutcome()

            assessment = self._assess_file(path, allowed_roots, root.category)
            if assessment.classification is not FileClassification.SAFE_CANDIDATE:
                return _FileOutcome(
                    classification=assessment.classification,
                    reason=assessment.reason,
                )
            if assessment.policy_decision is not CleanupPolicyDecision.ALLOW:
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    assessment.policy_reason
                    or (
                        "The safety classifier did not explicitly allow "
                        "generic cleanup."
                    ),
                )

            # Revalidate after the safety classifier runs. This cannot eliminate
            # every filesystem TOCTOU race; deletion code must repeat the checks.
            final_metadata = self._read_file_metadata(path)
            final_status = self._validate_entry_reparse_status(final_metadata)
            if final_status is True:
                return self._issue(
                    FileClassification.REPARSE_POINT,
                    "The file became a reparse point during classification; excluded.",
                )
            if final_status is None:
                return self._issue(
                    FileClassification.INACCESSIBLE,
                    "Reparse-point metadata is unavailable after classification.",
                )
            if not stat.S_ISREG(final_metadata.st_mode):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The item ceased to be a regular file during classification.",
                )
            if not self._same_file_identity(lexical_after_resolve, final_metadata):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The file changed or was replaced during classification; excluded.",
                )
            final_resolved = path.resolve(strict=True)
            if final_resolved != resolved_path or not self._is_path_within(
                final_resolved, root.path
            ):
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The canonical path changed or escaped the approved root.",
                )

            final_dates = self._read_timestamps(final_metadata, scan_time)
            if final_dates is None:
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "Timestamps became invalid during classification; excluded.",
                )
            final_access, final_modified = final_dates
            if final_access > cutoff or final_modified > cutoff:
                return self._issue(
                    FileClassification.REVIEW_REQUIRED,
                    "The file's age changed during scanning; item excluded.",
                )

            access_age_days = self._age_days(scan_time, final_access)
            modified_age_days = self._age_days(scan_time, final_modified)
            calculated_age_days = min(access_age_days, modified_age_days)
            reason = (
                f"{assessment.reason} Calculated age: {calculated_age_days} days "
                f"(last access: {access_age_days} days; last modification: "
                f"{modified_age_days} days; required: {min_age_days} days). "
                "Windows last-access timestamps can be disabled or updated with "
                "delay; age alone does not prove that a file is unnecessary."
            )
            return _FileOutcome(
                candidate=FileCandidate(
                    path=str(final_resolved),
                    name=final_resolved.name,
                    category=root.category,
                    size_bytes=int(final_metadata.st_size),
                    last_access=final_access,
                    last_modified=final_modified,
                    classification=FileClassification.SAFE_CANDIDATE,
                    reason=reason,
                    policy_decision=CleanupPolicyDecision.ALLOW,
                    fingerprint=self._build_fingerprint(final_metadata),
                )
            )
        except FileNotFoundError:
            return self._issue(
                FileClassification.INACCESSIBLE,
                "The file disappeared during scanning; item excluded.",
            )
        except PermissionError:
            return self._issue(
                FileClassification.INACCESSIBLE,
                "Permission was denied while inspecting the file; item excluded.",
            )
        except (OSError, RuntimeError, ValueError, OverflowError, TypeError):
            return self._issue(
                FileClassification.INACCESSIBLE,
                "The file could not be inspected consistently; item excluded.",
            )

    def scan_system_protection(
        self,
        progress: ProgressCallback | None = None,
    ) -> SystemProtectionSummary:
        roots: list[Path] = []
        for rule in self._classifier.protected_rules:
            try:
                resolved = rule.path.resolve(strict=True)
                if resolved.exists() and resolved.is_dir():
                    roots.append(resolved)
            except OSError:
                continue

        files_seen = 0
        protected_files = 0
        system_managed_files = 0
        inaccessible_items = 0
        unique_roots = tuple(dict.fromkeys(str(root) for root in roots))

        # The Windows directory itself is treated as system-managed for analysis.
        # We do not use this broad rule for generic cleanup; it only prevents
        # the protection analyzer from declaring arbitrary Windows files disposable.
        system_root: Path | None = None
        candidate_system_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
        try:
            resolved_system_root = candidate_system_root.resolve(strict=True)
            if resolved_system_root.exists() and resolved_system_root.is_dir():
                system_root = resolved_system_root
        except OSError:
            system_root = None

        if system_root is not None:
            roots = list(dict.fromkeys([system_root, *roots]))
            roots = [
                root
                for root in roots
                if root == system_root or not self._is_descendant(root, system_root)
            ]

        unique_roots = tuple(dict.fromkeys(str(root) for root in roots))

        for root in roots:
            if progress:
                progress(f"Checking protected tree: {root}")
            for file_path in self._iter_files(root):
                files_seen += 1
                if progress and files_seen % 1000 == 0:
                    progress(f"Files inspected: {files_seen}")
                classification, _ = self._classifier.classify(file_path)
                if classification is FileClassification.PROTECTED:
                    protected_files += 1
                elif classification is FileClassification.INACCESSIBLE:
                    inaccessible_items += 1
                else:
                    try:
                        if system_root is not None:
                            file_path.resolve(strict=False).relative_to(system_root)
                            system_managed_files += 1
                    except (ValueError, OSError):
                        pass

        return SystemProtectionSummary(
            roots_checked=len(roots),
            files_seen=files_seen,
            protected_files=protected_files,
            system_managed_files=system_managed_files,
            inaccessible_items=inaccessible_items,
            protected_roots=unique_roots,
        )

    @staticmethod
    def _is_descendant(path: Path, parent: Path) -> bool:
        try:
            path.relative_to(parent)
            return path != parent
        except ValueError:
            return False

    @staticmethod
    def _iter_files(root: Path):
        stack = [root]
        while stack:
            current = stack.pop()
            try:
                with os.scandir(current) as entries:
                    for entry in entries:
                        try:
                            if entry.is_symlink():
                                continue
                            entry_path = Path(entry.path)
                            is_junction = getattr(entry_path, "is_junction", None)
                            if is_junction and is_junction():
                                continue
                            if entry.is_dir(follow_symlinks=False):
                                stack.append(entry_path)
                            elif entry.is_file(follow_symlinks=False):
                                yield entry_path
                        except OSError:
                            continue
            except (OSError, PermissionError):
                continue


    def _prepare_root(
        self,
        category: str,
        root: Path,
    ) -> tuple[_PreparedRoot | None, FileClassification | None, str, bool]:
        """Validate an explicit root before canonicalizing it."""
        if not root.is_absolute() or ".." in root.parts:
            return (
                None,
                FileClassification.REVIEW_REQUIRED,
                "Cleanup root must be absolute and contain no parent traversal.",
                False,
            )
        try:
            root_metadata = os.lstat(root)
        except FileNotFoundError:
            return None, None, "Root does not exist.", True
        except PermissionError:
            return (
                None,
                FileClassification.INACCESSIBLE,
                "Permission was denied while inspecting the cleanup root.",
                False,
            )
        except (OSError, ValueError):
            return (
                None,
                FileClassification.INACCESSIBLE,
                "Cleanup-root metadata could not be read.",
                False,
            )

        link_status = self._path_reparse_status(root)
        if link_status is True:
            return (
                None,
                FileClassification.REPARSE_POINT,
                "The cleanup root or one of its ancestors is a reparse point.",
                False,
            )
        if link_status is None:
            return (
                None,
                FileClassification.INACCESSIBLE,
                "Reparse-point status for the cleanup root is unknown.",
                False,
            )
        if not stat.S_ISDIR(root_metadata.st_mode):
            return (
                None,
                FileClassification.REVIEW_REQUIRED,
                "Cleanup root is not a directory.",
                False,
            )

        try:
            resolved_root = root.resolve(strict=True)
            resolved_metadata = os.lstat(resolved_root)
            # Detect a root changed to a link while canonicalization was running.
            if self._path_reparse_status(root) is not False:
                return (
                    None,
                    FileClassification.REPARSE_POINT,
                    "The cleanup root changed or became uncertain during validation.",
                    False,
                )
            if not self._same_file_identity(root_metadata, resolved_metadata):
                return (
                    None,
                    FileClassification.REVIEW_REQUIRED,
                    "The cleanup root changed during validation.",
                    False,
                )
        except FileNotFoundError:
            return None, None, "Root disappeared before scanning.", True
        except (OSError, RuntimeError, ValueError):
            return (
                None,
                FileClassification.INACCESSIBLE,
                "Cleanup root could not be canonicalized safely.",
                False,
            )

        if not stat.S_ISDIR(resolved_metadata.st_mode):
            return (
                None,
                FileClassification.REVIEW_REQUIRED,
                "Canonical cleanup root is not a directory.",
                False,
            )
        if self._is_overbroad_root(resolved_root):
            return (
                None,
                FileClassification.REVIEW_REQUIRED,
                "Root is too broad (drive, Windows directory, profile, or "
                "application-data/program-files root) for generic cleanup.",
                False,
            )
        return _PreparedRoot(category, resolved_root), None, "", False

    @staticmethod
    def _validate_min_age_days(min_age_days: int) -> None:
        if isinstance(min_age_days, bool) or not isinstance(min_age_days, int):
            raise TypeError("min_age_days must be an integer")
        if not MIN_AGE_DAYS <= min_age_days <= MAX_AGE_DAYS:
            raise ValueError(
                f"min_age_days must be between {MIN_AGE_DAYS} and {MAX_AGE_DAYS}"
            )

    @staticmethod
    def _is_overbroad_root(root: Path) -> bool:
        if root.parent == root:
            return True
        try:
            anchors = [Path.home()]
        except (OSError, RuntimeError):
            anchors = []
        for variable in (
            "SystemRoot",
            "USERPROFILE",
            "APPDATA",
            "LOCALAPPDATA",
            "ProgramFiles",
            "ProgramFiles(x86)",
            "ProgramW6432",
        ):
            value = os.environ.get(variable)
            if value:
                try:
                    anchor = Path(value)
                except (OSError, ValueError):
                    continue
                if anchor.is_absolute():
                    anchors.append(anchor)
        for anchor in anchors:
            try:
                canonical_anchor = anchor.resolve(strict=False)
            except (OSError, RuntimeError, ValueError):
                continue
            if CleanupScanner._is_path_within(canonical_anchor, root):
                return True
        return False

    @staticmethod
    def _validate_entry_reparse_status(metadata: os.stat_result) -> bool | None:
        if stat.S_ISLNK(metadata.st_mode):
            return True
        attributes = getattr(metadata, "st_file_attributes", None)
        if attributes is None:
            return None if sys.platform == "win32" else False
        return bool(attributes & _REPARSE_POINT_ATTRIBUTE)

    @classmethod
    def _path_reparse_status(cls, path: Path) -> bool | None:
        """Check every path component with lstat, never resolving through links."""
        try:
            current = path.absolute()
            while True:
                try:
                    metadata = os.lstat(current)
                except (OSError, ValueError):
                    return None
                status = cls._validate_entry_reparse_status(metadata)
                if status is not False:
                    return status
                parent = current.parent
                if parent == current:
                    return False
                current = parent
        except (OSError, RuntimeError, ValueError):
            return None

    def _walk_events(self, root: Path) -> Iterator[_WalkEvent]:
        """Stream entries and skip all link/reparse-point objects."""
        stack = [root]
        while stack:
            current = stack.pop()
            try:
                with os.scandir(current) as entries:
                    for entry in entries:
                        entry_path = Path(entry.path)
                        try:
                            # Use the same lstat code path for the enumeration snapshot
                            # and later revalidation. On Windows, DirEntry.stat() may
                            # expose incomplete file identity metadata, which makes an
                            # unchanged file appear replaced when compared with os.lstat().
                            metadata = os.lstat(entry_path)
                        except FileNotFoundError:
                            yield _WalkEvent(
                                entry_path,
                                None,
                                False,
                                FileClassification.INACCESSIBLE,
                                "Item disappeared during directory enumeration.",
                            )
                            continue
                        except PermissionError:
                            yield _WalkEvent(
                                entry_path,
                                None,
                                False,
                                FileClassification.INACCESSIBLE,
                                "Permission was denied while reading item metadata.",
                            )
                            continue
                        except OSError:
                            yield _WalkEvent(
                                entry_path,
                                None,
                                False,
                                FileClassification.INACCESSIBLE,
                                "Item metadata could not be read.",
                            )
                            continue

                        link_status = self._validate_entry_reparse_status(metadata)
                        is_directory = stat.S_ISDIR(metadata.st_mode)
                        is_file = not is_directory
                        if link_status is True:
                            yield _WalkEvent(
                                entry_path,
                                metadata,
                                is_file,
                                FileClassification.REPARSE_POINT,
                                "Symlink, junction, or reparse point was skipped.",
                            )
                        elif link_status is None:
                            yield _WalkEvent(
                                entry_path,
                                metadata,
                                is_file,
                                FileClassification.INACCESSIBLE,
                                "Reparse-point metadata is unavailable; item skipped.",
                            )
                        elif is_directory:
                            stack.append(entry_path)
                        else:
                            yield _WalkEvent(entry_path, metadata, True)
            except PermissionError:
                yield _WalkEvent(
                    current,
                    None,
                    False,
                    FileClassification.INACCESSIBLE,
                    "Permission was denied while enumerating a directory.",
                )
            except OSError:
                yield _WalkEvent(
                    current,
                    None,
                    False,
                    FileClassification.INACCESSIBLE,
                    "Directory could not be enumerated.",
                )

    def _assess_file(
        self,
        path: Path,
        allowed_roots: tuple[Path, ...],
        category: str,
    ) -> SafetyAssessment:
        assess_for_cleanup = getattr(self._classifier, "assess_for_cleanup", None)
        if not callable(assess_for_cleanup):
            return SafetyAssessment(
                classification=FileClassification.REVIEW_REQUIRED,
                reason=(
                    "Safety classifier does not expose an explicit cleanup "
                    "assessment."
                ),
                policy_decision=CleanupPolicyDecision.REVIEW_REQUIRED,
                policy_reason=(
                    "Cleanup requires an explicit ALLOW decision from the "
                    "safety classifier."
                ),
            )
        try:
            assessment = assess_for_cleanup(
                path,
                allowed_roots,
                f"Known disposable location: {category}.",
            )
        except Exception:
            return SafetyAssessment(
                classification=FileClassification.INACCESSIBLE,
                reason="The safety classifier failed; item excluded.",
                policy_decision=CleanupPolicyDecision.BLOCK,
                policy_reason="Classifier errors never authorize cleanup.",
            )
        if not isinstance(assessment, SafetyAssessment):
            return SafetyAssessment(
                classification=FileClassification.REVIEW_REQUIRED,
                reason=(
                    "The safety classifier returned an invalid result; item "
                    "excluded."
                ),
                policy_decision=CleanupPolicyDecision.REVIEW_REQUIRED,
                policy_reason="Invalid classifier output never authorizes cleanup.",
            )
        return assessment

    @staticmethod
    def _issue(classification: FileClassification, reason: str) -> _FileOutcome:
        return _FileOutcome(classification=classification, reason=reason)

    @staticmethod
    def _read_file_metadata(path: Path) -> os.stat_result:
        """Read metadata without following the final symbolic link."""
        return os.lstat(path)

    @staticmethod
    def _same_file_identity(first: os.stat_result, second: os.stat_result) -> bool:
        """Compare stable identity/metadata; atime is intentionally excluded."""
        for field_name in ("st_dev", "st_ino", "st_size"):
            left = getattr(first, field_name, None)
            right = getattr(second, field_name, None)
            if left is None or right is None or left != right:
                return False
        if stat.S_IFMT(first.st_mode) != stat.S_IFMT(second.st_mode):
            return False
        for field_name in ("st_mtime_ns", "st_ctime_ns"):
            left = getattr(first, field_name, None)
            right = getattr(second, field_name, None)
            if left is None or right is None:
                fallback = field_name.removesuffix("_ns")
                left = getattr(first, fallback, None)
                right = getattr(second, fallback, None)
            if left is None or right is None or left != right:
                return False
        return True

    @staticmethod
    def _read_timestamps(
        metadata: os.stat_result,
        now: datetime,
    ) -> tuple[datetime, datetime] | None:
        try:
            accessed = float(metadata.st_atime)
            modified = float(metadata.st_mtime)
            now_timestamp = now.timestamp()
            if not math.isfinite(accessed) or not math.isfinite(modified):
                return None
            if accessed > now_timestamp or modified > now_timestamp:
                return None
            access_time = datetime.fromtimestamp(accessed, tz=now.tzinfo)
            modified_time = datetime.fromtimestamp(modified, tz=now.tzinfo)
        except (AttributeError, OSError, OverflowError, TypeError, ValueError):
            return None
        if access_time > now or modified_time > now:
            return None
        return access_time, modified_time

    @staticmethod
    def _age_days(now: datetime, timestamp: datetime) -> int:
        return max(0, int((now - timestamp).total_seconds() // 86400))

    @staticmethod
    def _build_fingerprint(metadata: os.stat_result) -> FileFingerprint:
        accessed_ns = getattr(metadata, "st_atime_ns", None)
        modified_ns = getattr(metadata, "st_mtime_ns", None)
        if accessed_ns is None:
            accessed_ns = int(float(metadata.st_atime) * 1_000_000_000)
        if modified_ns is None:
            modified_ns = int(float(metadata.st_mtime) * 1_000_000_000)
        return FileFingerprint(
            size_bytes=int(metadata.st_size),
            accessed_ns=int(accessed_ns),
            modified_ns=int(modified_ns),
            device_id=(
                int(metadata.st_dev)
                if getattr(metadata, "st_dev", None) is not None
                else None
            ),
            file_id=(
                int(metadata.st_ino)
                if getattr(metadata, "st_ino", None) is not None
                else None
            ),
        )

    @staticmethod
    def _is_path_within(path: Path, root: Path) -> bool:
        """Compare path components instead of string prefixes."""
        try:
            path.relative_to(root)
            return True
        except ValueError:
            if os.name == "nt":
                try:
                    path_value = os.path.normcase(os.path.abspath(path))
                    root_value = os.path.normcase(os.path.abspath(root))
                    return os.path.commonpath((path_value, root_value)) == root_value
                except (OSError, ValueError):
                    return False
            return False

    @staticmethod
    def _safe_progress(callback: ProgressCallback | None, message: str) -> None:
        if callback is None:
            return
        try:
            callback(message)
        except Exception:
            pass


def default_cleanup_roots() -> list[tuple[str, Path]]:
    """Return known, determinable disposable roots; absent caches are skipped."""
    roots: list[tuple[str, Path]] = []
    temp = os.environ.get("TEMP") or os.environ.get("TMP")
    if temp:
        roots.append(("User temporary files", Path(temp)))

    system_root = os.environ.get("SystemRoot")
    if system_root:
        roots.append(("Windows temporary files", Path(system_root) / "Temp"))

    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        local = Path(local_app_data)
        roots.extend(
            [
                (
                    "Chrome cache",
                    local / "Google" / "Chrome" / "User Data" / "Default" / "Cache",
                ),
                (
                    "Edge cache",
                    local / "Microsoft" / "Edge" / "User Data" / "Default" / "Cache",
                ),
            ]
        )
        profiles = local / "Mozilla" / "Firefox" / "Profiles"
        # Do not enumerate through a symlink/junction when determining profiles.
        if CleanupScanner._path_reparse_status(profiles) is False:
            try:
                profile_metadata = os.lstat(profiles)
                if stat.S_ISDIR(profile_metadata.st_mode):
                    with os.scandir(profiles) as entries:
                        for entry in entries:
                            try:
                                metadata = entry.stat(follow_symlinks=False)
                                reparse_status = (
                                    CleanupScanner._validate_entry_reparse_status(
                                        metadata
                                    )
                                )
                                if reparse_status is not False:
                                    continue
                                if stat.S_ISDIR(metadata.st_mode):
                                    roots.append(
                                        ("Firefox cache", Path(entry.path) / "cache2")
                                    )
                            except OSError:
                                continue
            except OSError:
                pass

    return roots
