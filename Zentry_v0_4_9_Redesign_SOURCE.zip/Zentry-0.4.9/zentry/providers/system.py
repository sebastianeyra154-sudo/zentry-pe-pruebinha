"""Read-only system diagnostics and the existing bounded cleanup adapter.

Diagnostics methods are synchronous and must be called from a worker thread by
GUI code. They never terminate processes, alter startup entries, edit the
Registry, or modify services.

``SystemSnapshot.health_score`` is a deterministic heuristic, not a scientific
or health guarantee. The existing compatibility model applies fixed penalties
at CPU >= 75/90%, RAM >= 80/90%, disk >= 85/95%, plus a penalty based on the
legacy estimated startup-impact count. That startup estimate is explicitly a
rough heuristic (one estimated high-impact item per four discovered startup
entries); it does not identify actual resource consumption or causality.

The richer diagnostic contracts in this module preserve unavailable values as
``None`` and expose status codes. ``collect_snapshot`` remains as a strict
compatibility adapter for the current GUI, whose existing ``SystemSnapshot``
contract cannot represent partial/unknown metrics.
"""

from __future__ import annotations

import logging
import math
import os
import ntpath
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Generic, Iterable, TypeVar

import psutil
from zentry.core.cleanup import CleanupPreview, CleanupService
from zentry.core.scanner import CleanupScanner, default_cleanup_roots
from zentry.core.safety import WindowsSafetyClassifier
from zentry.models import (
    CleanupResult,
    FileCandidate,
    ProcessInfo,
    StartupEntry,
    SystemSnapshot,
)

LOGGER = logging.getLogger("zentry.providers.system")

if sys.platform == "win32":
    import winreg
else:  # pragma: no cover - exercised by mocks in platform-independent tests
    winreg = None

T = TypeVar("T")


class DiagnosticStatus(str, Enum):
    """Availability state for diagnostic data, never a deletion decision."""

    AVAILABLE = "available"
    PARTIAL = "partial"
    UNAVAILABLE = "unavailable"
    PERMISSION_DENIED = "permission_denied"


@dataclass(frozen=True)
class MetricResult(Generic[T]):
    """A measured value plus a non-sensitive status/error code.

    ``value=None`` represents unknown/unavailable data. Error codes deliberately
    omit exception text because OS exception strings can contain private paths.
    """

    value: T | None
    status: DiagnosticStatus
    error_code: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.status, DiagnosticStatus):
            raise TypeError("status must be a DiagnosticStatus")
        if self.status in {DiagnosticStatus.AVAILABLE, DiagnosticStatus.PARTIAL}:
            if self.value is None:
                raise ValueError("available/partial metrics must carry a value")
        elif self.value is not None:
            raise ValueError("unavailable metrics must not carry a value")
        if self.error_code is not None:
            if not isinstance(self.error_code, str):
                raise TypeError("error_code must be a string or None")
            if not self.error_code.strip():
                raise ValueError("error_code must be non-empty when supplied")


@dataclass(frozen=True)
class MemoryDiagnostics:
    """Memory values from one psutil sample; byte values are session-only."""

    total_bytes: int | None = field(metadata={"privacy": "session_only", "persist": False})
    available_bytes: int | None = field(metadata={"privacy": "session_only", "persist": False})
    used_percent: float | None


@dataclass(frozen=True)
class DiskVolumeDiagnostics:
    """Read-only capacity for one mounted volume; paths are session-only."""

    device: str = field(metadata={"privacy": "session_only", "persist": False})
    mountpoint: str = field(metadata={"privacy": "session_only", "persist": False})
    filesystem: str = field(metadata={"privacy": "session_only", "persist": False})
    total_bytes: int | None
    used_bytes: int | None
    free_bytes: int | None
    used_percent: float | None
    status: DiagnosticStatus
    error_code: str | None = None


@dataclass(frozen=True)
class ProcessDiagnostics:
    """Per-process measurements; unavailable fields remain ``None``.

    Process name and PID are sensitive session data and must not be persisted in
    Zentry's aggregate history.
    """

    pid: int = field(metadata={"privacy": "session_only", "persist": False})
    name: str | None = field(metadata={"privacy": "session_only", "persist": False})
    cpu_percent: float | None
    memory_percent: float | None
    status: str | None = field(metadata={"privacy": "session_only", "persist": False})
    availability: DiagnosticStatus


@dataclass(frozen=True)
class ProcessListDiagnostics:
    """Result of reading process details, including incomplete observations."""

    processes: tuple[ProcessDiagnostics, ...]
    status: DiagnosticStatus
    observed_count: int | None
    inaccessible_count: int = 0
    disappeared_count: int = 0
    error_code: str | None = None


@dataclass(frozen=True)
class StartupDiagnostics:
    """Read-only startup inventory, with completeness explicitly represented.

    Registry command strings and Startup-folder paths are session-only and must
    not be included in persistent history/logs.
    """

    entries: tuple[StartupEntry, ...]
    status: DiagnosticStatus
    sources_checked: int
    inaccessible_sources: int = 0
    error_code: str | None = None
    permission_denied_sources: int = 0


@dataclass(frozen=True)
class SystemDiagnosticsReport:
    """Detailed read-only snapshot with independent availability per metric."""

    cpu_percent: MetricResult[float]
    memory: MetricResult[MemoryDiagnostics]
    volumes: MetricResult[tuple[DiskVolumeDiagnostics, ...]]
    process_count: MetricResult[int]
    startup: StartupDiagnostics
    collected_at: datetime = field(default_factory=lambda: datetime.now().astimezone())


class DiagnosticCollectionError(RuntimeError):
    """Required data for a legacy all-numeric snapshot was unavailable."""

    def __init__(self, error_codes: Iterable[str]) -> None:
        self.error_codes = tuple(sorted(set(error_codes)))
        safe_codes = ", ".join(self.error_codes) or "required_metric_unavailable"
        super().__init__(f"System diagnostics incomplete: {safe_codes}")


class SystemDiagnosticsProvider:
    """Read-only Windows/system diagnostics plus bounded cleanup compatibility.

    ``collect_diagnostics`` is the detailed API. ``collect_snapshot`` preserves
    the return type expected by the current GUI and fails explicitly rather
    than substituting zero for an unavailable required metric.
    """

    def __init__(self, cpu_sample_interval: float = 0.35) -> None:
        if isinstance(cpu_sample_interval, bool) or not isinstance(
            cpu_sample_interval, (int, float)
        ):
            raise TypeError("cpu_sample_interval must be a number")
        if not math.isfinite(float(cpu_sample_interval)) or cpu_sample_interval < 0.1:
            raise ValueError("cpu_sample_interval must be finite and >= 0.1 seconds")
        self._cpu_sample_interval = float(cpu_sample_interval)
        self._classifier = WindowsSafetyClassifier()
        self._scanner = CleanupScanner(self._classifier)
        self._cleanup_service = CleanupService(
            classifier=self._classifier,
            roots_provider=default_cleanup_roots,
        )

    @staticmethod
    def _error_status(exc: BaseException) -> tuple[DiagnosticStatus, str]:
        if isinstance(exc, (PermissionError, psutil.AccessDenied)):
            return DiagnosticStatus.PERMISSION_DENIED, "access_denied"
        if isinstance(exc, (FileNotFoundError, psutil.NoSuchProcess, psutil.ZombieProcess)):
            return DiagnosticStatus.UNAVAILABLE, "resource_disappeared"
        if isinstance(exc, (OSError, psutil.Error)):
            return DiagnosticStatus.UNAVAILABLE, "os_query_failed"
        if isinstance(exc, (ValueError, TypeError, AttributeError, OverflowError)):
            return DiagnosticStatus.UNAVAILABLE, "invalid_or_unavailable_value"
        return DiagnosticStatus.UNAVAILABLE, "unexpected_provider_error"

    @staticmethod
    def _valid_percent(value: object) -> float | None:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        number = float(value)
        if not math.isfinite(number) or not 0 <= number <= 100:
            return None
        return number

    @staticmethod
    def _valid_nonnegative_int(value: object) -> int | None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return None
        return value

    def sample_activity(self) -> tuple[float | None, float | None]:
        """Return non-blocking CPU and RAM percentages for the UI activity graph.

        This lightweight sample is intentionally independent of the full system
        diagnostic snapshot and is called only from a background worker. Unknown
        metrics remain None; callers must not render unavailable data as zero.
        """
        cpu: float | None = None
        memory: float | None = None
        try:
            cpu = self._valid_percent(psutil.cpu_percent(interval=None))
        except Exception as exc:  # noqa: BLE001 - OS telemetry is best effort
            LOGGER.debug("Dashboard CPU sample unavailable: %s", type(exc).__name__)
        try:
            memory = self._valid_percent(psutil.virtual_memory().percent)
        except Exception as exc:  # noqa: BLE001 - OS telemetry is best effort
            LOGGER.debug("Dashboard memory sample unavailable: %s", type(exc).__name__)
        return cpu, memory

    def collect_cpu_usage(self) -> MetricResult[float]:
        """Sample total CPU usage; callers should run this outside the GUI thread."""
        try:
            value = self._valid_percent(
                psutil.cpu_percent(interval=self._cpu_sample_interval)
            )
        except Exception as exc:  # noqa: BLE001 - OS boundary
            status, code = self._error_status(exc)
            return MetricResult(value=None, status=status, error_code=code)
        if value is None:
            return MetricResult(
                value=None,
                status=DiagnosticStatus.UNAVAILABLE,
                error_code="invalid_or_unavailable_value",
            )
        return MetricResult(value=value, status=DiagnosticStatus.AVAILABLE)

    def collect_memory_metrics(self) -> MetricResult[MemoryDiagnostics]:
        """Read RAM total, available bytes and percentage without defaulting to zero."""
        try:
            vm = psutil.virtual_memory()
        except Exception as exc:  # noqa: BLE001 - OS boundary
            status, code = self._error_status(exc)
            return MetricResult(value=None, status=status, error_code=code)

        total = self._valid_nonnegative_int(getattr(vm, "total", None))
        available = self._valid_nonnegative_int(getattr(vm, "available", None))
        percent = self._valid_percent(getattr(vm, "percent", None))
        result = MemoryDiagnostics(
            total_bytes=total,
            available_bytes=available,
            used_percent=percent,
        )
        found = sum(value is not None for value in (total, available, percent))
        if found == 3:
            return MetricResult(value=result, status=DiagnosticStatus.AVAILABLE)
        if found:
            return MetricResult(
                value=result,
                status=DiagnosticStatus.PARTIAL,
                error_code="some_memory_fields_unavailable",
            )
        return MetricResult(
            value=None,
            status=DiagnosticStatus.UNAVAILABLE,
            error_code="memory_metrics_unavailable",
        )

    def collect_disk_volumes(self) -> MetricResult[tuple[DiskVolumeDiagnostics, ...]]:
        """Read capacity for mounted local volumes, preserving failures per volume."""
        try:
            partitions = list(psutil.disk_partitions(all=False))
        except Exception as exc:  # noqa: BLE001 - OS boundary
            status, code = self._error_status(exc)
            return MetricResult(value=None, status=status, error_code=code)

        if not partitions:
            return MetricResult(
                value=None,
                status=DiagnosticStatus.UNAVAILABLE,
                error_code="no_mounted_volumes",
            )

        volumes: list[DiskVolumeDiagnostics] = []
        unavailable_count = 0
        permission_count = 0
        for partition in partitions:
            device = str(getattr(partition, "device", "") or "")
            mountpoint = str(getattr(partition, "mountpoint", "") or "")
            filesystem = str(getattr(partition, "fstype", "") or "")
            if not mountpoint:
                unavailable_count += 1
                volumes.append(
                    DiskVolumeDiagnostics(
                        device=device,
                        mountpoint="",
                        filesystem=filesystem,
                        total_bytes=None,
                        used_bytes=None,
                        free_bytes=None,
                        used_percent=None,
                        status=DiagnosticStatus.UNAVAILABLE,
                        error_code="mountpoint_unavailable",
                    )
                )
                continue
            try:
                usage = psutil.disk_usage(mountpoint)
                total = self._valid_nonnegative_int(getattr(usage, "total", None))
                used = self._valid_nonnegative_int(getattr(usage, "used", None))
                free = self._valid_nonnegative_int(getattr(usage, "free", None))
                percent = self._valid_percent(getattr(usage, "percent", None))
                if (
                    None in (total, used, free, percent)
                    or used is None
                    or total is None
                    or free is None
                ):
                    raise ValueError("invalid_disk_usage_values")
                if used + free > total:
                    raise ValueError("inconsistent_disk_usage_values")
                volumes.append(
                    DiskVolumeDiagnostics(
                        device=device,
                        mountpoint=mountpoint,
                        filesystem=filesystem,
                        total_bytes=total,
                        used_bytes=used,
                        free_bytes=free,
                        used_percent=percent,
                        status=DiagnosticStatus.AVAILABLE,
                    )
                )
            except Exception as exc:  # noqa: BLE001 - per-volume OS boundary
                status, code = self._error_status(exc)
                unavailable_count += 1
                if status is DiagnosticStatus.PERMISSION_DENIED:
                    permission_count += 1
                volumes.append(
                    DiskVolumeDiagnostics(
                        device=device,
                        mountpoint=mountpoint,
                        filesystem=filesystem,
                        total_bytes=None,
                        used_bytes=None,
                        free_bytes=None,
                        used_percent=None,
                        status=status,
                        error_code=code,
                    )
                )

        if unavailable_count == 0:
            return MetricResult(value=tuple(volumes), status=DiagnosticStatus.AVAILABLE)
        if unavailable_count == len(volumes) and permission_count == len(volumes):
            return MetricResult(
                value=None,
                status=DiagnosticStatus.PERMISSION_DENIED,
                error_code="all_volumes_access_denied",
            )
        return MetricResult(
            value=tuple(volumes),
            status=DiagnosticStatus.PARTIAL,
            error_code="some_volumes_unavailable",
        )

    def collect_process_count(self) -> MetricResult[int]:
        """Return the number of process IDs reported by psutil, or unknown."""
        try:
            pids = psutil.pids()
            if not isinstance(pids, (list, tuple, set)):
                raise TypeError("psutil.pids returned an unexpected type")
            return MetricResult(value=len(pids), status=DiagnosticStatus.AVAILABLE)
        except Exception as exc:  # noqa: BLE001 - OS boundary
            status, code = self._error_status(exc)
            return MetricResult(value=None, status=status, error_code=code)

    def collect_startup_diagnostics(self) -> StartupDiagnostics:
        """Read standard Run/RunOnce registry keys and Startup folders only.

        Registry keys are opened with read-only access. Missing keys/folders are
        normal; access errors make the result partial or unavailable, never a
        claim that the unavailable source contains zero entries.
        """
        entries: list[StartupEntry] = []
        sources_checked = 0
        inaccessible_sources = 0
        permission_denied_sources = 0
        registry_supported = winreg is not None

        if winreg is not None:
            registry_queries = self._registry_queries(winreg)
            for hive, registry_path, source, view_flag in registry_queries:
                sources_checked += 1
                try:
                    access = getattr(winreg, "KEY_READ", 0x20019) | view_flag
                    with winreg.OpenKey(hive, registry_path, 0, access) as key:
                        value_count = winreg.QueryInfoKey(key)[1]
                        for index in range(value_count):
                            try:
                                name, command, _ = winreg.EnumValue(key, index)
                                entries.append(
                                    StartupEntry(
                                        name=str(name),
                                        command=str(command),
                                        source=source,
                                    )
                                )
                            except FileNotFoundError:
                                # The value may have disappeared during the read.
                                inaccessible_sources += 1
                            except (PermissionError, psutil.AccessDenied):
                                inaccessible_sources += 1
                                permission_denied_sources += 1
                            except Exception:
                                inaccessible_sources += 1
                except FileNotFoundError:
                    # A missing Run/RunOnce key is normal and means no entries at
                    # that specific source, not a failed read.
                    continue
                except (PermissionError, psutil.AccessDenied):
                    inaccessible_sources += 1
                    permission_denied_sources += 1
                except Exception:
                    inaccessible_sources += 1

        for source, directory in self._startup_directories():
            sources_checked += 1
            try:
                with os.scandir(directory) as directory_entries:
                    for item in directory_entries:
                        try:
                            if not item.is_file(follow_symlinks=False):
                                continue
                            entries.append(
                                StartupEntry(
                                    name=item.name,
                                    command=str(Path(item.path)),
                                    source=f"{source} (target not resolved)",
                                )
                            )
                        except OSError:
                            inaccessible_sources += 1
            except FileNotFoundError:
                continue
            except PermissionError:
                inaccessible_sources += 1
                permission_denied_sources += 1
            except OSError:
                inaccessible_sources += 1

        unique: dict[tuple[str, str, str], StartupEntry] = {}
        for entry in entries:
            key = (entry.source.casefold(), entry.name.casefold(), entry.command.casefold())
            unique[key] = entry
        ordered = tuple(
            sorted(
                unique.values(),
                key=lambda item: (item.name.casefold(), item.source.casefold()),
            )
        )

        if inaccessible_sources == 0 and registry_supported:
            status = DiagnosticStatus.AVAILABLE
            error_code = None
        elif ordered:
            status = DiagnosticStatus.PARTIAL
            error_code = "some_startup_sources_unavailable"
        elif permission_denied_sources and permission_denied_sources == inaccessible_sources:
            status = DiagnosticStatus.PERMISSION_DENIED
            error_code = "access_denied"
        elif registry_supported:
            status = DiagnosticStatus.UNAVAILABLE
            error_code = "startup_sources_unavailable"
        else:
            status = DiagnosticStatus.UNAVAILABLE
            error_code = "windows_registry_unavailable"

        return StartupDiagnostics(
            entries=ordered,
            status=status,
            sources_checked=sources_checked,
            inaccessible_sources=inaccessible_sources,
            error_code=error_code,
            permission_denied_sources=permission_denied_sources,
        )

    def _startup_directories(self) -> tuple[tuple[str, Path], ...]:
        """Return the standard per-user and all-users Startup folders."""
        startup_dirs: list[tuple[str, Path]] = []
        appdata = os.environ.get("APPDATA")
        program_data = os.environ.get("ProgramData")
        relative = Path("Microsoft") / "Windows" / "Start Menu" / "Programs" / "Startup"
        if appdata:
            startup_dirs.append(("Current user Startup folder", Path(appdata) / relative))
        if program_data:
            startup_dirs.append(("Common Startup folder", Path(program_data) / relative))
        return tuple(startup_dirs)

    @staticmethod
    def _registry_queries(registry: object) -> tuple[tuple[object, str, str, int], ...]:
        """Build read-only Run/RunOnce queries for the relevant registry views."""
        queries: list[tuple[object, str, str, int]] = []
        architecture = (
            os.environ.get("PROCESSOR_ARCHITEW6432")
            or os.environ.get("PROCESSOR_ARCHITECTURE", "")
        ).upper()
        is_64_bit_windows = sys.maxsize > 2**32 or architecture in {"AMD64", "ARM64", "IA64"}
        flag_32 = int(getattr(registry, "KEY_WOW64_32KEY", 0) or 0)
        flag_64 = int(getattr(registry, "KEY_WOW64_64KEY", 0) or 0)
        if is_64_bit_windows and flag_32 and flag_64:
            view_flags = (("64-bit view", flag_64), ("32-bit view", flag_32))
        else:
            view_flags = (("native view", 0),)

        hives = (
            (getattr(registry, "HKEY_CURRENT_USER"), "HKCU"),
            (getattr(registry, "HKEY_LOCAL_MACHINE"), "HKLM"),
        )
        paths = (
            (r"Software\Microsoft\Windows\CurrentVersion\Run", "Run"),
            (r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "RunOnce"),
        )
        for hive, hive_label in hives:
            for path, path_label in paths:
                for view_label, view_flag in view_flags:
                    queries.append(
                        (hive, path, f"{hive_label} {path_label} ({view_label})", view_flag)
                    )
        return tuple(queries)

    def collect_diagnostics(self) -> SystemDiagnosticsReport:
        """Collect each read-only metric independently; unavailable values remain unknown."""
        cpu = self.collect_cpu_usage()
        memory = self.collect_memory_metrics()
        volumes = self.collect_disk_volumes()
        process_count = self.collect_process_count()
        startup = self.collect_startup_diagnostics()
        return SystemDiagnosticsReport(
            cpu_percent=cpu,
            memory=memory,
            volumes=volumes,
            process_count=process_count,
            startup=startup,
            collected_at=datetime.now().astimezone(),
        )

    def collect_snapshot(self) -> SystemSnapshot:
        """Compatibility adapter for the current GUI's all-numeric model.

        If required values are unknown, raise ``DiagnosticCollectionError``
        rather than reporting zero. Partial volume failures are tolerated when
        the system volume itself has a complete, valid measurement.
        """
        report = self.collect_diagnostics()
        errors: list[str] = []

        cpu = report.cpu_percent.value
        if cpu is None:
            errors.append(report.cpu_percent.error_code or "cpu_unavailable")

        memory = report.memory.value
        memory_percent = memory.used_percent if memory is not None else None
        if memory_percent is None:
            errors.append(report.memory.error_code or "memory_percent_unavailable")

        volumes = report.volumes.value
        system_volume = self._find_system_volume(volumes or ())
        if (
            system_volume is None
            or system_volume.used_percent is None
            or system_volume.free_bytes is None
        ):
            errors.append("system_volume_unavailable")

        process_count = report.process_count.value
        if process_count is None:
            errors.append(report.process_count.error_code or "process_count_unavailable")

        startup = report.startup
        if startup.status is not DiagnosticStatus.AVAILABLE:
            errors.append(startup.error_code or "startup_inventory_incomplete")

        if errors:
            raise DiagnosticCollectionError(errors)
        assert cpu is not None
        assert memory_percent is not None
        assert system_volume is not None and system_volume.used_percent is not None
        assert system_volume.free_bytes is not None
        assert process_count is not None

        startup_count = len(startup.entries)
        # Legacy compatibility heuristic only: the app does not measure startup
        # performance impact. UI text already labels this count as an estimate.
        estimated_high_impact = min(startup_count // 4, startup_count)
        return SystemSnapshot(
            cpu_percent=cpu,
            memory_percent=memory_percent,
            disk_percent=system_volume.used_percent,
            disk_free_gb=system_volume.free_bytes / (1024**3),
            startup_count=startup_count,
            startup_high_impact_count=estimated_high_impact,
            process_count=process_count,
            collected_at=report.collected_at,
        )

    def _find_system_volume(
        self,
        volumes: tuple[DiskVolumeDiagnostics, ...],
    ) -> DiskVolumeDiagnostics | None:
        drive = os.environ.get("SystemDrive")
        if drive:
            system_mount = drive.rstrip("\\/") + "\\"
        elif os.environ.get("SystemRoot"):
            system_mount = ntpath.splitdrive(os.environ["SystemRoot"])[0] + "\\"
        elif os.name == "nt":
            system_mount = Path(os.path.abspath(os.sep)).anchor or "C:\\"
        else:
            system_mount = os.path.abspath(os.sep)

        normalized_target = ntpath.normcase(ntpath.normpath(system_mount))
        for volume in volumes:
            if ntpath.normcase(ntpath.normpath(volume.mountpoint)) == normalized_target:
                if volume.status is DiagnosticStatus.AVAILABLE:
                    return volume
        return None

    def list_startup_entries(self) -> list[StartupEntry]:
        """Legacy UI adapter; refuses to present an incomplete list as complete."""
        result = self.collect_startup_diagnostics()
        if result.status is not DiagnosticStatus.AVAILABLE:
            raise DiagnosticCollectionError(
                [result.error_code or "startup_inventory_incomplete"]
            )
        return list(result.entries)

    def collect_process_details(
        self,
        limit: int = 80,
        sample_interval: float = 0.1,
    ) -> ProcessListDiagnostics:
        """Collect process metrics with unknown values kept as ``None``.

        CPU usage is sampled over one shared interval instead of treating the
        first psutil per-process ``cpu_percent`` sample as a measured zero.
        Call this method from a worker because it waits for ``sample_interval``.
        """
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            raise ValueError("limit must be an integer >= 1")
        if isinstance(sample_interval, bool) or not isinstance(
            sample_interval, (int, float)
        ):
            raise TypeError("sample_interval must be a number")
        if not math.isfinite(float(sample_interval)) or sample_interval < 0.1:
            raise ValueError("sample_interval must be finite and >= 0.1 seconds")

        try:
            process_iterator = psutil.process_iter()
            observed: list[tuple[object, ProcessDiagnostics, bool]] = []
            inaccessible_count = 0
            disappeared_count = 0
            for process in process_iterator:
                try:
                    pid = int(process.pid)
                except Exception:  # noqa: BLE001 - process may exit during enumeration
                    disappeared_count += 1
                    continue
                try:
                    metadata = process.as_dict(
                        attrs=["name", "memory_percent", "status"],
                        ad_value=None,
                    )
                    name_value = metadata.get("name")
                    name = name_value if isinstance(name_value, str) and name_value else None
                    memory_percent = self._valid_percent(metadata.get("memory_percent"))
                    status_value = metadata.get("status")
                    status_text = (
                        status_value
                        if isinstance(status_value, str) and status_value
                        else None
                    )
                    process.cpu_percent(interval=None)  # prime the counter; not a reading
                    record = ProcessDiagnostics(
                        pid=pid,
                        name=name,
                        cpu_percent=None,
                        memory_percent=memory_percent,
                        status=status_text,
                        availability=DiagnosticStatus.AVAILABLE
                        if (
                            name is not None
                            and memory_percent is not None
                            and status_text is not None
                        )
                        else DiagnosticStatus.PARTIAL,
                    )
                    observed.append((process, record, True))
                except (psutil.NoSuchProcess, psutil.ZombieProcess):
                    disappeared_count += 1
                except (psutil.AccessDenied, PermissionError):
                    inaccessible_count += 1
                    observed.append(
                        (
                            process,
                            ProcessDiagnostics(
                                pid=pid,
                                name=None,
                                cpu_percent=None,
                                memory_percent=None,
                                status=None,
                                availability=DiagnosticStatus.PERMISSION_DENIED,
                            ),
                            False,
                        )
                    )
                except Exception:  # noqa: BLE001 - isolate per-process failures
                    inaccessible_count += 1
                    observed.append(
                        (
                            process,
                            ProcessDiagnostics(
                                pid=pid,
                                name=None,
                                cpu_percent=None,
                                memory_percent=None,
                                status=None,
                                availability=DiagnosticStatus.UNAVAILABLE,
                            ),
                            False,
                        )
                    )
        except Exception as exc:  # noqa: BLE001 - enumeration boundary
            status, code = self._error_status(exc)
            return ProcessListDiagnostics(
                processes=(),
                status=status,
                observed_count=None,
                inaccessible_count=0,
                disappeared_count=0,
                error_code=code,
            )

        initial_observed_count = len(observed) + disappeared_count
        if observed and sample_interval > 0:
            time.sleep(float(sample_interval))

        results: list[ProcessDiagnostics] = []
        for process, record, can_sample_cpu in observed:
            if not can_sample_cpu:
                results.append(record)
                continue
            try:
                cpu_percent = self._valid_process_cpu(process.cpu_percent(interval=None))
                availability = (
                    DiagnosticStatus.AVAILABLE
                    if cpu_percent is not None
                    and record.name is not None
                    and record.memory_percent is not None
                    and record.status is not None
                    else DiagnosticStatus.PARTIAL
                )
                results.append(
                    ProcessDiagnostics(
                        pid=record.pid,
                        name=record.name,
                        cpu_percent=cpu_percent,
                        memory_percent=record.memory_percent,
                        status=record.status,
                        availability=availability,
                    )
                )
            except (psutil.NoSuchProcess, psutil.ZombieProcess):
                disappeared_count += 1
            except (psutil.AccessDenied, PermissionError):
                inaccessible_count += 1
                results.append(
                    ProcessDiagnostics(
                        pid=record.pid,
                        name=record.name,
                        cpu_percent=None,
                        memory_percent=record.memory_percent,
                        status=record.status,
                        availability=DiagnosticStatus.PARTIAL,
                    )
                )
            except Exception:  # noqa: BLE001 - isolate per-process failures
                inaccessible_count += 1
                results.append(
                    ProcessDiagnostics(
                        pid=record.pid,
                        name=record.name,
                        cpu_percent=None,
                        memory_percent=record.memory_percent,
                        status=record.status,
                        availability=DiagnosticStatus.PARTIAL,
                    )
                )

        results.sort(
            key=lambda item: (
                item.cpu_percent is not None,
                item.cpu_percent if item.cpu_percent is not None else -1.0,
                item.memory_percent is not None,
                item.memory_percent if item.memory_percent is not None else -1.0,
            ),
            reverse=True,
        )
        limited = tuple(results[:limit])
        any_partial = (
            inaccessible_count > 0
            or disappeared_count > 0
            or any(item.availability is not DiagnosticStatus.AVAILABLE for item in limited)
        )
        status = DiagnosticStatus.PARTIAL if any_partial else DiagnosticStatus.AVAILABLE
        return ProcessListDiagnostics(
            processes=limited,
            status=status,
            observed_count=initial_observed_count,
            inaccessible_count=inaccessible_count,
            disappeared_count=disappeared_count,
            error_code="some_process_details_unavailable" if any_partial else None,
        )

    @staticmethod
    def _valid_process_cpu(value: object) -> float | None:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        value_float = float(value)
        if not math.isfinite(value_float) or value_float < 0:
            return None
        return value_float

    def list_processes(self, limit: int = 80) -> list[ProcessInfo]:
        """Backward-compatible GUI adapter exposing only fully measured rows.

        The current ``ProcessInfo`` model requires non-optional numeric values,
        so rows with unavailable CPU/RAM data are omitted rather than assigned
        fabricated zeroes. The richer ``collect_process_details`` API preserves
        them explicitly for a future GUI integration.
        """
        result = self.collect_process_details(limit=limit)
        if result.status in {
            DiagnosticStatus.UNAVAILABLE,
            DiagnosticStatus.PERMISSION_DENIED,
        }:
            raise DiagnosticCollectionError([result.error_code or "process_inventory_unavailable"])
        return [
            ProcessInfo(
                pid=item.pid,
                name=item.name,
                cpu_percent=item.cpu_percent,
                memory_percent=item.memory_percent,
                status=item.status,
            )
            for item in result.processes
            if item.name is not None
            and item.cpu_percent is not None
            and item.memory_percent is not None
            and item.status is not None
            and item.memory_percent <= 100
        ]

    def scan_cleanup(self, min_age_days: int = 31, progress=None):
        roots = default_cleanup_roots()
        # Invalidate the prior candidate manifest before starting a new scan. If
        # scanning fails, old UI candidates cannot be replayed for cleanup.
        self._cleanup_service.invalidate_scan()
        summary = self._scanner.scan(
            roots,
            min_age_days=min_age_days,
            progress=progress,
        )
        self._cleanup_service._register_scan(summary, roots, min_age_days)
        return summary

    def preview_cleanup(
        self,
        candidates: Iterable[FileCandidate],
    ) -> CleanupPreview:
        """Produce a read-only selected-category dry-run summary."""
        return self._cleanup_service.preview_selection(candidates)

    def scan_system_protection(self, progress=None):
        return self._scanner.scan_system_protection(progress=progress)

    def delete_files(
        self,
        candidates: Iterable[FileCandidate],
        min_age_days: int = 31,
        *,
        confirmed: bool = False,
    ) -> CleanupResult:
        """Compatibility adapter to the validated cleanup service.

        The caller must pass ``confirmed=True`` only after the user accepts the
        confirmation dialog. Candidate objects must come from the latest scan.
        No filesystem mutation is implemented in the GUI or this adapter.
        """
        return self._cleanup_service.execute_selected(
            candidates,
            min_age_days=min_age_days,
            confirmed=confirmed,
        )

    def default_cleanup_paths(self) -> list[tuple[str, Path]]:
        return default_cleanup_roots()

    @property
    def protected_roots(self) -> tuple[str, ...]:
        return self._classifier.protected_root_strings()
