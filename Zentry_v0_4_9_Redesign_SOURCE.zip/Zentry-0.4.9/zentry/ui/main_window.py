from __future__ import annotations

import logging
import re
from string import Formatter
from typing import Callable, Mapping

from PySide6.QtCore import QThread, QTimer, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QCloseEvent, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QCheckBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from zentry.models import (
    CleanupPolicyDecision,
    CleanupResult,
    CleanupScanSummary,
    FileCandidate,
    FileClassification,
    ProcessInfo,
    StartupEntry,
    SystemProtectionSummary,
    SystemSnapshot,
)
from zentry.core.history import (
    HistoryEvent,
    HistoryOperation,
    HistoryResult,
    HistoryStore,
    HistoryStoreError,
)
from zentry.core.cleanup import CleanupPreview
from zentry.core.local_state import get_app_data_directory
from zentry.core.logging_setup import log_safe_exception
from zentry.providers.system import SystemDiagnosticsProvider

LOGGER = logging.getLogger("zentry.ui")


def _format_bytes(value: int | None, unavailable: str) -> str:
    if value is None:
        return unavailable
    if value >= 1024**3:
        return f"{value / (1024**3):.2f} GB"
    if value >= 1024**2:
        return f"{value / (1024**2):.1f} MB"
    return f"{value / 1024:.1f} KB" if value else "0 B"


def _cleanup_history_result(data: CleanupResult) -> HistoryResult:
    if data.failed_files and data.moved_files:
        return HistoryResult.PARTIAL
    if data.failed_files and not data.moved_files:
        return HistoryResult.FAILED
    if data.omitted_files and data.moved_files:
        return HistoryResult.PARTIAL
    if data.omitted_files and not data.moved_files:
        return HistoryResult.SKIPPED
    if data.selected_files == 0:
        return HistoryResult.NO_CANDIDATES
    if data.moved_files == data.selected_files:
        return HistoryResult.SUCCESS
    return HistoryResult.INCOMPLETE


TRANSLATIONS = {
    "es": {
        "brand_title": "ZENTRY",
        "brand_subtitle": "DIAGNÓSTICO Y LIMPIEZA SEGURA",
        "overview": "Inicio",
        "diagnostics": "Diagnóstico",
        "cleanup": "Limpieza segura",
        "cleanup_nav": "Limpieza segura",
        "startup": "Inicio de Windows",
        "startup_nav": "Inicio de Windows",
        "processes": "Procesos",
        "history": "Historial",
        "safe_mode": "TU PC, EN SU MEJOR VERSIÓN",
        "system_protection": "Protección Windows",
        "system_protection_nav": "Protección Windows",
        "pages_accessible_name": "Páginas de Zentry",
        "page_overview": "ZENTRY  /  ESTADO DEL EQUIPO",
        "title_overview": "Estado del equipo",
        "overview_subtitle": "Resumen de rendimiento y mantenimiento",
        "safety_badge": "🛡️ Modo seguro",
        "safety_badge_tooltip": "Los diagnósticos no modifican el equipo. La limpieza requiere vista previa y confirmación, y mueve archivos a la Papelera de reciclaje.",
        "safe_cleanup_title": "Limpieza segura",
        "safe_cleanup_desc": "Revisa los candidatos antes de confirmar. Nada se elimina sin tu aprobación.",
        "safe_cleanup_button": "Ver vista previa  →",
        "scan": "ESCANEAR SISTEMA  →",
        "scanning": "ESCANEANDO...  ◌",
        "complete": "ESCANEO COMPLETO  ✓",
        "notice": "La limpieza es reversible: primero verás una vista previa y solo se moverán archivos a la Papelera después de confirmar.",
        "dashboard_waiting": "Listo para analizar el equipo",
        "dashboard_healthy": "Los indicadores medidos están en rangos generales",
        "dashboard_moderate": "Hay indicadores que conviene revisar",
        "dashboard_elevated": "Conviene revisar el estado del sistema",
        "dashboard_detail_waiting": "Ejecuta el análisis para mostrar métricas reales del equipo.",
        "dashboard_detail_ready": "La puntuación es orientativa; revisa las métricas antes de tomar decisiones.",
        "disk_usage": "Espacio libre en la unidad principal",
        "activity_title": "Actividad del sistema",
        "activity_cpu": "CPU",
        "activity_memory": "RAM",
        "activity_waiting": "Recopilando muestras reales de actividad...",
        "progress_files": "Archivos revisados: {count}",
        "cpu": "CPU",
        "memory": "MEMORIA",
        "storage": "ALMACENAMIENTO",
        "startup_metric": "INICIO",
        "waiting": "Esperando escaneo",
        "current_cpu": "Uso actual del procesador",
        "current_memory": "Uso actual de memoria",
        "available": "{value:.1f} GB disponibles",
        "estimated": "Impacto alto estimado: {value}",
        "health": "SALUD DEL SISTEMA",
        "run_scan": "Ejecuta un escaneo para calcular una línea base.",
        "healthy": "La línea base parece saludable. Diagnostica cuellos de botella concretos antes de optimizar.",
        "moderate": "Se detecta presión moderada. Revisa las métricas antes de decidir una acción.",
        "elevated": "Se detecta presión elevada. El diagnóstico debe preceder a la optimización.",
        "recommendations": "ACCIONES RECOMENDADAS",
        "cleanup_action": "Analizar archivos antiguos",
        "cleanup_desc": "Busca archivos en ubicaciones de caché/temporales conocidos que lleven al menos un mes sin acceso ni modificación.",
        "system_action": "Analizar archivos protegidos de Windows",
        "system_desc": "Comprueba árboles del sistema y clasifica recursos que el limpiador debe bloquear.",
        "low_risk": "RIESGO BAJO",
        "workflow": "ZENTRY · DATOS REALES · LIMPIEZA CON CONFIRMACIÓN",
        "refresh": "ACTUALIZAR",
        "no_data": "No hay datos todavía.",
        "diagnostics_body": "Métricas reales de Windows obtenidas en modo de lectura.",
        "processes_body": "Inspección de procesos en tiempo real. Finalizar procesos no está habilitado.",
        "startup_body": "Entradas de inicio detectadas en el registro. Esta vista es de solo lectura.",
        "cleanup_body": "Solo se muestran como eliminables archivos de ubicaciones desechables conocidas, con una antigüedad mínima configurable. Los recursos protegidos o ambiguos se bloquean o se excluyen.",
        "history_body": "Historial local con resúmenes agregados. No guarda rutas completas, nombres de archivos ni detalles de procesos.",
        "history_operation": "Operación",
        "history_result": "Resultado",
        "history_files": "Cantidad",
        "history_estimated_bytes": "Bytes estimados",
        "history_moved_bytes": "Bytes enviados",
        "history_omissions": "Omitidos / fallidos",
        "history_op_system_diagnostics": "Diagnóstico del equipo",
        "history_op_stale_scan": "Análisis de archivos antiguos",
        "history_op_system_protection_scan": "Análisis de protección",
        "history_op_cleanup": "Limpieza",
        "history_op_application_error": "Error de operación",
        "history_op_legacy_aggregate": "Historial anterior (resumen)",
        "history_result_success": "Correcto",
        "history_result_partial": "Parcial",
        "history_result_failed": "Fallido",
        "history_result_no_candidates": "Sin candidatos",
        "history_result_skipped": "Omitido",
        "history_result_cancelled": "Cancelado",
        "history_result_incomplete": "Incompleto",
        "history_na": "N/D",
        "history_count_pair": "{skipped} omitidos / {failed} fallidos",
        "history_clear": "BORRAR HISTORIAL",
        "history_clear_confirm_title": "Borrar historial local",
        "history_clear_confirm": "Se borrará únicamente el archivo history.json. Los logs no se borrarán. ¿Continuar?",
        "history_clear_done": "Se borró el historial local.",
        "history_clear_missing": "No había un archivo de historial para borrar.",
        "history_clear_failed": "No se pudo borrar el historial. Revisa los permisos de la carpeta de datos de Zentry.",
        "scan_cleanup": "ANALIZAR ARCHIVOS ANTIGUOS",
        "scan_protection": "ANALIZAR PROTECCIÓN DE WINDOWS",
        "age_label": "ANTIGÜEDAD MÍNIMA",
        "days": "días",
        "select_all": "SELECCIONAR TODO",
        "clear_selection": "LIMPIAR SELECCIÓN",
        "delete_selected": "ENVIAR SELECCIONADOS A LA PAPELERA",
        "no_candidates": "No se encontraron candidatos seguros con estos criterios.",
        "reclaimable": "Potencial recuperable: {value:.2f} GB",
        "selected": "Seleccionado: {files} archivos · {value:.2f} GB",
        "files": "archivos",
        "process_name": "Proceso",
        "pid": "PID",
        "cpu_header": "CPU %",
        "ram": "RAM %",
        "status": "Estado",
        "startup_name": "Nombre",
        "source": "Origen",
        "command": "Comando",
        "time": "Hora",
        "health_score": "Salud",
        "disk": "Disco %",
        "reclaim": "Recuperable",
        "category": "Categoría",
        "file_name": "Archivo",
        "size": "Tamaño",
        "path": "Ruta",
        "last_access": "Último acceso",
        "last_modified": "Última modificación",
        "reason": "Motivo",
        "classification": "Clasificación",
        "language": "ES  ⌄",
        "version": "ZENTRY 0.4.9  ·  WINDOWS",
        "confirm_title": "Confirmar limpieza",
        "confirm_body": (
            "Los archivos elegibles se enviarán a la Papelera de reciclaje, "
            "no se borrarán permanentemente. Antes de cada movimiento se vuelve "
            "a comprobar la ruta, la antigüedad y la política de seguridad. "
            "Los archivos que hayan cambiado o no superen las comprobaciones "
            "se omitirán. La recuperación no está garantizada en todos los "
            "volúmenes o entornos. ¿Continuar?"
        ),
        "confirm_summary": (
            "Categorías:\n{categories}\nArchivos elegibles: {files}\n"
            "Espacio estimado: {value:.2f} GB\nSelecciones rechazadas: "
            "{rejected}\nAntigüedad mínima: {days} días"
        ),
        "cancel": "CANCELAR",
        "continue": "CONTINUAR",
        "cleaning": "ENVIANDO A LA PAPELERA...",
        "cleanup_done": "Limpieza completada",
        "cleanup_result": (
            "Enviados a la Papelera: {moved}\nEspacio estimado movido: "
            "{value:.2f} GB\nOmitidos por seguridad o selección no válida: "
            "{skipped}\nOmitidos porque cambiaron: {changed}\n"
            "Fallos de envío/verificación: {failed}\nLa recuperación no está "
            "garantizada en todos los volúmenes o entornos."
        ),
        "ok": "ACEPTAR",
        "preview_category": "{category}: {files} archivos, {value:.1f} MB",
        "selection_stale": "Ningún elemento seleccionado sigue autorizado por el último análisis. Vuelve a analizar los archivos.",
        "selection_empty": "No has seleccionado ningún archivo.",
        "error": "Error",
        "operation_failed": "La operación no pudo completarse.",
        "system_scan_title": "Protección de recursos Windows",
        "system_scan_result": "Árboles comprobados: {roots}\nArchivos inspeccionados: {files}\nRecursos protegidos: {protected}\nArchivos dentro de Windows: {managed}\nElementos inaccesibles: {inaccessible}",
        "protected_notice": "Los recursos protegidos por Windows no forman parte de la selección de limpieza. El motor aplica protección por rutas y, cuando está disponible, consulta Windows Resource Protection (SfcIsFileProtected).",
        "system_protection_body": (
            "Revisa los recursos de Windows detectados por el análisis. El resultado "
            "describe las ubicaciones que se pudieron inspeccionar y no garantiza "
            "un inventario completo del sistema."
        ),
        "system_protection_limit": (
            "La protección combina reglas conservadoras de rutas y comprobaciones "
            "disponibles de Windows. Los elementos inaccesibles o sin confirmar "
            "requieren revisión; esta pantalla no modifica archivos."
        ),
        "status_legend_title": "CÓMO LEER LOS RESULTADOS",
        "candidate_explanation": (
            "Candidato: cumple los filtros actuales; se vuelve a verificar antes "
            "de cualquier acción."
        ),
        "protected_explanation": "Protegido: las reglas bloquean su limpieza.",
        "review_explanation": "Revisar: no se autoriza la limpieza automática.",
        "navigation_description": "Abrir la página: {page}",
        "scan_button_description": "Consultar métricas reales del equipo en modo de solo lectura.",
        "cleanup_button_description": (
            "Enviar a la Papelera solo archivos seleccionados y revalidados "
            "después de confirmar."
        ),
        "protection_button_description": "Analizar los recursos de Windows sin modificarlos.",
        "cleanup_table_description": (
            "Lista de candidatos del análisis. Las rutas completas no se muestran "
            "aquí; la columna Motivo explica por qué se incluyó cada elemento."
        ),
        "startup_table_description": (
            "Entradas de inicio detectadas. Esta tabla es de solo lectura."
        ),
        "process_table_description": (
            "Procesos y métricas disponibles. Zentry no finaliza procesos desde "
            "esta pantalla."
        ),
        "history_table_description": (
            "Historial agregado local. No contiene rutas completas ni nombres de "
            "archivos personales."
        ),
        "history_clear_button_description": (
            "Borrar únicamente el historial agregado local. Los registros técnicos "
            "se conservan."
        ),
        "health_heuristic_help": (
            "La puntuación es una heurística orientativa basada en umbrales de "
            "métricas; no es una medida científica ni una garantía de salud del equipo."
        ),
        "status_scanning": "Analizando: {value}",
        "candidate_badge": "CANDIDATO",
        "protected_badge": "BLOQUEADO",
        "review_badge": "REVISAR",
        "processes_count": "Procesos",
        "loading_diagnostics": "Consultando las métricas del equipo...",
        "loading_protection": "Comprobando la protección de Windows...",
        "loading_cleanup": "Analizando archivos en ubicaciones aprobadas...",
        "loading_cleanup_preview": "Preparando la vista previa de la limpieza...",
        "operation_already_running": "Ya hay una operación de este tipo en curso.",
        "worker_close_title": "Operación en curso",
        "worker_close_body": (
            "Zentry está trabajando. Espera a que termine antes de cerrar la aplicación; "
            "esta operación no se puede cancelar de forma segura."
        ),
        "loading_startup": "Leyendo las entradas de inicio...",
        "loading_processes": "Consultando los procesos...",
        "empty_startup": "No se detectaron entradas de inicio.",
        "empty_processes": "No hay procesos disponibles para mostrar.",
        "empty_history": "Todavía no hay operaciones registradas.",
        "empty_cleanup_results": "No hay candidatos para mostrar.",
        "cleanup_status_initial": "Analiza las ubicaciones aprobadas para ver los resultados.",
        "protection_initial": "Ejecuta el análisis para consultar los recursos protegidos de Windows.",
        "cleanup_status_summary": "{scanned} archivos analizados · {protected} protegidos · {review} para revisar · {inaccessible} inaccesibles",
        "date_time_format": "%d/%m/%Y %H:%M",
        "date_time_seconds_format": "%d/%m/%Y %H:%M:%S",
        "language_tooltip": "Cambiar el idioma de la interfaz",
        "select_file": "Seleccionar archivo {name}",
        "delete": "BORRAR",
        "category_user_temp": "Temporales del usuario",
        "category_windows_temp": "Temporales de Windows",
        "category_chrome_cache": "Caché de Chrome",
        "category_edge_cache": "Caché de Edge",
        "category_firefox_cache": "Caché de Firefox",
        "category_unknown": "Categoría desconocida",
        "process_status_running": "En ejecución",
        "process_status_sleeping": "En espera",
        "process_status_stopped": "Detenido",
        "process_status_zombie": "Zombi",
        "process_status_dead": "Finalizado",
        "process_status_idle": "Inactivo",
        "process_status_waiting": "Esperando",
        "process_status_unknown": "Desconocido",
        "loading_scan": "Escaneando el sistema...",
        "select_to_preview": "Selecciona archivos para ver el total.",
        "empty_table": "Analiza para mostrar resultados.",

    },
    "en": {
        "brand_title": "ZENTRY",
        "brand_subtitle": "DIAGNOSTICS AND SAFE CLEANUP",
        "overview": "Overview",
        "diagnostics": "Diagnostics",
        "cleanup": "Safe cleanup",
        "cleanup_nav": "Cleanup",
        "startup": "Windows startup",
        "startup_nav": "Startup",
        "processes": "Processes",
        "history": "History",
        "safe_mode": "YOUR PC, AT ITS BEST",
        "system_protection": "Windows protection",
        "system_protection_nav": "System protection",
        "pages_accessible_name": "Zentry pages",
        "page_overview": "ZENTRY  /  PC STATUS",
        "title_overview": "PC status",
        "overview_subtitle": "Performance and maintenance overview",
        "safety_badge": "🛡️ Safe mode",
        "safety_badge_tooltip": "Diagnostics do not modify your PC. Cleanup requires preview and confirmation, and moves files to the Recycle Bin.",
        "safe_cleanup_title": "Safe cleanup",
        "safe_cleanup_desc": "Review candidates before confirming. Nothing is removed without your approval.",
        "safe_cleanup_button": "Preview cleanup  →",
        "scan": "SCAN SYSTEM  →",
        "scanning": "SCANNING...  ◌",
        "complete": "SCAN COMPLETE  ✓",
        "notice": "Cleanup is reversible: you see a preview first, and files are moved to the Recycle Bin only after confirmation.",
        "dashboard_waiting": "Ready to analyze your PC",
        "dashboard_healthy": "Measured indicators are within general ranges",
        "dashboard_moderate": "Some indicators are worth reviewing",
        "dashboard_elevated": "Reviewing system status is recommended",
        "dashboard_detail_waiting": "Run an analysis to show real measurements from this PC.",
        "dashboard_detail_ready": "The score is an estimate; review the metrics before deciding what to do.",
        "disk_usage": "Free space on the main drive",
        "activity_title": "System activity",
        "activity_cpu": "CPU",
        "activity_memory": "RAM",
        "activity_waiting": "Collecting real activity samples...",
        "progress_files": "Files reviewed: {count}",
        "cpu": "CPU",
        "memory": "MEMORY",
        "storage": "STORAGE",
        "startup_metric": "STARTUP",
        "waiting": "Waiting for scan",
        "current_cpu": "Current processor utilization",
        "current_memory": "Current memory utilization",
        "available": "{value:.1f} GB available",
        "estimated": "Estimated high impact: {value}",
        "health": "SYSTEM HEALTH",
        "run_scan": "Run a scan to calculate a baseline.",
        "healthy": "Baseline looks healthy. Diagnose specific bottlenecks before making changes.",
        "moderate": "Moderate pressure detected. Review the metrics before deciding on an action.",
        "elevated": "Elevated pressure detected. Diagnosis should come before optimization.",
        "recommendations": "RECOMMENDED ACTIONS",
        "cleanup_action": "Analyze stale files",
        "cleanup_desc": "Searches known disposable cache/temp locations for files with at least one month without access or modification.",
        "system_action": "Analyze protected Windows files",
        "system_desc": "Checks protected system trees and classifies resources that the cleaner must block.",
        "low_risk": "LOW RISK",
        "workflow": "ZENTRY · REAL DATA · CONFIRMATION BEFORE CLEANUP",
        "refresh": "REFRESH",
        "no_data": "No data yet.",
        "diagnostics_body": "Real Windows metrics collected in read-only mode.",
        "processes_body": "Real-time process inspection. Process termination is not enabled.",
        "startup_body": "Startup entries detected in the registry. This view is read-only.",
        "cleanup_body": "Only files in known disposable locations with a configurable minimum age are shown as removable. Protected or ambiguous resources are blocked or excluded.",
        "history_body": "Local history of aggregate summaries. Full paths, file names and process details are not stored.",
        "history_operation": "Operation",
        "history_result": "Result",
        "history_files": "Count",
        "history_estimated_bytes": "Estimated bytes",
        "history_moved_bytes": "Bytes sent",
        "history_omissions": "Skipped / failed",
        "history_op_system_diagnostics": "System diagnostics",
        "history_op_stale_scan": "Stale-file scan",
        "history_op_system_protection_scan": "Protection scan",
        "history_op_cleanup": "Cleanup",
        "history_op_application_error": "Operation error",
        "history_op_legacy_aggregate": "Previous history (aggregate)",
        "history_result_success": "Success",
        "history_result_partial": "Partial",
        "history_result_failed": "Failed",
        "history_result_no_candidates": "No candidates",
        "history_result_skipped": "Skipped",
        "history_result_cancelled": "Cancelled",
        "history_result_incomplete": "Incomplete",
        "history_na": "N/A",
        "history_count_pair": "{skipped} skipped / {failed} failed",
        "history_clear": "CLEAR HISTORY",
        "history_clear_confirm_title": "Clear local history",
        "history_clear_confirm": "Only the history.json file will be deleted. Logs will not be deleted. Continue?",
        "history_clear_done": "Local history was deleted.",
        "history_clear_missing": "There was no history file to delete.",
        "history_clear_failed": "History could not be deleted. Check permissions on the Zentry data directory.",
        "scan_cleanup": "ANALYZE STALE FILES",
        "scan_protection": "ANALYZE WINDOWS PROTECTION",
        "age_label": "MINIMUM AGE",
        "days": "days",
        "select_all": "SELECT ALL",
        "clear_selection": "CLEAR SELECTION",
        "delete_selected": "SEND SELECTED TO RECYCLE BIN",
        "no_candidates": "No safe candidates were found with these criteria.",
        "reclaimable": "Potentially reclaimable: {value:.2f} GB",
        "selected": "Selected: {files} files · {value:.2f} GB",
        "files": "files",
        "process_name": "Process",
        "pid": "PID",
        "cpu_header": "CPU %",
        "ram": "RAM %",
        "status": "Status",
        "startup_name": "Name",
        "source": "Source",
        "command": "Command",
        "time": "Time",
        "health_score": "Health",
        "disk": "Disk %",
        "reclaim": "Reclaimable",
        "category": "Category",
        "file_name": "File",
        "size": "Size",
        "path": "Path",
        "last_access": "Last access",
        "last_modified": "Last modified",
        "reason": "Reason",
        "classification": "Classification",
        "language": "EN  ⌄",
        "version": "ZENTRY 0.4.9  ·  WINDOWS",
        "confirm_title": "Confirm cleanup",
        "confirm_body": (
            "Eligible files will be sent to the Recycle Bin, not permanently "
            "deleted. Each file is revalidated for path, age and safety immediately "
            "before the move. Changed or unverified files are skipped. Recovery "
            "is not guaranteed on every volume or environment. Continue?"
        ),
        "confirm_summary": (
            "Categories:\n{categories}\nEligible files: {files}\n"
            "Estimated space: {value:.2f} GB\nRejected selections: {rejected}\n"
            "Minimum age: {days} days"
        ),
        "cancel": "CANCEL",
        "continue": "CONTINUE",
        "cleaning": "SENDING TO RECYCLE BIN...",
        "cleanup_done": "Cleanup complete",
        "cleanup_result": (
            "Sent to Recycle Bin: {moved}\nEstimated space moved: {value:.2f} GB\n"
            "Skipped by safety or invalid selection: {skipped}\n"
            "Skipped because changed: {changed}\nMove/verification failures: "
            "{failed}\nRecovery is not guaranteed on every volume or environment."
        ),
        "ok": "OK",
        "preview_category": "{category}: {files} files, {value:.1f} MB",
        "selection_stale": "None of the selected items is authorized by the latest scan. Analyze files again.",
        "selection_empty": "No files are selected.",
        "error": "Error",
        "operation_failed": "The operation could not be completed.",
        "system_scan_title": "Windows resource protection",
        "system_scan_result": "Trees checked: {roots}\nFiles inspected: {files}\nProtected resources: {protected}\nFiles inside Windows: {managed}\nInaccessible items: {inaccessible}",
        "protected_notice": "Windows-protected resources are never part of the cleanup selection. The engine uses protected-path rules and, when available, checks Windows Resource Protection (SfcIsFileProtected).",
        "system_protection_body": (
            "Review the Windows resources detected by the scan. Results describe "
            "the locations that could be inspected and do not guarantee a complete "
            "inventory of the system."
        ),
        "system_protection_limit": (
            "Protection combines conservative path rules with available Windows "
            "checks. Inaccessible or unverified items require review; this page "
            "does not modify files."
        ),
        "status_legend_title": "HOW TO READ RESULTS",
        "candidate_explanation": (
            "Candidate: matches the current filters; it is checked again before "
            "any action."
        ),
        "protected_explanation": "Protected: cleanup is blocked by policy.",
        "review_explanation": "Review: automatic cleanup is not authorized.",
        "navigation_description": "Open page: {page}",
        "scan_button_description": "Read real system metrics without modifying the computer.",
        "cleanup_button_description": (
            "Send only selected, revalidated files to the Recycle Bin after "
            "confirmation."
        ),
        "protection_button_description": "Inspect Windows resources without modifying them.",
        "cleanup_table_description": (
            "List of scan candidates. Full paths are not displayed here; the "
            "Reason column explains why each item was included."
        ),
        "startup_table_description": "Detected startup entries. This table is read-only.",
        "process_table_description": (
            "Processes and available metrics. Zentry does not terminate processes "
            "from this page."
        ),
        "history_table_description": (
            "Local aggregate history. It does not contain full paths or personal "
            "file names."
        ),
        "history_clear_button_description": (
            "Clear only the local aggregate history. Technical logs are retained."
        ),
        "health_heuristic_help": (
            "This score is an indicative heuristic based on metric thresholds; it "
            "is not a scientific measure or a guarantee of system health."
        ),
        "status_scanning": "Analyzing: {value}",
        "candidate_badge": "CANDIDATE",
        "protected_badge": "BLOCKED",
        "review_badge": "REVIEW",
        "processes_count": "Processes",
        "loading_diagnostics": "Collecting system metrics...",
        "loading_protection": "Checking Windows protection...",
        "loading_cleanup": "Analyzing files in approved locations...",
        "loading_cleanup_preview": "Preparing the cleanup preview...",
        "operation_already_running": "An operation of this type is already running.",
        "worker_close_title": "Operation in progress",
        "worker_close_body": (
            "Zentry is working. Wait for it to finish before closing the application; "
            "this operation cannot be cancelled safely."
        ),
        "loading_startup": "Reading startup entries...",
        "loading_processes": "Collecting process information...",
        "empty_startup": "No startup entries were found.",
        "empty_processes": "No processes are available to display.",
        "empty_history": "No operations have been recorded yet.",
        "empty_cleanup_results": "There are no candidates to display.",
        "cleanup_status_initial": "Analyze approved locations to see the results.",
        "protection_initial": "Run the analysis to inspect Windows-protected resources.",
        "cleanup_status_summary": "{scanned} files scanned · {protected} protected · {review} for review · {inaccessible} inaccessible",
        "date_time_format": "%Y-%m-%d %H:%M",
        "date_time_seconds_format": "%Y-%m-%d %H:%M:%S",
        "language_tooltip": "Change the interface language",
        "select_file": "Select file {name}",
        "delete": "DELETE",
        "category_user_temp": "User temporary files",
        "category_windows_temp": "Windows temporary files",
        "category_chrome_cache": "Chrome cache",
        "category_edge_cache": "Edge cache",
        "category_firefox_cache": "Firefox cache",
        "category_unknown": "Unknown category",
        "process_status_running": "Running",
        "process_status_sleeping": "Sleeping",
        "process_status_stopped": "Stopped",
        "process_status_zombie": "Zombie",
        "process_status_dead": "Exited",
        "process_status_idle": "Idle",
        "process_status_waiting": "Waiting",
        "process_status_unknown": "Unknown",
        "loading_scan": "Scanning the system...",
        "select_to_preview": "Select files to view the selected total.",
        "empty_table": "Run an analysis to show results.",

    },
}


def validate_translation_catalog(
    translations: Mapping[str, Mapping[str, str]] = TRANSLATIONS,
) -> None:
    """Validate locale parity and format placeholders before building the UI."""
    required_languages = {"es", "en"}
    if set(translations) != required_languages:
        raise ValueError("Translation catalog must contain exactly 'es' and 'en'")

    spanish_keys = set(translations["es"])
    english_keys = set(translations["en"])
    if spanish_keys != english_keys:
        missing_in_english = sorted(spanish_keys - english_keys)
        missing_in_spanish = sorted(english_keys - spanish_keys)
        raise ValueError(
            "Translation keys differ between locales: "
            f"missing_en={missing_in_english}, missing_es={missing_in_spanish}"
        )

    formatter = Formatter()
    for key in sorted(spanish_keys):
        spanish = translations["es"][key]
        english = translations["en"][key]
        if not isinstance(spanish, str) or not spanish.strip():
            raise ValueError(f"Spanish translation {key!r} must be a non-empty string")
        if not isinstance(english, str) or not english.strip():
            raise ValueError(f"English translation {key!r} must be a non-empty string")
        try:
            spanish_fields = {
                field_name.split(".")[0].split("[")[0]
                for _, field_name, _, _ in formatter.parse(spanish)
                if field_name is not None
            }
            english_fields = {
                field_name.split(".")[0].split("[")[0]
                for _, field_name, _, _ in formatter.parse(english)
                if field_name is not None
            }
        except ValueError as exc:
            raise ValueError(f"Invalid format string for translation {key!r}") from exc
        if spanish_fields != english_fields:
            raise ValueError(
                f"Format placeholders differ for translation {key!r}: "
                f"es={sorted(spanish_fields)}, en={sorted(english_fields)}"
            )


validate_translation_catalog()


class Worker(QThread):
    """Run one provider/service operation outside the GUI thread.

    Signals carry the worker object so MainWindow can identify the operation
    without using lambdas as cross-thread Qt receivers.
    """

    finished_data = Signal(object, object)
    progress = Signal(object, str)
    failed = Signal(object, str)

    def __init__(
        self,
        task_key: str,
        func: Callable[[Callable[[str], None]], object],
    ) -> None:
        super().__init__()
        self.task_key = task_key
        self._func = func

    def run(self) -> None:
        try:
            result = self._func(
                lambda message: self.progress.emit(self, message)
            )
            self.finished_data.emit(self, result)
        except Exception as exc:  # noqa: BLE001
            log_safe_exception(LOGGER, f"worker_{self.task_key}_failed", exc)
            self.failed.emit(self, "worker_operation_failed")


class GaugeRing(QWidget):
    """Compact circular gauge rendered from the latest measured percentage."""

    def __init__(self, accent: str) -> None:
        super().__init__()
        self._value: float | None = None
        self._accent = QColor(accent)
        self.setFixedSize(82, 82)
        self.setAccessibleName("Metric gauge")

    def set_value_text(self, value: str) -> None:
        try:
            parsed = float(value.strip().removesuffix("%"))
            self._value = parsed if 0.0 <= parsed <= 100.0 else None
        except (TypeError, ValueError):
            self._value = None
        self.setAccessibleDescription(
            f"Measured value: {value}"
            if self._value is not None else "No measurement available"
        )
        self.update()

    def paintEvent(self, _event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(9, 9, -9, -9)
        painter.setPen(QPen(
            QColor("#203c59"), 8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap
        ))
        painter.drawArc(rect, 0, 360 * 16)
        if self._value is not None:
            painter.setPen(QPen(
                self._accent, 8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap
            ))
            painter.drawArc(rect, 90 * 16, -int(360 * 16 * self._value / 100.0))
        painter.setPen(QColor("#eaf3ff"))
        font = painter.font()
        font.setFamily("Segoe UI")
        font.setPointSize(13)
        font.setBold(True)
        painter.setFont(font)
        label = f"{self._value:.0f}%" if self._value is not None else "—"
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, label)


class MetricCard(QFrame):
    def __init__(
        self, name: str, value: str, detail: str, *, icon: str, accent: str
    ) -> None:
        super().__init__()
        self.setObjectName("metricCard")
        self.setMinimumHeight(164)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 13, 16, 14)
        outer.setSpacing(12)
        title_row = QHBoxLayout()
        title_row.setSpacing(10)
        self._icon = QLabel(icon)
        self._icon.setObjectName("metricIcon")
        self._icon.setStyleSheet(
            f"color: {accent}; font-size: 21px; font-weight: 800;"
        )
        self._title = QLabel(name)
        self._title.setObjectName("metricTitle")
        self._title.setWordWrap(True)
        title_row.addWidget(self._icon)
        title_row.addWidget(self._title, 1)
        outer.addLayout(title_row)

        body = QHBoxLayout()
        body.setSpacing(12)
        self._gauge = GaugeRing(accent)
        body.addWidget(self._gauge, 0, Qt.AlignmentFlag.AlignVCenter)
        value_box = QVBoxLayout()
        value_box.setSpacing(4)
        self._value = QLabel(value)
        self._value.setObjectName("metricValue")
        self._value.setWordWrap(True)
        self._detail = QLabel(detail)
        self._detail.setObjectName("metricDetail")
        self._detail.setWordWrap(True)
        value_box.addWidget(self._value)
        value_box.addWidget(self._detail)
        value_box.addStretch(1)
        body.addLayout(value_box, 1)
        outer.addLayout(body, 1)

    def update_text(
        self, title: str, value: str, detail: str, *, headline: str | None = None
    ) -> None:
        self._title.setText(title.upper())
        self._value.setText(headline if headline is not None else value)
        self._detail.setText(detail)
        self._gauge.set_value_text(value)


class ActivityGraph(QWidget):
    """Small live graph using actual CPU/RAM samples supplied by the provider."""

    def __init__(self, waiting_text: str) -> None:
        super().__init__()
        self._samples: list[tuple[float, float]] = []
        self._waiting_text = waiting_text
        self.setMinimumHeight(165)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAccessibleName("System activity graph")
        self.setAccessibleDescription(
            "Live CPU and RAM percentage samples from this computer"
        )

    def set_waiting_text(self, text: str) -> None:
        self._waiting_text = text
        self.update()

    def add_sample(self, cpu: float, memory: float) -> None:
        if not (0.0 <= cpu <= 100.0 and 0.0 <= memory <= 100.0):
            return
        self._samples.append((float(cpu), float(memory)))
        self._samples = self._samples[-60:]
        self.update()

    def paintEvent(self, _event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        plot = self.rect().adjusted(42, 12, -12, -25)
        if plot.width() <= 10 or plot.height() <= 10:
            return
        for step in range(5):
            value = 100 - step * 25
            y = plot.top() + plot.height() * step / 4
            painter.setPen(QPen(QColor("#1b334e"), 1, Qt.PenStyle.SolidLine))
            painter.drawLine(int(plot.left()), int(y), int(plot.right()), int(y))
            painter.setPen(QColor("#7e9fc7"))
            painter.drawText(
                0, int(y - 7), 34, 16, Qt.AlignmentFlag.AlignRight, f"{value}%"
            )
        for step in range(1, 5):
            x = plot.left() + plot.width() * step / 5
            painter.setPen(QPen(QColor("#142b45"), 1, Qt.PenStyle.SolidLine))
            painter.drawLine(int(x), int(plot.top()), int(x), int(plot.bottom()))

        if len(self._samples) < 2:
            painter.setPen(QColor("#8caed7"))
            painter.drawText(
                plot,
                int(Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap),
                self._waiting_text,
            )
            return

        def make_path(index: int) -> QPainterPath:
            path = QPainterPath()
            denominator = max(1, len(self._samples) - 1)
            for sample_index, sample in enumerate(self._samples):
                x = plot.left() + plot.width() * sample_index / denominator
                y = plot.bottom() - plot.height() * sample[index] / 100.0
                if sample_index == 0:
                    path.moveTo(x, y)
                else:
                    path.lineTo(x, y)
            return path

        painter.setPen(QPen(
            QColor("#16d8f4"), 2.5, Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin
        ))
        painter.drawPath(make_path(0))
        painter.setPen(QPen(
            QColor("#9a67ff"), 2.5, Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin
        ))
        painter.drawPath(make_path(1))
        painter.setPen(QColor("#7e9fc7"))
        painter.drawText(int(plot.left()), self.height() - 5, "−2 min")
        painter.drawText(int(plot.right() - 40), self.height() - 5, "Ahora")

class MainWindow(QMainWindow):
    def __init__(self, provider: SystemDiagnosticsProvider) -> None:
        super().__init__()
        self._provider = provider
        self._language = "es"
        self._pages = QStackedWidget()
        self._metrics: dict[str, MetricCard] = {}
        self._last_snapshot: SystemSnapshot | None = None
        # Used by _render_snapshot(), which is called during _retranslate_ui().
        # Initialize it before _build_ui() and the first translation pass.
        self._latest_activity: tuple[float | None, float | None] | None = None
        self._last_diagnostic_snapshot: SystemSnapshot | None = None
        self._last_protection_summary: SystemProtectionSummary | None = None
        self._last_cleanup_summary: CleanupScanSummary | None = None
        self._startup_entries: list[StartupEntry] = []
        self._process_entries: list[ProcessInfo] = []
        self._startup_loaded = False
        self._processes_loaded = False
        self._startup_loading = False
        self._processes_loading = False
        self._cleanup_previewing = False
        self._scan_state = "idle"
        self._diagnostics_loading = False
        self._protection_loading = False
        self._cleanup_loading = False
        self._cleanup_running = False
        self._workers: list[Worker] = []
        self._active_tasks: dict[str, Worker] = {}
        self._worker_callbacks: dict[int, Callable[[object], None]] = {}
        self._finished_workers: set[int] = set()
        self._language_button: QPushButton | None = None
        self._history: list[HistoryEvent] = []
        self._history_store = HistoryStore(get_app_data_directory() / "history.json")
        self._pending_cleanup_estimated_bytes: int | None = None
        self._pending_cleanup_candidates: tuple[FileCandidate, ...] = ()
        self._cleanup_stage = "idle"
        self._cleanup_candidates: list[FileCandidate] = []
        self._discarded_candidate_count = 0
        self._cleanup_checkboxes: list[QCheckBox] = []
        self._current_age_days = 31
        self._build_ui()
        self._load_history()
        self._retranslate_ui()
        self._activity_timer = QTimer(self)
        self._activity_timer.setInterval(2000)
        self._activity_cpu_warmed = False
        self._activity_timer.timeout.connect(self._sample_activity)
        self._activity_timer.start()

    def _build_ui(self) -> None:
        self.setWindowTitle("Zentry")
        self.setMinimumSize(1080, 700)
        self.resize(1440, 900)
        central = QWidget()
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._build_sidebar())

        # Persistent top bar: language + the actual safety behavior of cleanup.
        content = QFrame()
        content.setObjectName("mainContent")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        topbar = QFrame()
        topbar.setObjectName("topbar")
        topbar.setMinimumHeight(58)
        topbar_layout = QHBoxLayout(topbar)
        topbar_layout.setContentsMargins(24, 8, 26, 8)
        topbar_layout.setSpacing(12)
        topbar_layout.addStretch(1)
        self._language_button = QPushButton()
        self._language_button.setObjectName("languageButton")
        self._language_button.setToolTip(self._t("language_tooltip"))
        self._language_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._language_button.clicked.connect(self._toggle_language)
        self._read_only_badge = QLabel()
        self._read_only_badge.setObjectName("safetyBadge")
        self._read_only_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._read_only_badge.setToolTip(self._t("safety_badge_tooltip"))
        self._read_only_badge.setAccessibleName(self._t("safety_badge"))
        self._read_only_badge.setAccessibleDescription(self._t("safety_badge_tooltip"))
        topbar_layout.addWidget(self._language_button)
        topbar_layout.addWidget(self._read_only_badge)
        content_layout.addWidget(topbar)
        content_layout.addWidget(self._build_pages(), 1)
        layout.addWidget(content, 1)
        self.setCentralWidget(central)

    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(270)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 24, 18, 20)
        layout.setSpacing(8)

        brand_row = QHBoxLayout()
        brand_row.setSpacing(12)
        self._brand_mark = QLabel("Z")
        self._brand_mark.setObjectName("brandMark")
        self._brand_mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._brand_mark.setFixedSize(48, 48)
        self._brand_mark.setAccessibleName("Zentry logo mark")
        self._brand = QLabel()
        self._brand.setObjectName("brand")
        self._brand.setAccessibleName("Zentry")
        self._brand_subtitle = QLabel()
        self._brand_subtitle.setObjectName("brandSubtitle")
        self._brand_subtitle.setWordWrap(True)
        brand_row.addWidget(self._brand_mark)
        brand_row.addWidget(self._brand, 1)
        layout.addLayout(brand_row)
        layout.addWidget(self._brand_subtitle)
        layout.addSpacing(26)

        self._nav_buttons: list[QPushButton] = []
        navigation_keys = (
            "overview", "diagnostics", "cleanup_nav", "startup_nav", "processes",
            "history", "system_protection_nav",
        )
        navigation_icons = ("⌂", "∿", "✧", "◴", "▦", "◷", "⬡")
        for index, icon in enumerate(navigation_icons):
            button = QPushButton(f"{icon}   {self._t(navigation_keys[index])}")
            button.setObjectName("navSelected" if index == 0 else "navButton")
            button.setCheckable(True)
            button.setChecked(index == 0)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setMinimumHeight(48)
            button.setAccessibleName(self._t(navigation_keys[index]))
            button.setAccessibleDescription(
                self._t("navigation_description", page=self._t(navigation_keys[index]))
            )
            button.clicked.connect(self._make_nav_handler(index))
            self._nav_buttons.append(button)
            layout.addWidget(button)
        layout.addStretch(1)

        self._safe_status = QLabel()
        self._safe_status.setObjectName("safeStatus")
        self._safe_status.setWordWrap(True)
        layout.addWidget(self._safe_status)
        self._version = QLabel()
        self._version.setObjectName("version")
        layout.addWidget(self._version)
        return sidebar

    def _make_nav_handler(self, index: int) -> Callable[[], None]:
        def handler() -> None:
            self._navigate_to(index)

        return handler

    def _navigate_to(self, index: int) -> None:
        """Navigate to a page and trigger its existing read-only refresh."""
        if not 0 <= index < self._pages.count():
            return
        self._pages.setCurrentIndex(index)
        for current_index, button in enumerate(self._nav_buttons):
            selected = current_index == index
            button.setChecked(selected)
            button.setObjectName("navSelected" if selected else "navButton")
            button.style().unpolish(button)
            button.style().polish(button)
        if index == 1:
            self._run_diagnostics()
        elif index == 2:
            self._ensure_cleanup_defaults()
        elif index == 3:
            self._load_startup()
        elif index == 4:
            self._load_processes()
        elif index == 5:
            self._refresh_history()
        elif index == 6 and not self._protection_loading:
            self._scan_protection()

    def _build_pages(self) -> QStackedWidget:
        self._pages.addWidget(self._build_overview())
        self._pages.addWidget(self._build_diagnostics_page())
        self._pages.addWidget(self._build_cleanup_page())
        self._pages.addWidget(self._build_startup_page())
        self._pages.addWidget(self._build_processes_page())
        self._pages.addWidget(self._build_history_page())
        self._pages.addWidget(self._build_protection_page())
        self._pages.setAccessibleName(self._t("pages_accessible_name"))
        return self._pages

    def _build_overview(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 20, 28, 22)
        layout.setSpacing(14)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title_box.setSpacing(3)
        self._overview_eyebrow = QLabel()
        self._overview_eyebrow.setObjectName("eyebrow")
        self._overview_title = QLabel()
        self._overview_title.setObjectName("pageTitle")
        self._overview_subtitle = QLabel()
        self._overview_subtitle.setObjectName("pageSubtitle")
        title_box.addWidget(self._overview_eyebrow)
        title_box.addWidget(self._overview_title)
        title_box.addWidget(self._overview_subtitle)
        self._scan_button = QPushButton()
        self._scan_button.setObjectName("scanButton")
        self._scan_button.setMinimumSize(172, 44)
        self._scan_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._scan_button.setAccessibleName(self._t("scan"))
        self._scan_button.setAccessibleDescription(self._t("scan_button_description"))
        self._scan_button.clicked.connect(self._start_scan)
        header.addLayout(title_box, 1)
        header.addWidget(self._scan_button, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addLayout(header)

        # This status banner is updated from real snapshots; it never contains
        # fabricated hardware values and explains the reversible cleanup flow.
        self._notice = QLabel()
        self._notice.setObjectName("notice")
        self._notice.setWordWrap(True)
        self._notice.setMinimumHeight(74)
        self._notice.setTextFormat(Qt.TextFormat.RichText)
        self._notice.setAccessibleName(self._t("health"))
        self._notice.setAccessibleDescription(self._t("notice"))
        layout.addWidget(self._notice)

        metrics = QHBoxLayout()
        metrics.setSpacing(14)
        self._metrics["cpu"] = MetricCard(
            self._t("cpu"), "—", self._t("waiting"), icon="⌘", accent="#16d8f4"
        )
        self._metrics["memory"] = MetricCard(
            self._t("memory"), "—", self._t("waiting"), icon="▦", accent="#9a67ff"
        )
        self._metrics["storage"] = MetricCard(
            self._t("storage"), "—", self._t("waiting"), icon="▰", accent="#16d8f4"
        )
        for card in self._metrics.values():
            metrics.addWidget(card, 1)
        layout.addLayout(metrics)

        lower = QHBoxLayout()
        lower.setSpacing(14)
        activity = QFrame()
        activity.setObjectName("contentCard")
        activity_layout = QVBoxLayout(activity)
        activity_layout.setContentsMargins(18, 14, 18, 12)
        activity_layout.setSpacing(8)
        activity_header = QHBoxLayout()
        activity_symbol = QLabel("⌁")
        activity_symbol.setObjectName("metricIcon")
        activity_title = QLabel()
        activity_title.setObjectName("contentHeading")
        self._activity_title = activity_title
        activity_header.addWidget(activity_symbol)
        activity_header.addWidget(activity_title)
        activity_header.addStretch(1)
        self._cpu_legend = QLabel(f"●  {self._t('activity_cpu')}")
        self._cpu_legend.setStyleSheet("color: #16d8f4; font-weight: 700;")
        self._memory_legend = QLabel(f"●  {self._t('activity_memory')}")
        self._memory_legend.setStyleSheet("color: #b08aff; font-weight: 700;")
        activity_header.addWidget(self._cpu_legend)
        activity_header.addSpacing(8)
        activity_header.addWidget(self._memory_legend)
        activity_layout.addLayout(activity_header)
        self._activity_graph = ActivityGraph(self._t("activity_waiting"))
        activity_layout.addWidget(self._activity_graph, 1)
        lower.addWidget(activity, 6)

        recommendations = QFrame()
        recommendations.setObjectName("recommendationPanel")
        rec_layout = QVBoxLayout(recommendations)
        rec_layout.setContentsMargins(15, 13, 15, 13)
        rec_layout.setSpacing(10)
        self._rec_label = QLabel()
        self._rec_label.setObjectName("contentHeading")
        rec_layout.addWidget(self._rec_label)
        rec_layout.addWidget(self._make_action_card("cleanup_action", "cleanup_desc", 2))
        rec_layout.addWidget(self._make_action_card("system_action", "system_desc", 6))
        lower.addWidget(recommendations, 5)
        layout.addLayout(lower, 1)

        cleanup_feature = QFrame()
        cleanup_feature.setObjectName("cleanupFeatureCard")
        cleanup_feature_layout = QHBoxLayout(cleanup_feature)
        cleanup_feature_layout.setContentsMargins(18, 14, 18, 14)
        cleanup_feature_layout.setSpacing(14)
        feature_mark = QLabel("✧")
        feature_mark.setObjectName("featureMark")
        feature_mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        feature_mark.setFixedWidth(42)
        feature_text = QVBoxLayout()
        self._safe_cleanup_title = QLabel()
        self._safe_cleanup_title.setObjectName("actionTitle")
        self._safe_cleanup_desc = QLabel()
        self._safe_cleanup_desc.setObjectName("actionDescription")
        self._safe_cleanup_desc.setWordWrap(True)
        feature_text.addWidget(self._safe_cleanup_title)
        feature_text.addWidget(self._safe_cleanup_desc)
        self._safe_cleanup_button = QPushButton()
        self._safe_cleanup_button.setObjectName("outlinedCyanButton")
        self._safe_cleanup_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._safe_cleanup_button.clicked.connect(lambda _checked=False: self._navigate_to(2))
        cleanup_feature_layout.addWidget(feature_mark)
        cleanup_feature_layout.addLayout(feature_text, 1)
        cleanup_feature_layout.addWidget(self._safe_cleanup_button)
        layout.addWidget(cleanup_feature)

        self._workflow_label = QLabel()
        self._workflow_label.setObjectName("workflow")
        self._workflow_label.setVisible(False)
        return page
    def _make_action_card(self, title_key: str, desc_key: str, target_index: int) -> QFrame:
        frame = QFrame()
        frame.setObjectName("actionCard")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 14, 18, 14)
        row = QHBoxLayout()
        text = QVBoxLayout()
        title = QLabel()
        title.setObjectName("actionTitle")
        desc = QLabel()
        desc.setObjectName("actionDescription")
        desc.setWordWrap(True)
        text.addWidget(title)
        text.addWidget(desc)
        button = QPushButton(self._t("refresh"))
        button.setObjectName("secondaryButton")
        action_key = {2: "cleanup", 6: "system_protection"}.get(
            target_index, "diagnostics"
        )
        button.setText(self._t(action_key))
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setAccessibleName(self._t(action_key))
        button.setAccessibleDescription(
            self._t("navigation_description", page=self._t(action_key))
        )
        button.clicked.connect(
            lambda _checked=False: self._navigate_to(target_index)
        )
        row.addLayout(text, 1)
        row.addWidget(button)
        layout.addLayout(row)
        setattr(self, f"_{title_key}", title)
        setattr(self, f"_{desc_key}", desc)
        setattr(self, f"_{title_key}_button", button)
        return frame

    def _build_diagnostics_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 26, 30, 28)
        layout.setSpacing(14)
        header = QHBoxLayout()
        left = QVBoxLayout()
        self._diagnostics_title = QLabel()
        self._diagnostics_title.setObjectName("pageTitle")
        self._diagnostics_body = QLabel()
        self._diagnostics_body.setObjectName("contentText")
        left.addWidget(self._diagnostics_title)
        left.addWidget(self._diagnostics_body)
        header.addLayout(left, 1)
        self._diagnostics_refresh = QPushButton()
        self._diagnostics_refresh.setObjectName("secondaryButton")
        self._diagnostics_refresh.setCursor(Qt.CursorShape.PointingHandCursor)
        self._diagnostics_refresh.clicked.connect(self._run_diagnostics)
        header.addWidget(self._diagnostics_refresh, 0, Qt.AlignmentFlag.AlignBottom)
        layout.addLayout(header)

        card = QFrame()
        card.setObjectName("contentCard")
        card_layout = QVBoxLayout(card)
        self._diagnostic_detail = QLabel()
        self._diagnostic_detail.setObjectName("contentText")
        self._diagnostic_detail.setWordWrap(True)
        card_layout.addWidget(self._diagnostic_detail)

        self._diagnostic_detail.setAccessibleName(self._t("diagnostics"))
        self._diagnostic_detail.setAccessibleDescription(self._t("diagnostics_body"))
        card_layout.addStretch(1)
        layout.addWidget(card, 1)
        return page

    def _build_protection_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 26, 30, 28)
        layout.setSpacing(16)

        self._protection_title = QLabel()
        self._protection_title.setObjectName("pageTitle")
        self._protection_body = QLabel()
        self._protection_body.setObjectName("contentText")
        self._protection_body.setWordWrap(True)
        layout.addWidget(self._protection_title)
        layout.addWidget(self._protection_body)

        card = QFrame()
        card.setObjectName("contentCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(20, 18, 20, 20)
        card_layout.setSpacing(14)

        self._protection_button = QPushButton()
        self._protection_button.setObjectName("secondaryButton")
        self._protection_button.setMinimumHeight(42)
        self._protection_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._protection_button.setAccessibleDescription(
            self._t("protection_button_description")
        )
        self._protection_button.clicked.connect(self._scan_protection)
        card_layout.addWidget(self._protection_button, 0, Qt.AlignmentFlag.AlignLeft)

        self._protection_result = QLabel()
        self._protection_result.setWordWrap(True)
        self._protection_result.setMinimumHeight(100)
        self._protection_result.setAccessibleDescription(
            self._t("protection_button_description")
        )
        card_layout.addWidget(self._protection_result)
        layout.addWidget(card, 1)

        self._protection_limit = QLabel()
        self._protection_limit.setObjectName("notice")
        self._protection_limit.setWordWrap(True)
        layout.addWidget(self._protection_limit)
        return page

    def _build_cleanup_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 26, 30, 28)
        layout.setSpacing(12)

        header = QHBoxLayout()
        left = QVBoxLayout()
        self._cleanup_title = QLabel()
        self._cleanup_title.setObjectName("pageTitle")
        self._cleanup_body = QLabel()
        self._cleanup_body.setObjectName("contentText")
        self._cleanup_body.setWordWrap(True)
        left.addWidget(self._cleanup_title)
        left.addWidget(self._cleanup_body)
        header.addLayout(left, 1)

        age_box = QHBoxLayout()
        self._age_label = QLabel()
        self._age_label.setObjectName("sectionLabel")
        self._age_spin = QSpinBox()
        self._age_spin.setRange(1, 3650)
        self._age_spin.setValue(31)
        self._age_spin.setAccessibleName(self._t("age_label"))
        self._age_spin.setToolTip(self._t("age_label"))
        self._age_spin.valueChanged.connect(self._on_age_changed)
        self._age_label.setBuddy(self._age_spin)
        self._age_days_suffix = QLabel()
        age_box.addWidget(self._age_label)
        age_box.addWidget(self._age_spin)
        age_box.addWidget(self._age_days_suffix)
        age_box.addStretch(1)
        left.addLayout(age_box)

        self._cleanup_scan_button = QPushButton()
        self._cleanup_scan_button.setObjectName("secondaryButton")
        self._cleanup_scan_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._cleanup_scan_button.clicked.connect(self._analyze_cleanup)
        header.addWidget(self._cleanup_scan_button, 0, Qt.AlignmentFlag.AlignBottom)
        layout.addLayout(header)

        self._cleanup_status = QLabel()
        self._cleanup_status.setObjectName("statusEmpty")
        self._cleanup_status.setWordWrap(True)
        self._cleanup_status.setMinimumHeight(38)
        layout.addWidget(self._cleanup_status)

        legend_frame = QFrame()
        legend_frame.setObjectName("contentCard")
        legend_layout = QVBoxLayout(legend_frame)
        legend_layout.setContentsMargins(12, 10, 12, 10)
        legend_layout.setSpacing(8)
        self._status_legend_title = QLabel()
        self._status_legend_title.setObjectName("sectionLabel")
        legend_layout.addWidget(self._status_legend_title)
        legend_row = QHBoxLayout()
        legend_row.setSpacing(8)
        self._candidate_legend = QLabel()
        self._candidate_legend.setObjectName("statusCandidate")
        self._candidate_legend.setWordWrap(True)
        self._protected_legend = QLabel()
        self._protected_legend.setObjectName("statusProtected")
        self._protected_legend.setWordWrap(True)
        self._review_legend = QLabel()
        self._review_legend.setObjectName("statusReview")
        self._review_legend.setWordWrap(True)
        for legend_item in (
            self._candidate_legend, self._protected_legend, self._review_legend
        ):
            legend_item.setMinimumHeight(46)
            legend_item.setAccessibleDescription(legend_item.text())
            legend_row.addWidget(legend_item, 1)
        legend_layout.addLayout(legend_row)
        layout.addWidget(legend_frame)

        action_bar = QHBoxLayout()
        self._select_all_button = QPushButton()
        self._select_all_button.setObjectName("secondaryButton")
        self._select_all_button.clicked.connect(lambda: self._set_cleanup_selection(True))
        self._clear_selection_button = QPushButton()
        self._clear_selection_button.setObjectName("secondaryButton")
        self._clear_selection_button.clicked.connect(lambda: self._set_cleanup_selection(False))
        self._delete_selected_button = QPushButton()
        self._delete_selected_button.setObjectName("dangerButton")
        self._delete_selected_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._delete_selected_button.setAccessibleDescription(
            self._t("cleanup_button_description")
        )
        self._delete_selected_button.setToolTip(self._t("cleanup_button_description"))
        self._delete_selected_button.clicked.connect(self._confirm_cleanup)
        action_bar.addWidget(self._select_all_button)
        action_bar.addWidget(self._clear_selection_button)
        action_bar.addStretch(1)
        action_bar.addWidget(self._delete_selected_button)
        layout.addLayout(action_bar)

        self._cleanup_summary = QLabel()
        self._cleanup_summary.setObjectName("sectionLabel")
        layout.addWidget(self._cleanup_summary)

        table_frame = QFrame()
        table_frame.setObjectName("tableCard")
        table_layout = QVBoxLayout(table_frame)
        self._cleanup_table = QTableWidget(0, 8)
        self._cleanup_table.setAccessibleName(self._t("cleanup"))
        self._cleanup_table.setAccessibleDescription(self._t("cleanup_table_description"))
        self._cleanup_table.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self._cleanup_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._cleanup_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._cleanup_table.setAlternatingRowColors(True)
        self._cleanup_table.setWordWrap(False)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        self._cleanup_table.horizontalHeader().setSectionResizeMode(7, QHeaderView.ResizeMode.Stretch)
        table_layout.addWidget(self._cleanup_table)
        layout.addWidget(table_frame, 1)

        self._protected_notice = QLabel()
        self._protected_notice.setObjectName("notice")
        self._protected_notice.setWordWrap(True)
        layout.addWidget(self._protected_notice)
        return page

    def _build_startup_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 26, 30, 28)
        layout.setSpacing(12)
        header = QHBoxLayout()
        left = QVBoxLayout()
        self._startup_title = QLabel()
        self._startup_title.setObjectName("pageTitle")
        self._startup_body = QLabel()
        self._startup_body.setObjectName("contentText")
        self._startup_body.setWordWrap(True)
        left.addWidget(self._startup_title)
        left.addWidget(self._startup_body)
        header.addLayout(left, 1)
        self._startup_refresh = QPushButton()
        self._startup_refresh.setObjectName("secondaryButton")
        self._startup_refresh.clicked.connect(self._load_startup)
        header.addWidget(self._startup_refresh, 0, Qt.AlignmentFlag.AlignBottom)
        layout.addLayout(header)
        self._startup_table = self._make_table(3)
        self._startup_table.setAccessibleName(self._t("startup"))
        self._startup_table.setAccessibleDescription(self._t("startup_table_description"))
        layout.addWidget(self._startup_table, 1)
        return page

    def _build_processes_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 26, 30, 28)
        layout.setSpacing(12)
        header = QHBoxLayout()
        left = QVBoxLayout()
        self._processes_title = QLabel()
        self._processes_title.setObjectName("pageTitle")
        self._processes_body = QLabel()
        self._processes_body.setObjectName("contentText")
        self._processes_body.setWordWrap(True)
        left.addWidget(self._processes_title)
        left.addWidget(self._processes_body)
        header.addLayout(left, 1)
        self._processes_refresh = QPushButton()
        self._processes_refresh.setObjectName("secondaryButton")
        self._processes_refresh.clicked.connect(self._load_processes)
        header.addWidget(self._processes_refresh, 0, Qt.AlignmentFlag.AlignBottom)
        layout.addLayout(header)
        self._process_table = self._make_table(5)
        self._process_table.setAccessibleName(self._t("processes"))
        self._process_table.setAccessibleDescription(self._t("process_table_description"))
        layout.addWidget(self._process_table, 1)
        return page

    def _build_history_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 26, 30, 28)
        layout.setSpacing(12)
        self._history_title = QLabel()
        self._history_title.setObjectName("pageTitle")
        self._history_body = QLabel()
        self._history_body.setObjectName("contentText")
        self._history_body.setWordWrap(True)
        history_header = QHBoxLayout()
        history_header.addWidget(self._history_title, 1)
        self._history_clear_button = QPushButton()
        self._history_clear_button.setObjectName("dangerButton")
        self._history_clear_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._history_clear_button.setAccessibleDescription(
            self._t("history_clear_button_description")
        )
        self._history_clear_button.setToolTip(self._t("history_clear_button_description"))
        self._history_clear_button.clicked.connect(self._clear_history)
        history_header.addWidget(self._history_clear_button)
        layout.addLayout(history_header)
        layout.addWidget(self._history_body)
        self._history_table = self._make_table(7)
        self._history_table.setAccessibleName(self._t("history"))
        self._history_table.setAccessibleDescription(self._t("history_table_description"))
        layout.addWidget(self._history_table, 1)
        return page

    def _make_table(self, columns: int) -> QTableWidget:
        table = QTableWidget(0, columns)
        table.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setWordWrap(False)
        table.verticalHeader().setVisible(False)
        table.verticalHeader().setDefaultSectionSize(34)
        table.setAccessibleName("Zentry data table")
        return table

    def _toggle_language(self) -> None:
        self._language = "en" if self._language == "es" else "es"
        self._retranslate_ui()

    def _on_age_changed(self, value: int) -> None:
        self._current_age_days = value

    def _t(self, key: str, **kwargs: object) -> str:
        """Return a translated label and validate the supplied format values."""
        try:
            template = TRANSLATIONS[self._language][key]
        except KeyError as exc:
            LOGGER.error("Missing translation key; key=%s language=%s", key, self._language)
            raise KeyError(f"Missing translation key {key!r} for {self._language!r}") from exc
        try:
            return template.format(**kwargs)
        except (KeyError, ValueError, IndexError) as exc:
            LOGGER.error("Invalid translation formatting; key=%s language=%s", key, self._language)
            raise ValueError(f"Cannot format translation {key!r} for {self._language!r}") from exc

    def _retranslate_ui(self) -> None:
        """Refresh every translated widget without recreating the widget tree."""
        self.setWindowTitle("Zentry")
        self._brand.setText(self._t("brand_title"))
        self._brand_subtitle.setText(self._t("brand_subtitle"))
        self._pages.setAccessibleName(self._t("pages_accessible_name"))
        nav_keys = (
            "overview", "diagnostics", "cleanup_nav", "startup_nav", "processes",
            "history", "system_protection_nav",
        )
        nav_icons = ("⌂", "∿", "✧", "◴", "▦", "◷", "⬡")
        for index, key in enumerate(nav_keys):
            button = self._nav_buttons[index]
            button.setText(f"{nav_icons[index]}  {self._t(key)}")
            button.setAccessibleName(self._t(key))
            button.setAccessibleDescription(
                self._t("navigation_description", page=self._t(key))
            )
        if self._language_button is not None:
            self._language_button.setText(self._t("language"))
            self._language_button.setToolTip(self._t("language_tooltip"))
        self._safe_status.setText(self._t("safe_mode"))
        self._version.setText(self._t("version"))
        self._overview_eyebrow.setText(self._t("page_overview"))
        self._overview_title.setText(self._t("title_overview"))
        self._overview_subtitle.setText(self._t("overview_subtitle"))
        self._read_only_badge.setText(self._t("safety_badge"))
        self._read_only_badge.setToolTip(self._t("safety_badge_tooltip"))
        self._read_only_badge.setAccessibleName(self._t("safety_badge"))
        self._read_only_badge.setAccessibleDescription(self._t("safety_badge_tooltip"))
        self._safe_cleanup_title.setText(self._t("safe_cleanup_title"))
        self._safe_cleanup_desc.setText(self._t("safe_cleanup_desc"))
        self._safe_cleanup_button.setText(self._t("safe_cleanup_button"))
        self._safe_cleanup_button.setAccessibleName(self._t("safe_cleanup_button"))
        scan_key = {"idle": "scan", "running": "scanning", "complete": "complete"}.get(
            self._scan_state, "scan"
        )
        self._scan_button.setText(self._t(scan_key))
        self._scan_button.setAccessibleName(self._t(scan_key))
        self._scan_button.setAccessibleDescription(self._t("scan_button_description"))
        self._rec_label.setText(self._t("recommendations"))
        self._activity_title.setText(self._t("activity_title"))
        self._cpu_legend.setText(f"●  {self._t('activity_cpu')}")
        self._memory_legend.setText(f"●  {self._t('activity_memory')}")
        self._activity_graph.set_waiting_text(self._t("activity_waiting"))
        self._workflow_label.setText(self._t("workflow"))
        self._cleanup_action.setText(self._t("cleanup_action"))
        self._cleanup_desc.setText(self._t("cleanup_desc"))
        self._cleanup_action_button.setText(self._t("cleanup"))
        self._system_action.setText(self._t("system_action"))
        self._system_desc.setText(self._t("system_desc"))
        self._system_action_button.setText(self._t("system_protection"))
        self._diagnostics_title.setText(self._t("diagnostics"))
        self._diagnostics_body.setText(self._t("diagnostics_body"))
        self._diagnostics_refresh.setText(self._t("refresh"))
        self._protection_title.setText(self._t("system_scan_title"))
        self._protection_body.setText(self._t("system_protection_body"))
        self._protection_button.setText(self._t("scan_protection"))
        self._protection_button.setAccessibleDescription(
            self._t("protection_button_description")
        )
        self._protection_limit.setText(self._t("system_protection_limit"))
        self._status_legend_title.setText(self._t("status_legend_title"))
        self._candidate_legend.setText(
            f"{self._t('candidate_badge')}: {self._t('candidate_explanation')}"
        )
        self._protected_legend.setText(
            f"{self._t('protected_badge')}: {self._t('protected_explanation')}"
        )
        self._review_legend.setText(
            f"{self._t('review_badge')}: {self._t('review_explanation')}"
        )
        self._delete_selected_button.setAccessibleDescription(
            self._t("cleanup_button_description")
        )
        self._delete_selected_button.setToolTip(self._t("cleanup_button_description"))
        self._age_spin.setAccessibleName(self._t("age_label"))
        self._age_spin.setToolTip(self._t("age_label"))
        self._cleanup_title.setText(self._t("cleanup"))
        self._cleanup_body.setText(self._t("cleanup_body"))
        self._cleanup_scan_button.setText(self._t("scan_cleanup"))
        self._age_label.setText(self._t("age_label"))
        self._age_days_suffix.setText(self._t("days"))
        self._select_all_button.setText(self._t("select_all"))
        self._clear_selection_button.setText(self._t("clear_selection"))
        cleanup_button_key = (
            "cleaning"
            if self._cleanup_running
            else "loading_cleanup_preview"
            if self._cleanup_previewing
            else "delete_selected"
        )
        self._delete_selected_button.setText(self._t(cleanup_button_key))
        self._protected_notice.setText(self._t("protected_notice"))
        self._startup_title.setText(self._t("startup"))
        self._startup_body.setText(self._t("startup_body"))
        self._startup_refresh.setText(self._t("refresh"))
        self._processes_title.setText(self._t("processes"))
        self._processes_body.setText(self._t("processes_body"))
        self._processes_refresh.setText(self._t("refresh"))
        self._history_title.setText(self._t("history"))
        self._history_body.setText(self._t("history_body"))
        self._history_clear_button.setText(self._t("history_clear"))
        self._history_clear_button.setAccessibleName(self._t("history_clear"))
        self._history_clear_button.setAccessibleDescription(
            self._t("history_clear_button_description")
        )
        self._history_clear_button.setToolTip(
            self._t("history_clear_button_description")
        )
        self._diagnostic_detail.setAccessibleName(self._t("diagnostics"))
        self._diagnostic_detail.setAccessibleDescription(self._t("diagnostics_body"))
        self._protection_result.setAccessibleDescription(
            self._t("system_protection_body")
        )
        for legend_item in (
            self._candidate_legend, self._protected_legend, self._review_legend
        ):
            legend_item.setAccessibleDescription(legend_item.text())
        for action_key, button in (
            ("cleanup", self._cleanup_action_button),
            ("system_protection", self._system_action_button),
        ):
            button.setAccessibleName(self._t(action_key))
            button.setAccessibleDescription(
                self._t("navigation_description", page=self._t(action_key))
            )
        self._apply_table_headers()

        # Re-render data-driven text as well as static labels. These renderers
        # never trigger collection, cleanup, or history writes.
        self._render_snapshot()
        self._render_diagnostic_snapshot()
        self._render_protection_result()
        self._render_cleanup_state(preserve_selection=True)
        self._render_startup_entries()
        self._render_process_entries()
        self._refresh_history()

    def _apply_table_headers(self) -> None:
        self._cleanup_table.setHorizontalHeaderLabels(
            [
                "",
                self._t("category"),
                self._t("file_name"),
                self._t("size"),
                self._t("last_access"),
                self._t("last_modified"),
                self._t("classification"),
                self._t("reason"),
            ]
        )
        self._startup_table.setHorizontalHeaderLabels(
            [self._t("startup_name"), self._t("source"), self._t("command")]
        )
        self._process_table.setHorizontalHeaderLabels(
            [self._t("process_name"), self._t("pid"), self._t("cpu_header"), self._t("ram"), self._t("status")]
        )
        self._history_table.setHorizontalHeaderLabels(
            [
                self._t("time"),
                self._t("history_operation"),
                self._t("history_result"),
                self._t("history_files"),
                self._t("history_estimated_bytes"),
                self._t("history_moved_bytes"),
                self._t("history_omissions"),
            ]
        )
        self._cleanup_table.setAccessibleName(self._t("cleanup"))
        self._cleanup_table.setAccessibleDescription(self._t("cleanup_table_description"))
        self._startup_table.setAccessibleName(self._t("startup"))
        self._startup_table.setAccessibleDescription(self._t("startup_table_description"))
        self._process_table.setAccessibleName(self._t("processes"))
        self._process_table.setAccessibleDescription(self._t("process_table_description"))
        self._history_table.setAccessibleName(self._t("history"))
        self._history_table.setAccessibleDescription(self._t("history_table_description"))

    def _start_scan(self) -> None:
        if self._task_is_running("diagnostics"):
            self._show_operation_busy("diagnostics")
            return
        self._scan_state = "running"
        self._diagnostics_loading = True
        self._scan_button.setEnabled(False)
        self._diagnostics_refresh.setEnabled(False)
        self._scan_button.setText(self._t("scanning"))
        self._run_worker(
            "diagnostics",
            lambda progress: self._provider.collect_snapshot(),
            self._on_snapshot,
        )

    def _on_snapshot(self, data: object) -> None:
        if not isinstance(data, SystemSnapshot):
            self._handle_operation_failure("diagnostics", "invalid_result")
            return
        self._scan_state = "complete"
        self._diagnostics_loading = False
        self._scan_button.setEnabled(True)
        self._diagnostics_refresh.setEnabled(True)
        self._last_snapshot = data
        self._last_diagnostic_snapshot = data
        self._render_snapshot()
        self._render_diagnostic_snapshot()
        self._record_snapshot_history(data)

    def _render_snapshot(self) -> None:
        data = self._last_snapshot
        if data is None:
            if self._latest_activity is None:
                self._metrics["cpu"].update_text(self._t("cpu"), "—", self._t("waiting"))
                self._metrics["memory"].update_text(self._t("memory"), "—", self._t("waiting"))
            else:
                live_cpu, live_memory = self._latest_activity
                if live_cpu is not None:
                    self._metrics["cpu"].update_text(
                        self._t("cpu"), f"{live_cpu:.0f}%", self._t("current_cpu")
                    )
                else:
                    self._metrics["cpu"].update_text(
                        self._t("cpu"), "—", self._t("waiting")
                    )
                if live_memory is not None:
                    self._metrics["memory"].update_text(
                        self._t("memory"), f"{live_memory:.0f}%", self._t("current_memory")
                    )
                else:
                    self._metrics["memory"].update_text(
                        self._t("memory"), "—", self._t("waiting")
                    )
            self._metrics["storage"].update_text(self._t("storage"), "—", self._t("waiting"))
            self._notice.setText(
                f"<span style='color:#35e7c4;font-size:18px;font-weight:700'>◉  "
                f"{self._t('dashboard_waiting')}</span><br>"
                f"<span style='color:#8fb4d9'>{self._t('dashboard_detail_waiting')}</span><br>"
                f"<span style='color:#6f94bd;font-size:11px'>{self._t('notice')}</span>"
            )
            return
        self._metrics["cpu"].update_text(
            self._t("cpu"), f"{data.cpu_percent:.0f}%", self._t("current_cpu")
        )
        self._metrics["memory"].update_text(
            self._t("memory"), f"{data.memory_percent:.0f}%", self._t("current_memory")
        )
        self._metrics["storage"].update_text(
            self._t("storage"),
            f"{data.disk_percent:.0f}%",
            self._t("disk_usage"),
            headline=self._t("available", value=data.disk_free_gb),
        )
        score = data.health_score
        if score >= 80:
            title_key = "dashboard_healthy"
        elif score >= 60:
            title_key = "dashboard_moderate"
        else:
            title_key = "dashboard_elevated"
        self._notice.setText(
            f"<span style='color:#35e7c4;font-size:18px;font-weight:700'>✓  "
            f"{self._t(title_key)}</span><br>"
            f"<span style='color:#8fb4d9'>{self._t('dashboard_detail_ready')}</span><br>"
            f"<span style='color:#6f94bd;font-size:11px'>{self._t('notice')}</span>"
        )

    def _sample_activity(self) -> None:
        """Request real CPU/RAM samples without blocking the Qt event loop."""
        if self._task_is_running("activity"):
            return
        sampler = getattr(self._provider, "sample_activity", None)
        if not callable(sampler):
            return
        self._run_worker(
            "activity",
            lambda _progress: sampler(),
            self._on_activity_sample,
        )

    def _on_activity_sample(self, data: object) -> None:
        """Validate provider output before drawing measured activity values."""
        if not isinstance(data, (tuple, list)) or len(data) != 2:
            return
        cpu, memory = data
        cpu_valid = (
            not isinstance(cpu, bool) and isinstance(cpu, (int, float))
            and 0.0 <= float(cpu) <= 100.0
        )
        memory_valid = (
            not isinstance(memory, bool) and isinstance(memory, (int, float))
            and 0.0 <= float(memory) <= 100.0
        )
        # psutil's initial non-blocking CPU sample initializes its counter.
        # Do not portray that first value (often 0%) as measured utilization.
        cpu_is_initial = cpu_valid and not self._activity_cpu_warmed
        if cpu_is_initial:
            self._activity_cpu_warmed = True
        previous_cpu, previous_memory = self._latest_activity or (None, None)
        current_cpu = previous_cpu if cpu_is_initial or not cpu_valid else float(cpu)
        current_memory = float(memory) if memory_valid else previous_memory
        if current_cpu is not None or current_memory is not None:
            self._latest_activity = (current_cpu, current_memory)
        if current_cpu is not None:
            self._metrics["cpu"].update_text(
                self._t("cpu"), f"{current_cpu:.0f}%", self._t("current_cpu")
            )
        if current_memory is not None:
            self._metrics["memory"].update_text(
                self._t("memory"), f"{current_memory:.0f}%", self._t("current_memory")
            )
        if cpu_is_initial or not (cpu_valid and memory_valid):
            return
        self._activity_graph.add_sample(float(cpu), float(memory))

    def _run_diagnostics(self) -> None:
        if self._task_is_running("diagnostics"):
            self._show_operation_busy("diagnostics")
            return
        self._diagnostics_loading = True
        self._scan_state = "running"
        self._scan_button.setEnabled(False)
        self._diagnostics_refresh.setEnabled(False)
        self._render_diagnostic_snapshot()
        self._run_worker(
            "diagnostics",
            lambda progress: self._provider.collect_snapshot(),
            self._on_diagnostic_page,
        )

    def _on_diagnostic_page(self, data: object) -> None:
        self._diagnostics_loading = False
        if not isinstance(data, SystemSnapshot):
            self._handle_operation_failure("diagnostics", "invalid_result")
            return
        self._scan_state = "complete"
        self._scan_button.setEnabled(True)
        self._diagnostics_refresh.setEnabled(True)
        self._last_snapshot = data
        self._last_diagnostic_snapshot = data
        self._render_snapshot()
        self._render_diagnostic_snapshot()
        self._record_snapshot_history(data)

    def _record_snapshot_history(self, data: SystemSnapshot) -> None:
        """Persist an aggregate result for either entry point to diagnostics."""
        self._record_history_event(
            HistoryEvent(
                operation_type=HistoryOperation.SYSTEM_DIAGNOSTICS,
                result=HistoryResult.SUCCESS,
                process_count=data.process_count,
                health_score=data.health_score,
                cpu_percent=data.cpu_percent,
                memory_percent=data.memory_percent,
                disk_percent=data.disk_percent,
            )
        )

    def _render_diagnostic_snapshot(self) -> None:
        if self._diagnostics_loading:
            self._set_status_label(
                self._diagnostic_detail, self._t("loading_diagnostics"), "Loading"
            )
            return
        data = self._last_diagnostic_snapshot
        if data is None:
            self._set_status_label(self._diagnostic_detail, self._t("no_data"), "Empty")
            return
        detail = (
            f"{self._t('cpu')}: {data.cpu_percent:.1f}%\n"
            f"{self._t('memory')}: {data.memory_percent:.1f}%\n"
            f"{self._t('storage')}: {data.disk_percent:.1f}%\n"
            f"{self._t('available', value=data.disk_free_gb)}\n"
            f"{self._t('startup')}: {data.startup_count}\n"
            f"{self._t('processes_count')}: {data.process_count}"
        )
        self._set_status_label(self._diagnostic_detail, detail, "Ready")

    def _scan_protection(self) -> None:
        if self._protection_loading or self._task_is_running("protection"):
            self._show_operation_busy("protection")
            return
        self._protection_loading = True
        self._protection_button.setEnabled(False)
        self._render_protection_result()
        self._run_worker(
            "protection", self._provider.scan_system_protection, self._on_protection
        )

    def _on_protection(self, data: object) -> None:
        self._protection_loading = False
        self._protection_button.setEnabled(True)
        if not isinstance(data, SystemProtectionSummary):
            self._handle_operation_failure("protection", "invalid_result")
            return
        self._last_protection_summary = data
        self._render_protection_result()
        protection_partial = data.inaccessible_items > 0
        self._record_history_event(
            HistoryEvent(
                operation_type=HistoryOperation.SYSTEM_PROTECTION_SCAN,
                result=HistoryResult.PARTIAL if protection_partial else HistoryResult.SUCCESS,
                files_seen=data.files_seen,
                protected_files=data.protected_files,
                inaccessible_items=data.inaccessible_items,
                skipped_files=data.inaccessible_items,
                roots_checked=data.roots_checked,
                error_codes=("items_inaccessible",) if protection_partial else (),
            )
        )

    def _render_protection_result(self) -> None:
        if self._protection_loading:
            self._set_status_label(
                self._protection_result, self._t("loading_protection"), "Loading"
            )
            return
        data = self._last_protection_summary
        if data is None:
            self._set_status_label(
                self._protection_result, self._t("protection_initial"), "Empty"
            )
            return
        result_text = self._t(
            "system_scan_result",
            roots=data.roots_checked,
            files=data.files_seen,
            protected=data.protected_files,
            managed=data.system_managed_files,
            inaccessible=data.inaccessible_items,
        )
        # A successful protection scan is a completed result, not an error;
        # protected resources are expected findings and are stated in the text.
        state = "Review" if data.inaccessible_items else "Ready"
        self._set_status_label(self._protection_result, result_text, state)

    def _ensure_cleanup_defaults(self) -> None:
        self._render_cleanup_state(preserve_selection=True)

    def _analyze_cleanup(self) -> None:
        if self._task_is_running("cleanup") or self._cleanup_previewing or self._cleanup_running:
            self._show_operation_busy("cleanup")
            return
        self._cleanup_stage = "scan"
        self._cleanup_loading = True
        self._cleanup_scan_button.setEnabled(False)
        self._age_spin.setEnabled(False)
        # Starting a scan invalidates the service's previous scan manifest.
        # Do not leave stale candidates visibly selectable if this scan fails.
        self._last_cleanup_summary = None
        self._cleanup_candidates = []
        self._discarded_candidate_count = 0
        self._cleanup_checkboxes = []
        self._render_cleanup_state(preserve_selection=False)
        age_days = self._age_spin.value()
        self._current_age_days = age_days
        started = self._run_worker(
            "cleanup",
            lambda progress: self._provider.scan_cleanup(age_days, progress),
            self._on_cleanup,
        )
        if not started:
            self._cleanup_loading = False
            self._cleanup_scan_button.setEnabled(True)
            self._age_spin.setEnabled(True)
            self._render_cleanup_state(preserve_selection=False)

    def _on_cleanup(self, data: object) -> None:
        self._cleanup_loading = False
        self._cleanup_scan_button.setEnabled(True)
        self._age_spin.setEnabled(True)
        if not isinstance(data, CleanupScanSummary):
            self._handle_operation_failure("cleanup", "invalid_result")
            return
        self._cleanup_stage = "idle"
        self._last_cleanup_summary = data
        approved_candidates = [
            candidate
            for candidate in data.candidates
            if candidate.classification is FileClassification.SAFE_CANDIDATE
            and candidate.policy_decision is CleanupPolicyDecision.ALLOW
            and candidate.fingerprint is not None
        ]
        self._discarded_candidate_count = len(data.candidates) - len(approved_candidates)
        if self._discarded_candidate_count:
            LOGGER.warning(
                "Unapproved candidates omitted from GUI selection; count=%d",
                self._discarded_candidate_count,
            )
        self._cleanup_candidates = approved_candidates
        self._cleanup_checkboxes = []
        self._render_cleanup_state(preserve_selection=False)
        scan_partial = data.inaccessible_items > 0 or self._discarded_candidate_count > 0
        self._record_history_event(
            HistoryEvent(
                operation_type=HistoryOperation.STALE_SCAN,
                result=(
                    HistoryResult.PARTIAL if scan_partial
                    else (
                        HistoryResult.NO_CANDIDATES
                        if not approved_candidates
                        else HistoryResult.SUCCESS
                    )
                ),
                files_seen=data.scanned_files,
                candidate_files=len(approved_candidates),
                protected_files=data.protected_files,
                review_files=data.review_files + self._discarded_candidate_count,
                inaccessible_items=data.inaccessible_items,
                skipped_files=(
                    data.protected_files + data.review_files + data.inaccessible_items
                    + self._discarded_candidate_count
                ),
                estimated_bytes=sum(item.size_bytes for item in approved_candidates),
                error_codes=(
                    ("items_inaccessible",) if data.inaccessible_items else ()
                ) + (
                    ("unapproved_candidates",) if self._discarded_candidate_count else ()
                ),
            )
        )

    def _render_cleanup_state(self, *, preserve_selection: bool) -> None:
        selected_paths = {
            str(candidate.path)
            for candidate, checkbox in zip(self._cleanup_candidates, self._cleanup_checkboxes)
            if checkbox.isChecked()
        } if preserve_selection else set()

        self._cleanup_table.clearSpans()
        self._cleanup_table.setRowCount(0)
        self._cleanup_checkboxes = []
        summary = self._last_cleanup_summary
        if summary is None:
            self._set_table_empty_state(self._cleanup_table, "empty_table")
            self._cleanup_summary.setText(self._t("empty_table"))
            self._select_all_button.setEnabled(False)
            self._clear_selection_button.setEnabled(False)
            if self._cleanup_loading:
                self._set_status_label(
                    self._cleanup_status,
                    self._t("status_scanning", value=self._t("loading_cleanup")),
                    "Loading",
                )
            else:
                self._set_status_label(
                    self._cleanup_status, self._t("cleanup_status_initial"), "Empty"
                )
            self._delete_selected_button.setEnabled(False)
            return

        if not self._cleanup_candidates:
            self._set_table_empty_state(self._cleanup_table, "no_candidates")
        else:
            for candidate in self._cleanup_candidates:
                row = self._cleanup_table.rowCount()
                self._cleanup_table.insertRow(row)
                checkbox = QCheckBox()
                checkbox.setChecked(str(candidate.path) in selected_paths)
                checkbox.setEnabled(
                    not (
                        self._cleanup_loading
                        or self._cleanup_previewing
                        or self._cleanup_running
                    )
                )
                checkbox.stateChanged.connect(self._update_cleanup_selection_summary)
                checkbox.setAccessibleName(
                    self._t("select_file", name=candidate.name)
                )
                self._cleanup_table.setCellWidget(row, 0, checkbox)
                self._cleanup_checkboxes.append(checkbox)
                self._cleanup_table.setItem(
                    row, 1, QTableWidgetItem(self._translate_cleanup_category(candidate.category))
                )
                name_item = QTableWidgetItem(candidate.name)
                name_item.setToolTip(candidate.name)
                self._cleanup_table.setItem(row, 2, name_item)
                self._cleanup_table.setItem(
                    row, 3, QTableWidgetItem(f"{candidate.size_mb:.1f} MB")
                )
                date_format = self._t("date_time_format")
                self._cleanup_table.setItem(
                    row, 4, QTableWidgetItem(candidate.last_access.strftime(date_format))
                )
                self._cleanup_table.setItem(
                    row, 5, QTableWidgetItem(candidate.last_modified.strftime(date_format))
                )
                badge = QLabel(self._t("candidate_badge"))
                badge.setObjectName("badgeSafe")
                badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
                self._cleanup_table.setCellWidget(row, 6, badge)
                reason_item = QTableWidgetItem(candidate.reason)
                reason_item.setToolTip(candidate.reason)
                self._cleanup_table.setItem(row, 7, reason_item)
                checkbox.setToolTip(
                    f"{self._translate_cleanup_category(candidate.category)} · "
                    f"{candidate.size_mb:.1f} MB · {candidate.reason}"
                )
                checkbox.setAccessibleDescription(
                    f"{self._translate_cleanup_category(candidate.category)}; "
                    f"{candidate.size_mb:.1f} MB; {candidate.reason}"
                )

        if self._cleanup_loading:
            self._set_status_label(
                self._cleanup_status,
                self._t("status_scanning", value=self._t("loading_cleanup")),
                "Loading",
            )
        else:
            status_state = (
                "Review"
                if (
                    summary.review_files
                    or summary.inaccessible_items
                    or self._discarded_candidate_count
                )
                else "Candidate"
                if self._cleanup_candidates
                else "Protected"
                if summary.protected_files
                else "Empty"
            )
            self._set_status_label(
                self._cleanup_status,
                self._t(
                    "cleanup_status_summary",
                    scanned=summary.scanned_files,
                    protected=summary.protected_files,
                    review=summary.review_files + self._discarded_candidate_count,
                    inaccessible=summary.inaccessible_items,
                ),
                status_state,
            )
        self._update_cleanup_selection_summary()

    def _translate_cleanup_category(self, category: str) -> str:
        category_keys = {
            "User temporary files": "category_user_temp",
            "Windows temporary files": "category_windows_temp",
            "Chrome cache": "category_chrome_cache",
            "Edge cache": "category_edge_cache",
            "Firefox cache": "category_firefox_cache",
        }
        return self._t(category_keys.get(category, "category_unknown"))

    def _set_status_label(self, label: QLabel, text: str, state: str) -> None:
        """Set a visible, text-backed status with consistent accessible semantics."""
        allowed_states = {
            "Loading", "Ready", "Empty", "Error", "Protected", "Review", "Candidate"
        }
        normalized = state[:1].upper() + state[1:].lower()
        if normalized not in allowed_states:
            normalized = "Empty"
        label.setObjectName(f"status{normalized}")
        label.setText(text)
        label.setWordWrap(True)
        label.setAccessibleDescription(text)
        label.style().unpolish(label)
        label.style().polish(label)

    def _set_table_empty_state(self, table: QTableWidget, key: str) -> None:
        table.clearSpans()
        table.setRowCount(0)
        table.insertRow(0)
        item = QTableWidgetItem(self._t(key))
        item.setFlags(Qt.ItemFlag.ItemIsEnabled)
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        item.setData(Qt.ItemDataRole.UserRole, "status")
        if key.startswith("loading"):
            foreground, background = ("#c8efff", "#102431")
        elif key == "operation_failed":
            foreground, background = ("#ffd3d8", "#31171d")
        else:
            foreground, background = ("#d0dbe5", "#121a23")
        item.setForeground(QBrush(QColor(foreground)))
        item.setBackground(QBrush(QColor(background)))
        table.setItem(0, 0, item)
        if table.columnCount() > 1:
            table.setSpan(0, 0, 1, table.columnCount())

    def _set_cleanup_selection(self, checked: bool) -> None:
        for checkbox in self._cleanup_checkboxes:
            checkbox.blockSignals(True)
            checkbox.setChecked(checked)
            checkbox.blockSignals(False)
        self._update_cleanup_selection_summary()

    def _selected_cleanup_candidates(self) -> list[FileCandidate]:
        return [
            candidate
            for candidate, checkbox in zip(self._cleanup_candidates, self._cleanup_checkboxes)
            if checkbox.isChecked()
        ]

    def _update_cleanup_selection_summary(self, *_args: object) -> None:
        selected = self._selected_cleanup_candidates()
        busy = self._cleanup_loading or self._cleanup_previewing or self._cleanup_running
        self._select_all_button.setEnabled(bool(self._cleanup_candidates) and not busy)
        self._clear_selection_button.setEnabled(bool(self._cleanup_candidates) and not busy)
        if selected:
            bytes_size = sum(item.size_bytes for item in selected)
            self._cleanup_summary.setText(
                self._t("selected", files=len(selected), value=bytes_size / (1024**3))
            )
            self._delete_selected_button.setEnabled(not busy)
            return

        summary = self._last_cleanup_summary
        if summary is None:
            self._cleanup_summary.setText(
                self._t("status_scanning", value=self._t("loading_cleanup"))
                if self._cleanup_loading else self._t("empty_table")
            )
        elif self._cleanup_candidates:
            self._cleanup_summary.setText(
                self._t(
                    "reclaimable",
                    value=sum(item.size_bytes for item in self._cleanup_candidates) / (1024**3),
                )
            )
        else:
            self._cleanup_summary.setText(self._t("no_candidates"))
        self._delete_selected_button.setEnabled(False)

    def _render_startup_entries(self) -> None:
        self._startup_table.clearSpans()
        self._startup_table.setRowCount(0)
        if self._startup_loading:
            self._set_table_empty_state(self._startup_table, "loading_startup")
            return
        if not self._startup_loaded:
            self._set_table_empty_state(self._startup_table, "empty_table")
            return
        if not self._startup_entries:
            self._set_table_empty_state(self._startup_table, "empty_startup")
            return
        for entry in self._startup_entries:
            row = self._startup_table.rowCount()
            self._startup_table.insertRow(row)
            self._startup_table.setItem(row, 0, QTableWidgetItem(entry.name))
            self._startup_table.setItem(row, 1, QTableWidgetItem(entry.source))
            self._startup_table.setItem(row, 2, QTableWidgetItem(entry.command))

    def _render_process_entries(self) -> None:
        self._process_table.clearSpans()
        self._process_table.setRowCount(0)
        if self._processes_loading:
            self._set_table_empty_state(self._process_table, "loading_processes")
            return
        if not self._processes_loaded:
            self._set_table_empty_state(self._process_table, "empty_table")
            return
        if not self._process_entries:
            self._set_table_empty_state(self._process_table, "empty_processes")
            return
        for process in self._process_entries:
            row = self._process_table.rowCount()
            self._process_table.insertRow(row)
            self._process_table.setItem(row, 0, QTableWidgetItem(process.name))
            self._process_table.setItem(row, 1, QTableWidgetItem(str(process.pid)))
            self._process_table.setItem(row, 2, QTableWidgetItem(f"{process.cpu_percent:.1f}"))
            self._process_table.setItem(row, 3, QTableWidgetItem(f"{process.memory_percent:.1f}"))
            self._process_table.setItem(
                row, 4, QTableWidgetItem(self._translate_process_status(process.status))
            )

    def _translate_process_status(self, status: str) -> str:
        status_keys = {
            "running": "process_status_running",
            "sleeping": "process_status_sleeping",
            "stopped": "process_status_stopped",
            "zombie": "process_status_zombie",
            "dead": "process_status_dead",
            "idle": "process_status_idle",
            "waiting": "process_status_waiting",
        }
        return self._t(status_keys.get(status.casefold(), "process_status_unknown"))

    def _confirm_cleanup(self) -> None:
        """Run a service-owned dry-run, then ask for explicit user confirmation."""
        if (
            self._task_is_running("cleanup")
            or self._cleanup_loading
            or self._cleanup_previewing
            or self._cleanup_running
        ):
            self._show_operation_busy("cleanup")
            return

        selected = tuple(self._selected_cleanup_candidates())
        if not selected:
            self._show_message_box(
                QMessageBox.Icon.Information, self._t("cleanup"), self._t("selection_empty")
            )
            return

        self._pending_cleanup_candidates = selected
        self._cleanup_previewing = True
        self._cleanup_stage = "preview"
        self._set_cleanup_controls_busy(True)
        self._set_status_label(
            self._cleanup_status,
            self._t("loading_cleanup_preview"),
            "Loading",
        )
        started = self._run_worker(
            "cleanup",
            lambda progress: self._provider.preview_cleanup(selected),
            self._on_cleanup_preview,
        )
        if not started:
            self._cleanup_previewing = False
            self._cleanup_stage = "idle"
            self._pending_cleanup_candidates = ()
            self._set_cleanup_controls_busy(False)

    def _on_cleanup_preview(self, data: object) -> None:
        self._cleanup_previewing = False
        self._set_cleanup_controls_busy(False)
        if not isinstance(data, CleanupPreview):
            self._pending_cleanup_candidates = ()
            self._handle_operation_failure("cleanup", "invalid_preview_result")
            return

        if data.eligible_files == 0:
            self._pending_cleanup_candidates = ()
            self._cleanup_stage = "idle"
            self._show_message_box(
                QMessageBox.Icon.Warning, self._t("cleanup"), self._t("selection_stale")
            )
            self._render_cleanup_state(preserve_selection=False)
            return

        categories = "\n".join(
            self._t(
                "preview_category",
                category=self._translate_cleanup_category(item.category),
                files=item.file_count,
                value=item.estimated_bytes / (1024**2),
            )
            for item in data.categories
        )
        summary = self._t(
            "confirm_summary",
            files=data.eligible_files,
            value=data.estimated_bytes / (1024**3),
            categories=categories,
            rejected=data.rejected_files,
            days=self._current_age_days,
        )
        result = self._show_message_box(
            QMessageBox.Icon.Warning,
            self._t("confirm_title"),
            f"{self._t('confirm_body')}\n\n{summary}",
            button_keys=("cancel", "continue"),
            default_button_key="cancel",
        )
        selected = self._pending_cleanup_candidates
        if result != "continue":
            self._record_history_event(
                HistoryEvent(
                    operation_type=HistoryOperation.CLEANUP,
                    result=HistoryResult.CANCELLED,
                    selected_files=len(selected),
                    skipped_files=data.rejected_files,
                    estimated_bytes=data.estimated_bytes,
                )
            )
            self._pending_cleanup_candidates = ()
            self._cleanup_stage = "idle"
            self._render_cleanup_state(preserve_selection=True)
            return

        if not selected:
            # Selection state cannot be reconstructed from paths or GUI data.
            self._cleanup_stage = "idle"
            self._show_message_box(
                QMessageBox.Icon.Warning, self._t("cleanup"), self._t("selection_stale")
            )
            return

        age_days = self._current_age_days
        self._pending_cleanup_estimated_bytes = data.estimated_bytes
        self._cleanup_running = True
        self._cleanup_stage = "execute"
        self._set_cleanup_controls_busy(True)
        self._delete_selected_button.setText(self._t("cleaning"))
        self._set_status_label(self._cleanup_status, self._t("cleaning"), "Loading")
        started = self._run_worker(
            "cleanup",
            lambda progress: self._provider.delete_files(
                selected, age_days, confirmed=True
            ),
            self._on_cleanup_deleted,
        )
        if not started:
            self._cleanup_running = False
            self._pending_cleanup_candidates = ()
            self._pending_cleanup_estimated_bytes = None
            self._handle_operation_failure("cleanup", "duplicate_operation_blocked")

    def _set_cleanup_controls_busy(self, busy: bool) -> None:
        """Disable selection/actions while a scan, preview or cleanup is active."""
        self._cleanup_scan_button.setEnabled(not busy)
        self._age_spin.setEnabled(not busy)
        self._select_all_button.setEnabled(bool(self._cleanup_candidates) and not busy)
        self._clear_selection_button.setEnabled(bool(self._cleanup_candidates) and not busy)
        for checkbox in self._cleanup_checkboxes:
            checkbox.setEnabled(not busy)
        has_selection = bool(self._selected_cleanup_candidates())
        self._delete_selected_button.setEnabled(has_selection and not busy)
        if self._cleanup_running:
            self._delete_selected_button.setText(self._t("cleaning"))
        elif self._cleanup_previewing:
            self._delete_selected_button.setText(self._t("loading_cleanup_preview"))
        else:
            self._delete_selected_button.setText(self._t("delete_selected"))

    def _on_cleanup_deleted(self, data: object) -> None:
        self._cleanup_running = False
        self._set_cleanup_controls_busy(False)
        if not isinstance(data, CleanupResult):
            self._handle_operation_failure("cleanup", "invalid_cleanup_result")
            return
        error_codes: tuple[str, ...] = ()
        if data.failed_files > 0:
            error_codes = ("trash_or_verification_failed",)
        self._record_history_event(
            HistoryEvent(
                operation_type=HistoryOperation.CLEANUP,
                result=_cleanup_history_result(data),
                selected_files=data.selected_files,
                moved_files=data.moved_files,
                skipped_files=data.omitted_files,
                failed_files=data.failed_files,
                estimated_bytes=self._pending_cleanup_estimated_bytes,
                moved_bytes=data.moved_bytes,
                error_codes=error_codes,
            )
        )
        self._pending_cleanup_estimated_bytes = None
        self._pending_cleanup_candidates = ()
        self._cleanup_stage = "idle"
        self._show_message_box(
            QMessageBox.Icon.Information,
            self._t("cleanup_done"),
            self._t(
                "cleanup_result",
                moved=data.moved_files,
                value=data.moved_bytes / (1024**3),
                failed=data.failed_files,
                changed=data.skipped_changed_files,
                skipped=data.skipped_files,
            ),
        )
        # The service consumes the selected-scan manifest. Perform a new
        # read-only scan after a confirmed attempt; old candidates are never
        # reused for a second cleanup attempt.
        self._analyze_cleanup()

    def _load_startup(self) -> None:
        if self._task_is_running("startup"):
            self._show_operation_busy("startup")
            return
        self._startup_loading = True
        self._startup_refresh.setEnabled(False)
        self._render_startup_entries()
        self._run_worker(
            "startup", lambda progress: self._provider.list_startup_entries(), self._on_startup
        )

    def _on_startup(self, data: object) -> None:
        self._startup_loading = False
        self._startup_refresh.setEnabled(True)
        if not isinstance(data, list) or not all(
            isinstance(item, StartupEntry) for item in data
        ):
            self._handle_operation_failure("startup", "invalid_result")
            return
        self._startup_loaded = True
        self._startup_entries = data
        self._render_startup_entries()

    def _load_processes(self) -> None:
        if self._task_is_running("processes"):
            self._show_operation_busy("processes")
            return
        self._processes_loading = True
        self._processes_refresh.setEnabled(False)
        self._render_process_entries()
        self._run_worker(
            "processes", lambda progress: self._provider.list_processes(), self._on_processes
        )

    def _on_processes(self, data: object) -> None:
        self._processes_loading = False
        self._processes_refresh.setEnabled(True)
        if not isinstance(data, list) or not all(
            isinstance(item, ProcessInfo) for item in data
        ):
            self._handle_operation_failure("processes", "invalid_result")
            return
        self._processes_loaded = True
        self._process_entries = data
        self._render_process_entries()

    def _refresh_history(self) -> None:
        self._history_table.clearSpans()
        self._history_table.setRowCount(0)
        if not self._history:
            self._set_table_empty_state(self._history_table, "empty_history")
            return
        for event in self._history:
            row = self._history_table.rowCount()
            self._history_table.insertRow(row)
            self._history_table.setItem(
                row,
                0,
                QTableWidgetItem(event.timestamp.astimezone().strftime(self._t("date_time_seconds_format"))),
            )
            self._history_table.setItem(
                row, 1, QTableWidgetItem(self._t(f"history_op_{event.operation_type.value}"))
            )
            self._history_table.setItem(
                row, 2, QTableWidgetItem(self._t(f"history_result_{event.result.value}"))
            )
            file_count = (
                event.selected_files
                if event.selected_files is not None
                else event.candidate_files
                if event.candidate_files is not None
                else event.files_seen
                if event.files_seen is not None
                else event.process_count
            )
            self._history_table.setItem(
                row,
                3,
                QTableWidgetItem(self._t("history_na") if file_count is None else str(file_count)),
            )
            self._history_table.setItem(
                row, 4, QTableWidgetItem(_format_bytes(event.estimated_bytes, self._t("history_na")))
            )
            self._history_table.setItem(
                row, 5, QTableWidgetItem(_format_bytes(event.moved_bytes, self._t("history_na")))
            )
            self._history_table.setItem(
                row,
                6,
                QTableWidgetItem(
                    self._t(
                        "history_count_pair",
                        skipped=event.skipped_files,
                        failed=event.failed_files,
                    )
                ),
            )

    def _load_history(self) -> None:
        try:
            self._history = list(self._history_store.load())
        except HistoryStoreError as exc:
            LOGGER.warning("History load failed; error_code=%s", exc.code)
            self._history = []
        except Exception as exc:  # noqa: BLE001 - keep local history failure recoverable
            log_safe_exception(LOGGER, "history_load_unexpected", exc)
            self._history = []
        self._refresh_history()

    def _record_history_event(self, event: HistoryEvent) -> None:
        # Keep this session's UI useful even when persistent storage is denied.
        self._history.insert(0, event)
        self._history = self._history[: self._history_store.max_entries]
        try:
            self._history = list(self._history_store.append(event))
        except HistoryStoreError as exc:
            LOGGER.warning("History append failed; error_code=%s", exc.code)
        except Exception as exc:  # noqa: BLE001 - keep history failures recoverable
            log_safe_exception(LOGGER, "history_append_unexpected", exc)
        self._refresh_history()

    def _clear_history(self) -> None:
        result = self._show_message_box(
            QMessageBox.Icon.Warning,
            self._t("history_clear_confirm_title"),
            self._t("history_clear_confirm"),
            button_keys=("cancel", "delete"),
            default_button_key="cancel",
        )
        if result != "delete":
            return
        try:
            removed = self._history_store.clear()
        except HistoryStoreError as exc:
            LOGGER.warning("History deletion failed; error_code=%s", exc.code)
            self._show_message_box(
                QMessageBox.Icon.Warning, self._t("error"), self._t("history_clear_failed")
            )
            return
        except Exception as exc:  # noqa: BLE001 - do not crash the UI on storage errors
            log_safe_exception(LOGGER, "history_delete_unexpected", exc)
            self._show_message_box(
                QMessageBox.Icon.Warning, self._t("error"), self._t("history_clear_failed")
            )
            return
        self._history.clear()
        self._refresh_history()
        message = "history_clear_done" if removed else "history_clear_missing"
        self._show_message_box(
            QMessageBox.Icon.Information, self._t("history"), self._t(message)
        )

    def _task_is_running(self, task_key: str) -> bool:
        # Keep the task lock until its queued result/error has been handled on
        # the GUI thread, even if the native QThread has already stopped.
        return task_key in self._active_tasks

    def _run_worker(
        self,
        task_key: str,
        func: Callable[[Callable[[str], None]], object],
        callback: Callable[[object], None],
    ) -> bool:
        """Start a provider/service operation once and route Qt signals safely.

        The signal receivers are bound MainWindow methods, so Qt can deliver
        results to the GUI thread. Lambdas are deliberately not used as slots
        for worker-thread results.
        """
        if self._task_is_running(task_key):
            LOGGER.info("Duplicate background operation ignored; operation=%s", task_key)
            self._show_operation_busy(task_key)
            return False

        worker = Worker(task_key, func)
        self._workers.append(worker)
        self._active_tasks[task_key] = worker
        self._worker_callbacks[id(worker)] = callback
        worker.finished_data.connect(self._on_worker_data)
        worker.progress.connect(self._show_worker_progress)
        worker.failed.connect(self._on_worker_failed)
        worker.finished.connect(self._on_worker_thread_finished)
        try:
            worker.start()
        except Exception as exc:  # noqa: BLE001 - thread startup must be recoverable
            if self._active_tasks.get(task_key) is worker:
                self._active_tasks.pop(task_key, None)
            self._worker_callbacks.pop(id(worker), None)
            try:
                self._workers.remove(worker)
            except ValueError:
                pass
            log_safe_exception(LOGGER, f"worker_{task_key}_start_failed", exc)
            worker.deleteLater()
            self._handle_operation_failure(task_key, "worker_start_failed")
            return False
        return True

    def _on_worker_data(self, worker: Worker, data: object) -> None:
        """Process worker results on the GUI thread after releasing its task lock."""
        if self._active_tasks.get(worker.task_key) is worker:
            self._active_tasks.pop(worker.task_key, None)
        callback = self._worker_callbacks.pop(id(worker), None)
        if callback is None:
            LOGGER.warning("Worker result arrived without callback; operation=%s", worker.task_key)
            return
        try:
            callback(data)
        except Exception as exc:  # noqa: BLE001 - UI must recover from callback errors
            log_safe_exception(LOGGER, f"worker_{worker.task_key}_callback_failed", exc)
            self._handle_operation_failure(worker.task_key, "callback_failed")
        finally:
            self._release_finished_worker_if_ready(worker)

    def _on_worker_failed(self, worker: Worker, error_code: str) -> None:
        """Handle a safe error code in the GUI thread; never expose exception text."""
        if self._active_tasks.get(worker.task_key) is worker:
            self._active_tasks.pop(worker.task_key, None)
        self._worker_callbacks.pop(id(worker), None)
        if worker.task_key == "activity":
            LOGGER.debug("Dashboard activity sample unavailable; code=%s", error_code)
            self._release_finished_worker_if_ready(worker)
            return
        self._handle_operation_failure(worker.task_key, error_code)
        self._release_finished_worker_if_ready(worker)

    def _on_worker_thread_finished(self) -> None:
        """Release the QThread object after Qt signals have been queued."""
        worker = self.sender()
        if not isinstance(worker, Worker):
            return
        self._finished_workers.add(id(worker))
        self._release_finished_worker_if_ready(worker)

    def _release_finished_worker_if_ready(self, worker: Worker) -> None:
        """Release worker lifetime only after both thread and result handling finish."""
        worker_id = id(worker)
        if worker_id not in self._finished_workers:
            return
        if worker_id in self._worker_callbacks:
            return
        self._finished_workers.discard(worker_id)
        try:
            self._workers.remove(worker)
        except ValueError:
            pass
        worker.deleteLater()

    def _show_worker_progress(self, worker: Worker, value: str) -> None:
        """Show localized file counts only; provider progress can contain paths."""
        task_key = worker.task_key
        match = re.search(r"(?:Scanned|Files inspected):\s*(\d+)", value, re.IGNORECASE)
        progress_text = (
            self._t("progress_files", count=int(match.group(1))) if match else None
        )
        if task_key == "cleanup":
            if self._cleanup_previewing:
                text = self._t("loading_cleanup_preview")
            elif self._cleanup_running:
                text = self._t("cleaning")
            elif progress_text is not None:
                text = progress_text
            else:
                text = self._t("loading_cleanup")
            self._set_status_label(self._cleanup_status, text, "Loading")
        elif task_key == "protection":
            self._set_status_label(
                self._protection_result,
                progress_text or self._t("loading_protection"),
                "Loading",
            )
        elif task_key == "diagnostics" and self._pages.currentIndex() == 1:
            self._set_status_label(
                self._diagnostic_detail, self._t("loading_diagnostics"), "Loading"
            )
        elif task_key == "startup":
            self._render_startup_entries()
        elif task_key == "processes":
            self._render_process_entries()

    def _show_operation_busy(self, task_key: str) -> None:
        """Give a localized, non-modal indication instead of starting twice."""
        message = self._t("operation_already_running")
        if task_key == "cleanup":
            self._set_status_label(self._cleanup_status, message, "Loading")
        elif task_key == "protection":
            self._set_status_label(self._protection_result, message, "Loading")
        elif task_key == "diagnostics" and self._pages.currentIndex() == 1:
            self._set_status_label(self._diagnostic_detail, message, "Loading")

    def _handle_operation_failure(self, task_key: str, error_code: str) -> None:
        """Record a minimal error and restore only the affected operation."""
        safe_code = (
            error_code
            if error_code.isascii() and error_code.replace("_", "").isalnum()
            else "operation_failed"
        )
        LOGGER.error("Background operation failed; operation=%s code=%s", task_key, safe_code)
        self._record_application_error(safe_code)
        self._restore_after_worker_failure(task_key)
        self._show_message_box(
            QMessageBox.Icon.Critical, self._t("error"), self._t("operation_failed")
        )

    def _record_application_error(self, error_code: str = "worker_operation_failed") -> None:
        self._record_history_event(
            HistoryEvent(
                operation_type=HistoryOperation.APPLICATION_ERROR,
                result=HistoryResult.FAILED,
                error_codes=(error_code,),
            )
        )

    def _restore_after_worker_failure(self, task_key: str) -> None:
        """Restore controls for the failed task without resetting unrelated work."""
        self._retranslate_ui()
        if task_key == "diagnostics":
            self._scan_state = "idle"
            self._diagnostics_loading = False
            self._scan_button.setEnabled(True)
            self._diagnostics_refresh.setEnabled(True)
            self._last_snapshot = None
            self._last_diagnostic_snapshot = None
            self._render_snapshot()
            self._set_status_label(
                self._diagnostic_detail, self._t("operation_failed"), "Error"
            )
        elif task_key == "protection":
            self._protection_loading = False
            self._protection_button.setEnabled(True)
            self._last_protection_summary = None
            self._set_status_label(
                self._protection_result, self._t("operation_failed"), "Error"
            )
        elif task_key == "cleanup":
            stage = self._cleanup_stage
            self._cleanup_loading = False
            self._cleanup_previewing = False
            self._cleanup_running = False
            self._pending_cleanup_estimated_bytes = None
            self._pending_cleanup_candidates = ()
            if stage in {"scan", "execute"}:
                # The provider invalidates/consumes the service manifest for
                # scans and cleanup attempts. Old candidate widgets must not be
                # left available after either operation fails.
                self._last_cleanup_summary = None
                self._cleanup_candidates = []
                self._discarded_candidate_count = 0
                self._cleanup_checkboxes = []
            self._cleanup_stage = "idle"
            self._set_cleanup_controls_busy(False)
            self._render_cleanup_state(preserve_selection=(stage == "preview"))
            self._set_status_label(
                self._cleanup_status, self._t("operation_failed"), "Error"
            )
        elif task_key == "startup":
            self._startup_loading = False
            self._startup_refresh.setEnabled(True)
            self._startup_loaded = False
            self._startup_entries = []
            self._set_table_empty_state(self._startup_table, "operation_failed")
        elif task_key == "processes":
            self._processes_loading = False
            self._processes_refresh.setEnabled(True)
            self._processes_loaded = False
            self._process_entries = []
            self._set_table_empty_state(self._process_table, "operation_failed")

    def closeEvent(self, event: QCloseEvent) -> None:
        """Prevent destruction of a window while owned QThreads are still active."""
        running_workers = any(worker.isRunning() for worker in self._workers)
        if self._active_tasks or running_workers:
            event.ignore()
            self._show_message_box(
                QMessageBox.Icon.Warning,
                self._t("worker_close_title"),
                self._t("worker_close_body"),
            )
            return
        if hasattr(self, "_activity_timer"):
            self._activity_timer.stop()
        event.accept()

    def _show_message_box(
        self,
        icon: QMessageBox.Icon,
        title: str,
        message: str,
        *,
        button_keys: tuple[str, ...] = ("ok",),
        default_button_key: str = "ok",
    ) -> str | None:
        """Show a translated dialog with localized button captions."""
        box = QMessageBox(self)
        box.setIcon(icon)
        box.setWindowTitle(title)
        box.setText(message)
        box.setTextFormat(Qt.TextFormat.PlainText)
        buttons = {}
        for key in button_keys:
            role = (
                QMessageBox.ButtonRole.RejectRole
                if key == "cancel"
                else QMessageBox.ButtonRole.AcceptRole
            )
            buttons[key] = box.addButton(self._t(key), role)
        if default_button_key in buttons:
            box.setDefaultButton(buttons[default_button_key])
        if "cancel" in buttons:
            box.setEscapeButton(buttons["cancel"])
        box.exec()
        clicked = box.clickedButton()
        return next((key for key, button in buttons.items() if button is clicked), None)


