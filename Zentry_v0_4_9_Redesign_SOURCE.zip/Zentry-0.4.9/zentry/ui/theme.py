"""Zentry's dark navy desktop theme with cyan/violet accents and clear focus states."""

from __future__ import annotations

STYLESHEET = r"""
QWidget {
    background: #06101e;
    color: #eaf3ff;
    font-family: "Segoe UI";
    font-size: 13px;
}
QMainWindow, QWidget#mainContent { background: #06101e; }
QFrame#sidebar {
    background: #071427;
    border-right: 1px solid #142b47;
}
QLabel#brandMark {
    color: #f8fbff;
    background: qlineargradient(x1:0, y1:1, x2:1, y2:0, stop:0 #8658f5, stop:0.5 #168ff4, stop:1 #14d9ef);
    border: 1px solid #59dafa;
    border-radius: 10px;
    font-size: 29px;
    font-weight: 900;
}
QLabel#brand {
    color: #f5f9ff;
    background: transparent;
    font-size: 22px;
    font-weight: 900;
    letter-spacing: 4px;
    padding: 4px 0;
}
QLabel#brandSubtitle {
    color: #8faed3;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1.0px;
    padding-left: 4px;
}
QFrame#topbar {
    background: #06101d;
    border-bottom: 1px solid #132b48;
}
QLabel#safetyBadge {
    color: #aaf5df;
    background: #082323;
    border: 1px solid #206b68;
    border-radius: 16px;
    padding: 7px 14px;
    font-weight: 700;
}
QPushButton#navButton, QPushButton#navSelected {
    text-align: left;
    padding: 10px 12px;
    min-height: 24px;
    border-radius: 8px;
    border: 1px solid transparent;
    color: #a7c0e2;
    background: transparent;
    font-size: 14px;
    font-weight: 600;
}
QPushButton#navButton:hover { background: #0c2037; color: #f2f7ff; }
QPushButton#navButton:checked, QPushButton#navSelected {
    background: #082942;
    color: #36e8ff;
    border: 1px solid #105273;
    border-left: 3px solid #17e4ff;
}
QLabel#safeStatus {
    color: #688fbf;
    background: transparent;
    padding: 8px 4px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.4px;
}
QLabel#version {
    color: #587ca9;
    font-size: 10px;
    padding: 4px;
}
QLabel#eyebrow, QLabel#sectionLabel {
    color: #64d9ee;
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.6px;
}
QLabel#pageTitle { color: #f4f8ff; font-size: 29px; font-weight: 850; }
QLabel#pageSubtitle { color: #8caed7; font-size: 14px; }
QPushButton#scanButton {
    color: #03121d;
    background: #18d7f4;
    border: 1px solid #77f1ff;
    border-radius: 11px;
    padding: 12px 18px;
    min-height: 22px;
    font-weight: 900;
}
QPushButton#scanButton:hover { background: #69eaff; }
QPushButton#scanButton:disabled { background: #22536b; color: #a6c9da; }
QPushButton#secondaryButton, QPushButton#dangerButton, QPushButton#languageButton {
    border-radius: 9px;
    padding: 8px 13px;
    min-height: 20px;
    font-weight: 700;
}
QPushButton#secondaryButton, QPushButton#languageButton {
    background: #09192d;
    border: 1px solid #244467;
    color: #c5ddfb;
}
QPushButton#secondaryButton:hover, QPushButton#languageButton:hover {
    background: #102844;
    border-color: #3f799f;
}
QPushButton#outlinedCyanButton {
    color: #39e6fb;
    background: #061827;
    border: 1px solid #04cde9;
    border-radius: 20px;
    padding: 10px 17px;
    min-height: 22px;
    font-weight: 800;
}
QPushButton#outlinedCyanButton:hover { background: #0a3045; border-color: #70f4ff; }
QPushButton#dangerButton {
    background: #28151e;
    border: 1px solid #a54b65;
    color: #ffd4de;
}
QPushButton#dangerButton:hover { background: #3a1c29; border-color: #d47b94; }
QPushButton#dangerButton:disabled { color: #99858b; background: #17151a; border-color: #49333a; }
QFrame#metricCard, QFrame#healthCard, QFrame#actionCard,
QFrame#contentCard, QFrame#tableCard, QFrame#recommendationPanel {
    background: #08182b;
    border: 1px solid #193858;
    border-radius: 12px;
}
QFrame#metricCard:hover, QFrame#actionCard:hover { border-color: #276084; }
QLabel#metricIcon { color: #63dff2; font-size: 21px; font-weight: 800; }
QLabel#metricTitle {
    color: #8eafd5;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.8px;
}
QLabel#metricValue { color: #f1f7ff; font-size: 20px; font-weight: 850; }
QLabel#metricDetail, QLabel#healthText, QLabel#contentText, QLabel#actionDescription {
    color: #91afd2;
}
QLabel#healthScore { color: #2de4c6; font-size: 25px; font-weight: 900; }
QProgressBar {
    background: #0b2038;
    border: 1px solid #1d3d5c;
    border-radius: 5px;
    min-height: 8px;
}
QProgressBar::chunk { background: #20d9eb; border-radius: 4px; }
QLabel#notice {
    color: #a7d7f0;
    background: #032a30;
    border: 1px solid #087b83;
    border-left: 4px solid #16d8b8;
    border-radius: 12px;
    padding: 13px 18px;
    font-size: 13px;
}
QLabel#workflow { color: #668ab4; font-size: 10px; font-weight: 800; letter-spacing: 0.65px; }
QLabel#actionTitle { color: #eaf4ff; font-size: 14px; font-weight: 800; }
QLabel#contentTitle { color: #f2f6fb; font-size: 22px; font-weight: 850; }
QLabel#contentHeading { color: #eaf4ff; font-size: 15px; font-weight: 850; padding: 2px 2px 5px 2px; }
QFrame#cleanupFeatureCard {
    background: #071d31;
    border: 1px solid #087d9d;
    border-left: 3px solid #13d9f1;
    border-radius: 12px;
}
QLabel#featureMark { color: #35e7ff; font-size: 32px; font-weight: 800; }
QLabel#badgeSafe, QLabel#badgeProtected, QLabel#badgeReview,
QLabel#statusCandidate, QLabel#statusProtected, QLabel#statusReview,
QLabel#statusLoading, QLabel#statusReady, QLabel#statusEmpty, QLabel#statusError {
    border-radius: 7px;
    padding: 8px 10px;
    font-size: 12px;
    font-weight: 700;
}
QLabel#badgeSafe, QLabel#statusCandidate {
    color: #a8f9dc; background: #0b2b2c; border: 1px solid #1d8378;
}
QLabel#badgeProtected, QLabel#statusProtected {
    color: #ffd0da; background: #301822; border: 1px solid #a14d63;
}
QLabel#badgeReview, QLabel#statusReview {
    color: #ffe4a6; background: #302711; border: 1px solid #8d732e;
}
QLabel#statusLoading { color: #c8efff; background: #102b3c; border: 1px solid #32708d; }
QLabel#statusReady { color: #c6f4df; background: #102b27; border: 1px solid #268b7a; }
QLabel#statusEmpty { color: #d0dbe5; background: #121e2c; border: 1px solid #344b64; }
QLabel#statusError { color: #ffd3d8; background: #31171d; border: 1px solid #b45362; }
QSpinBox, QComboBox {
    background: #07172a; border: 1px solid #2a4c70; border-radius: 7px;
    padding: 7px; color: #e5eef6; min-height: 20px;
}
QCheckBox { spacing: 9px; color: #e2ebf3; padding: 4px; }
QCheckBox::indicator { width: 18px; height: 18px; }
QCheckBox::indicator:unchecked { background: #07172a; border: 2px solid #8297aa; border-radius: 4px; }
QCheckBox::indicator:checked { background: #25dff3; border: 2px solid #b2edff; border-radius: 4px; }
QTableWidget {
    background: #07172a; alternate-background-color: #0b1d32;
    border: 1px solid #193858; gridline-color: #1b3854;
    selection-background-color: #16496a; selection-color: #ffffff; outline: none;
}
QTableWidget::item { padding: 7px 6px; }
QTableWidget::item:focus { border: 1px solid #8bdcff; }
QHeaderView::section {
    background: #0d223a; color: #b8d1ed; border: none;
    border-bottom: 1px solid #24496c; padding: 10px 8px;
    font-size: 11px; font-weight: 800;
}
QScrollBar:vertical { width: 12px; background: #06101e; margin: 2px; }
QScrollBar::handle:vertical { background: #234667; min-height: 40px; border-radius: 5px; }
QScrollBar::handle:vertical:hover { background: #3b6e96; }
QScrollBar:horizontal { height: 12px; background: #06101e; margin: 2px; }
QScrollBar::handle:horizontal { background: #234667; min-width: 40px; border-radius: 5px; }
QToolTip { color: #f6f8fb; background: #10253c; border: 1px solid #47769c; padding: 6px; }
QPushButton#navButton:focus, QPushButton#navSelected:focus,
QPushButton#scanButton:focus, QPushButton#secondaryButton:focus,
QPushButton#dangerButton:focus, QPushButton#languageButton:focus,
QPushButton#outlinedCyanButton:focus, QCheckBox:focus, QSpinBox:focus,
QComboBox:focus, QTableWidget:focus { border: 2px solid #f4fbff; }
"""
