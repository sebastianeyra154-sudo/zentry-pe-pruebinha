"""Desktop user interface."""
