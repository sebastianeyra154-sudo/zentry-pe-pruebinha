from __future__ import annotations

import logging
import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from zentry.core.logging_setup import configure_logging as _configure_logging
from zentry.providers.system import SystemDiagnosticsProvider
from zentry.ui.main_window import MainWindow
from zentry.ui.theme import STYLESHEET

LOGGER = logging.getLogger("zentry")


def configure_logging() -> Path | None:
    """Configure bounded, privacy-conscious logging for the application."""
    return _configure_logging()


def main() -> int:
    configure_logging()
    app = QApplication(sys.argv)
    app.setApplicationName("Zentry")
    app.setOrganizationName("Zentry")
    app.setStyleSheet(STYLESHEET)

    provider = SystemDiagnosticsProvider()
    window = MainWindow(provider)
    window.show()
    LOGGER.info("Zentry started")
    return app.exec()
