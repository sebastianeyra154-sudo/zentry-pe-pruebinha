# Cambios de Zentry 0.4.5

Versión de corrección centrada en la compatibilidad de las pruebas y el escáner con Windows.

- El escáner ahora obtiene la instantánea inicial de metadatos con `os.lstat()`, igual que en las revalidaciones, para evitar falsos positivos de “archivo cambiado” por diferencias de identidad expuestas por la enumeración en Windows.
- La prueba que simula una marca de tiempo inválida conserva los atributos propios de Windows y continúa comprobando que la marca inválida se clasifique como revisión necesaria.
- Se alineó la etiqueta en inglés de Inicio con “Overview”, tal como exige el contrato de navegación de las pruebas.

## Validación disponible

- En este entorno: `134 passed, 3 skipped`.
- Las pruebas omitidas requieren PySide6, no instalado en este entorno.
- Aún debe volver a ejecutarse la suite en Windows. Esta corrección no se considera validada en Windows hasta que el build real termine correctamente.
