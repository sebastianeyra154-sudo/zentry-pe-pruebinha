# Cambios de Zentry 0.4.6

Corrección puntual posterior a las pruebas de Windows.

- Se alineó el texto de navegación en inglés de la sección de limpieza con el contrato de interfaz (`Cleanup`). El encabezado de la página conserva `Safe cleanup`, que comunica el flujo seguro.
- Se incrementó la versión del paquete a `0.4.6`.

## Estado de validación

- La ejecución Windows anterior mostró `130 passed, 6 skipped, 1 failed`; el único fallo comunicado era la etiqueta de navegación. En la ejecución local posterior a esta corrección, `pytest` dio `135 passed, 3 skipped`.
- Esta corrección debe volver a probarse en Windows. No se afirma que el EXE esté construido ni validado hasta que el constructor complete todas las etapas.
