# Zentry 0.4.9 — guía breve para la presentación

## Qué es Zentry

Zentry es una aplicación de escritorio para Windows centrada en entender el estado del equipo y realizar mantenimiento prudente sin exigir que el usuario use comandos ni conozca rutas internas del sistema.

Su diseño prioriza tres ideas: datos legibles, explicaciones claras y confirmación del usuario antes de una acción que mueva archivos.

## Funciones incluidas en el código fuente

- **Panel de estado:** resumen de CPU, memoria, almacenamiento e información de inicio disponible.
- **Diagnóstico:** consulta de métricas del equipo en modo de lectura.
- **Procesos:** consulta de procesos y métricas disponibles; no incorpora un botón para finalizar procesos.
- **Inicio de Windows:** inspección de entradas estándar de inicio; no deshabilita programas.
- **Limpieza segura:** analiza raíces aprobadas de temporales y cachés conocidas, con antigüedad mínima predeterminada de 31 días.
- **Vista previa y confirmación:** el usuario revisa y selecciona los candidatos. Los elementos vuelven a validarse antes de actuar y se envían a la Papelera de reciclaje; no se implementa un borrado permanente como alternativa.
- **Protección de Windows:** clasifica rutas y explica límites del análisis; no afirma ser un inventario completo del sistema.
- **Historial y logs locales:** registra resúmenes de operaciones con tratamiento prudente de datos.
- **Español e inglés:** la interfaz permite cambiar de idioma durante la sesión.

## Seguridad por diseño

Zentry no inicia escaneos ni limpiezas automáticamente al abrirse. Las pantallas de diagnóstico son de lectura. Tener antigüedad no convierte automáticamente un archivo en innecesario: las reglas de seguridad y la selección del usuario siguen siendo obligatorias. La recuperación desde la Papelera puede depender del volumen y del entorno, así que tampoco se promete recuperación garantizada.

## Identidad visual

La interfaz actualizada usa fondo azul marino, paneles con bordes discretos, acentos cian y violeta, navegación lateral, estado visible «Modo seguro» y una acción principal diferenciada. La imagen `docs/zentry-dashboard-mockup.png` es una **maqueta visual de referencia**; los valores que aparecen en ella son ilustrativos y no son datos medidos de un equipo.

## Estado de pruebas y límites de esta entrega

Validaciones ejecutadas en este entorno el 22 de octubre de 2026 sobre el código v0.4.9:

- `python -m compileall -q zentry tests`: correcto.
- `python -m pytest -q -rs`: **141 pruebas correctas y 3 omitidas**.
- Las pruebas omitidas requieren PySide6, que no está instalado en este entorno. Por eso no se pudo abrir la GUI para una validación visual aquí.
- El ejecutable final de Windows todavía debe generarse y verificarse en un runner de Windows. La existencia del código fuente y el paso de pruebas en Linux no equivalen a una release de Windows validada.

## Guion sugerido para una demostración

1. Abrir Inicio y explicar que no se ejecuta ninguna limpieza automática.
2. Ejecutar «Escanear sistema» para recoger métricas reales disponibles.
3. Mostrar Diagnóstico, Procesos e Inicio de Windows en modo de lectura.
4. Abrir Limpieza segura, analizar candidatos y explicar las clasificaciones.
5. Mostrar la vista previa y el resumen antes de cualquier confirmación.
6. Explicar el historial local y los límites de protección del sistema.

**Frase de cierre:** Zentry no promete acelerar todo con un solo clic; ayuda a entender el estado del equipo y hace que el mantenimiento sea explicable, revisable y confirmado por la persona usuaria.
