# Zentry v0.4.8

- Acelera el análisis de ubicaciones temporales omitiendo temprano archivos recientes según la primera lectura de metadatos; candidatos antiguos o con fechas inciertas mantienen la validación completa.
- El muestreo del gráfico CPU/RAM ahora se solicita al proveedor desde un trabajador en segundo plano; la interfaz no consulta directamente APIs del sistema.
- La etiqueta superior informa **Modo seguro** y explica que el diagnóstico es de lectura, mientras que la limpieza se activa solo con vista previa y confirmación y usa la Papelera.
- Se afinó el panel principal con métricas reales, indicadores circulares, actividad medida, tarjetas de acciones y una banda de limpieza segura.
- Se corrigió el contraste del banner para cumplir la prueba automatizada.

Los datos de uso solo se muestran si son mediciones válidas. La maqueta sigue siendo una referencia visual; esta compilación debe validarse en Windows.
