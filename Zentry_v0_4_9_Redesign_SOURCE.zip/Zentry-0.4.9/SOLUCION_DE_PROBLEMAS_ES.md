# Zentry — guía de solución de problemas

Trabaja desde una terminal normal y en una copia del proyecto. No desactives protecciones de Windows, no cambies `ExecutionPolicy`, no ejecutes como administrador y no descargues DLL de Qt desde sitios no oficiales.

## 1. Python no se encuentra o se abre Microsoft Store

El constructor necesita una instalación funcional de CPython, no solo un alias de App Execution Alias.

Desde PowerShell:

```powershell
py -3 --version
python3 --version
python --version
Get-Command py, python3, python -ErrorAction SilentlyContinue
```

No todos los comandos tienen que existir. Si las salidas muestran que no hay intérprete válido, instala CPython desde una fuente confiable. `build_windows.bat` y `build_windows.ps1` prueban candidatos y muestran el intérprete/versión aceptado; no confían solo en el nombre del comando.

## 2. `.venv` existe, pero el constructor la considera dañada

El constructor no elimina automáticamente un entorno existente incompatible. Cierra Zentry y las terminales que estén utilizando el entorno. Haz una copia de seguridad y renombra solo la carpeta `.venv` del proyecto, por ejemplo:

```powershell
Rename-Item -LiteralPath .venv -NewName .venv.bak
```

Después vuelve a ejecutar `build_windows.bat`. No renombres ni elimines una carpeta si `Get-Location` no confirma que estás en la raíz del proyecto correcta.

## 3. La instalación de dependencias falla

Ejecuta los comandos por separado para encontrar la etapa exacta:

```powershell
.\.venv\Scripts\python.exe --version
.\.venv\Scripts\python.exe -m pip --version
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pip check
```

Comprueba la conexión de red y el error concreto de pip. No instales paquetes con un `pip` global distinto del de `.venv`. Si falla una dependencia, conserva la salida completa y no continúes asumiendo que la instalación fue correcta.

## 4. Error de Qt/PySide6 o plugin `windows`

Primero ejecuta la app desde fuente, porque la terminal puede mostrar el traceback que un ejecutable `--windowed` no presenta en consola:

```powershell
.\.venv\Scripts\python.exe -m zentry
```

Comprueba además:

```powershell
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -c "import PySide6; print(PySide6.__version__)"
```

Si el error aparece solo en el EXE, conserva la salida completa del build y la versión instalada. PyInstaller usa hooks estándar para PySide6/Qt; ciertos warnings sobre plugins opcionales pueden no ser fatales, pero no deben ocultarse. La señal decisiva es el código de salida de PyInstaller y la prueba posterior de arranque. No copies DLL al azar ni fuerces `--collect-all PySide6` como primer recurso.

## 5. La compilación termina, pero no existe `dist\Zentry.exe`

Revisa la última línea `[PASO x/8]` y la marca `[FALLO]`. El constructor ejecuta `compileall` y pytest antes de eliminar artefactos y compilar. Si fallan las pruebas, no comienza el build. Como la carpeta `dist` puede contener un EXE de una ejecución anterior cuando el fallo ocurre antes del paso de limpieza, no lo consideres un resultado nuevo.

Comprueba la ruta real:

```powershell
Get-Location
Get-ChildItem .\dist -ErrorAction SilentlyContinue
```

El resultado esperado es `dist\Zentry.exe`, tamaño mayor que cero. Esa verificación no prueba por sí sola que la GUI funcione.

## 6. Ruta demasiado larga

Extrae el proyecto en una ubicación corta como `C:\Zentry`. Evita anidar el ZIP en múltiples carpetas (`Downloads\archivo\otra-carpeta\...`). No hace falta cambiar globalmente la configuración de rutas largas de Windows para empezar por esta alternativa.

## 7. El EXE se abre y se cierra

Ejecuta la aplicación desde código fuente para que el fallo se vea en la terminal:

```powershell
.\.venv\Scripts\python.exe -m zentry
```

Revisa `%LOCALAPPDATA%\Zentry\logs\zentry.log`. Los logs minimizan datos sensibles, pero revísalos antes de compartirlos. Si el error solo ocurre dentro del EXE, el smoke test de CI puede ayudar a saber si termina pronto; un proceso que permanece activo diez segundos no garantiza que todas las páginas funcionen.

## 8. Obtener logs de build

### PowerShell constructor

`build_windows.ps1` crea `.build-logs\build_YYYYMMDD_HHMMSS.log` mediante `Start-Transcript` cuando está disponible.

### BAT desde PowerShell

```powershell
New-Item -ItemType Directory -Force .build-logs | Out-Null
.\build_windows.bat 2>&1 | Tee-Object -FilePath .\.build-logs\build-local.log
```

### GitHub Actions

En la ejecución correspondiente, descarga los artifacts `Zentry-build-logs-<run_id>` y, si el build fue exitoso, `Zentry-windows-py3.12-<arquitectura>`. Los logs se intentan subir incluso cuando falla un paso; revisa si el artifact existe.

## 9. Qué información compartir para depurar

Envía solo lo necesario:

1. Último paso `[PASO x/8]` y el mensaje `[FALLO]` completo.
2. Salida de `py -3 --version`, `python --version` (puedes omitir el comando que no exista) y `\.venv\Scripts\python.exe --version`.
3. Resultado de `pip check` y pytest.
4. Extracto relevante del log de build, después de revisar y redactar nombre de usuario, rutas personales y datos de organización.
5. Indica si el fallo es al ejecutar desde fuente, al construir o al iniciar el EXE.

No compartas contraseñas, tokens, variables de entorno completas, `history.json`, listas de procesos/inicio ni logs sin revisarlos.
